package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.SjdStatusType;
import com.peopletech.fractionable.dto.SjdDto;
import com.peopletech.fractionable.entity.SjdBO;
import com.peopletech.fractionable.entity.SjdStatusBO;
import com.peopletech.fractionable.repository.SjdRepository;
import com.peopletech.fractionable.service.CareersService;
import com.peopletech.fractionable.util.CommonUtil;
import org.dozer.DozerBeanMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CareeersServiceImplTest {
    @Mock
    private SjdRepository sjdRepository;

    private CareersService careersService;

    @BeforeEach
    public void setup(){
        careersService = new CareersServiceImpl(sjdRepository,new CommonUtil(new LookupServiceImpl(),new DozerBeanMapper()));
    }

    @Test
    @DisplayName("Method Should Return Empty Sjd List")
    public void getSjdReturnsEmptyList(){
        when(sjdRepository.findAllByPublishAndActive(true,true)).thenReturn(Collections.emptyList());
        assertEquals(0,careersService.getSjd().size());
    }

    @Test
    @DisplayName("Method Should Return Sjd List with size 1")
    public void getSjdReturnNonEmptyList(){
        SjdBO sjdBO1= new SjdBO();
        SjdBO sjdBO2= new SjdBO();
        SjdBO sjdBO3= new SjdBO();

        SjdStatusBO sjdStatusBO1= new SjdStatusBO();
        SjdStatusBO sjdStatusBO2= new SjdStatusBO();
        SjdStatusBO sjdStatusBO3 = new SjdStatusBO();

        sjdBO1.setSjdStatus(sjdStatusBO1);
        sjdBO2.setSjdStatus(sjdStatusBO2);
        sjdBO3.setSjdStatus(sjdStatusBO3);

        sjdBO1.getSjdStatus().setName(SjdStatusType.NEW.getType());
        sjdBO2.getSjdStatus().setName(SjdStatusType.ON_HOLD.getType());
        sjdBO3.getSjdStatus().setName(SjdStatusType.COMPLETED.getType());

        when(sjdRepository.findAllByPublishAndActive(true,true)).thenReturn(List.of(sjdBO1,sjdBO2,sjdBO3));
        List<SjdDto> list1 = careersService.getSjd();

        assertEquals(1,list1.size());
    }


}
