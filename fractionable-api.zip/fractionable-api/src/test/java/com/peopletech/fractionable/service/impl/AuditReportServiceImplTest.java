package com.peopletech.fractionable.service.impl;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.Date;
import java.util.List;

import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.persistence.Tuple;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.util.IOUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.peopletech.fractionable.dto.AuditReportDto;
import com.peopletech.fractionable.dto.request.ReportRequestDto;
import com.peopletech.fractionable.repository.SjdCandidateInfoRepository;

@ExtendWith(MockitoExtension.class)
class AuditReportServiceImplTest {

    @Mock
    private SjdCandidateInfoRepository sjdCandidateInfoRepository;

    @InjectMocks
    private AuditReportServiceImpl auditReportService;

    @Mock
    private CommonUtil commonUtil;

    private ReportRequestDto reportRequestDto;

    @BeforeEach
    void setUp() {
        reportRequestDto = new ReportRequestDto();
        reportRequestDto.setFromDate(new Date());
        reportRequestDto.setToDate(new Date());
    }

    @Test
    void testGetReport() {
        Instant fromDate=Instant.parse("2023-08-19T00:00:00Z");
        Tuple mockTuple=mock(Tuple.class);
        when(mockTuple.get(0,Integer.class)).thenReturn(3);
        when(mockTuple.get(1,String.class)).thenReturn("Full Stack");
        when(mockTuple.get(2,Integer.class)).thenReturn(10);
        when(mockTuple.get(3,String.class)).thenReturn("shiva");
        when(mockTuple.get(4,String.class)).thenReturn("Karan");
        when(mockTuple.get(5,Boolean.class)).thenReturn(true);
        when(mockTuple.get(6,String.class)).thenReturn("Nothing");
        when(mockTuple.get(7,String.class)).thenReturn("Keshava");
        when(mockTuple.get(8,Instant.class)).thenReturn(fromDate);
        when(mockTuple.get(9,Integer.class)).thenReturn(10);
        when(commonUtil.getNameFromId(mockTuple.get(9, Integer.class), LookupType.OPERATION)).thenReturn("Operations");


        List<Tuple> mockAuditReport=List.of(mockTuple);
        when(sjdCandidateInfoRepository.findAuditReport(any(Date.class), any(Date.class))).thenReturn(mockAuditReport);

        List<AuditReportDto> actualReport = auditReportService.getReport(reportRequestDto);
        Assertions.assertNotNull(actualReport);
        verify(sjdCandidateInfoRepository, times(1)).findAuditReport(any(), any());
    }

    @Test
    void testGetReportExcel() throws IOException {

        Instant fromDate=Instant.parse("2023-08-19T00:00:00Z");
        Tuple mockTuple=mock(Tuple.class);
        when(mockTuple.get(0,Integer.class)).thenReturn(3);
        when(mockTuple.get(1,String.class)).thenReturn("Full Stack");
        when(mockTuple.get(2,Integer.class)).thenReturn(10);
        when(mockTuple.get(3,String.class)).thenReturn("shiva");
        when(mockTuple.get(4,String.class)).thenReturn("Karan");
        when(mockTuple.get(5,Boolean.class)).thenReturn(true);
        when(mockTuple.get(6,String.class)).thenReturn("Nothing");
        when(mockTuple.get(7,String.class)).thenReturn("Keshava");
        when(mockTuple.get(8,Instant.class)).thenReturn(fromDate);
        when(mockTuple.get(9,Integer.class)).thenReturn(10);
        when(commonUtil.getNameFromId(mockTuple.get(9, Integer.class), LookupType.OPERATION)).thenReturn("Operations");


        List<Tuple> mockAuditReport=List.of(mockTuple);
        when(sjdCandidateInfoRepository.findAuditReport(any(Date.class),any(Date.class))).thenReturn(mockAuditReport);

       byte[] result= auditReportService.getReportExcel(reportRequestDto);
        ByteArrayInputStream inputStream = new ByteArrayInputStream(result);
        Workbook wb = new HSSFWorkbook(inputStream);
        Sheet sheet = wb.getSheetAt(0);

        Row headerRow = sheet.getRow(1);
        Assertions.assertNotNull(headerRow);
        Cell headerCell = headerRow.getCell(CellReference.convertColStringToIndex("B"));
        Cell headerCellNumeric = headerRow.getCell(CellReference.convertColStringToIndex("A"));
        Assertions.assertEquals("Full Stack",headerCell.getStringCellValue());
        Assertions.assertEquals(3,headerCellNumeric.getNumericCellValue());
        wb.close();
        IOUtils.closeQuietly(inputStream);
        verify(sjdCandidateInfoRepository, times(1)).findAuditReport(any(), any());
        Assertions.assertNotNull(result);
    }
}
