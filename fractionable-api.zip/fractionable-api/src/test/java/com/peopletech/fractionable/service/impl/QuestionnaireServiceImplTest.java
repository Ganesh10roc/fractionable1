package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.dto.LookupDto;
import com.peopletech.fractionable.dto.QuestionDto;
import com.peopletech.fractionable.dto.QuestionnaireAnswerDto;
import com.peopletech.fractionable.dto.QuestionnaireDto;
import com.peopletech.fractionable.dto.request.SjdQuestionnaireRequestDto;
import com.peopletech.fractionable.entity.CandidateEventTypeBO;
import com.peopletech.fractionable.entity.QuestionBO;
import com.peopletech.fractionable.entity.QuestionnaireAnswersBO;
import com.peopletech.fractionable.entity.QuestionnaireBO;
import com.peopletech.fractionable.repository.QuestionRepository;
import com.peopletech.fractionable.repository.QuestionnaireAnswerRepository;
import com.peopletech.fractionable.repository.QuestionnaireRepository;
import com.peopletech.fractionable.repository.SjdQuestionnaireMappingRepository;
import com.peopletech.fractionable.service.CandidateEventService;
import com.peopletech.fractionable.service.SjdEventService;
import com.peopletech.fractionable.util.CommonUtil;
import org.dozer.DozerBeanMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class QuestionnaireServiceImplTest {

    @Mock
    private SjdQuestionnaireMappingRepository sjdQuestionnaireMappingRepository;

    @Mock
    private QuestionnaireRepository questionnaireRepository;

    @Mock
    private QuestionRepository questionRepository;

    @Mock
    private SjdEventService sjdEventService;

    @Mock
    private QuestionnaireAnswerRepository questionnaireAnswerRepository;

    @Mock
    private CandidateEventService candidateEventService;

    @Mock
    private CommonUtil commonUtil;

    @Mock
    private DozerBeanMapper mapper;

    @InjectMocks
    private QuestionnaireServiceImpl questionnaireService;


    @Test
    public void testGetAllQuestionnaire() {
        when(questionnaireRepository.findAll()).thenReturn(new ArrayList<>());
        List<QuestionnaireDto> result = questionnaireService.getAllQuestionnaire();
        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("Should give empty skills list")
    public void getAllQuestionnaireByType_WithEmptySkillsList() {
        when(questionnaireRepository.findAllByQuestionnaireType(any())).thenReturn(new ArrayList<>());
        List<QuestionnaireDto> result = questionnaireService.getAllQuestionnaireByType(1, new ArrayList<>());
        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("Should have with skills List")
    public void getAllQuestionnaireByType_WithSkillsList() {
        when(questionnaireRepository.findByQuestionnaireTypeAndSkillsIn(any(), any())).thenReturn(new ArrayList<>());
        List<QuestionnaireDto> result = questionnaireService.getAllQuestionnaireByType(1, Collections.singletonList(new LookupDto()));
        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("Should return by questionnaire id")
    public void getQuestionnaireById_WithValidId() {
        QuestionnaireBO mockQuestionnaire = new QuestionnaireBO();
        mockQuestionnaire.setId(1);
        when(questionnaireRepository.findById(1)).thenReturn(Optional.of(mockQuestionnaire));
        QuestionnaireDto mockDto = new QuestionnaireDto();
        mockDto.setId(1); // Assuming setId() is available in QuestionnaireDto
        when(mapper.map(any(QuestionnaireBO.class), eq(QuestionnaireDto.class))).thenReturn(mockDto);
        QuestionnaireDto result = questionnaireService.getQuestionnaireById(1);
        assertNotNull(result);
        assertEquals(1, result.getId());
    }

    @Test
    @DisplayName("Should Return an invalid type id")
    public void getQuestionnaireById_WithInvalidId() {
        when(questionnaireRepository.findById(anyInt())).thenReturn(Optional.empty());
        assertThrows(NoSuchElementException.class, () -> questionnaireService.getQuestionnaireById(1));
    }

    @Test
    public void saveQuestionnaire() {
        QuestionnaireDto mockQuestionnaireDto = new QuestionnaireDto();
        mockQuestionnaireDto.setId(1);
        QuestionnaireBO mockQuestionnaireEntity = new QuestionnaireBO();
        mockQuestionnaireEntity.setId(1);
        when(questionnaireRepository.save(any())).thenReturn(mockQuestionnaireEntity);
        Integer result = questionnaireService.saveQuestionnaire(mockQuestionnaireDto, 1);
        assertNotNull(result);
        assertEquals(1, result);
    }

    @Test
    public void updateQuestionnaire() {
        QuestionnaireDto mockQuestionnaireDto = new QuestionnaireDto();
        mockQuestionnaireDto.setId(1);
        QuestionnaireBO mockQuestionnaireEntity = new QuestionnaireBO();
        mockQuestionnaireEntity.setId(1);
        when(questionnaireRepository.save(any())).thenReturn(mockQuestionnaireEntity);
        Integer result = questionnaireService.updateQuestionnaire(mockQuestionnaireDto, 1);
        assertNotNull(result);
        assertEquals(1, result);
    }

    @Test
    @DisplayName("Should save question type")
    public void saveQuestion() {
        QuestionDto mockQuestionDto = new QuestionDto();
        mockQuestionDto.setId(1);
        QuestionBO mockQuestionEntity = new QuestionBO();
        mockQuestionEntity.setId(1);
        when(questionRepository.save(any())).thenReturn(mockQuestionEntity);
        Integer result = questionnaireService.saveQuestion(mockQuestionDto);
        assertNotNull(result);
        assertEquals(1, result);
    }

    @Test
    @DisplayName("Should delete question with id")
    public void deleteQuestion() {
        assertDoesNotThrow(() -> questionnaireService.deleteQuestion(1));
    }

    @Test
    @DisplayName("Should convert tag questionnaire to sjd id")
    public void tagQuestionnaireToSjd() {
        SjdQuestionnaireRequestDto request = new SjdQuestionnaireRequestDto();
        request.setSjdId(1);
        request.setQuestionnaireId(1);
        when(sjdQuestionnaireMappingRepository.save(any())).thenReturn(null);
        assertDoesNotThrow(() -> questionnaireService.tagQuestionnaireToSjd(request, 1));
    }

    @Test
    public void getQuestionnaireAnswers() {
        when(questionnaireAnswerRepository.getAllBySjdIdAndCandidateId(anyInt(), anyInt())).thenReturn(Optional.of(new ArrayList<>()));
        List<QuestionnaireAnswerDto> result = questionnaireService.getQuestionnaireAnswers(1, 1);
        assertTrue(result.isEmpty());
    }

    @Test
    public void saveQuestionnaireAnswers() {
        QuestionnaireAnswerDto mockAnswer = new QuestionnaireAnswerDto();
        mockAnswer.setSjdId(1);
        mockAnswer.setCandidateId(1);
        CandidateEventTypeBO mockEventType = new CandidateEventTypeBO();
        mockEventType.setId(1); // Mock a non-null id
        when(commonUtil.mapItreable(anyList(), eq(QuestionnaireAnswersBO.class))).thenReturn(new ArrayList<>());
        when(questionnaireAnswerRepository.saveAll(anyList())).thenReturn(new ArrayList<>());
        when(commonUtil.getCandidateEventTypeId(anyString())).thenReturn(mockEventType);
        assertDoesNotThrow(() -> questionnaireService.saveQuestionnaireAnswers(Collections.singletonList(mockAnswer), 1));
    }
}