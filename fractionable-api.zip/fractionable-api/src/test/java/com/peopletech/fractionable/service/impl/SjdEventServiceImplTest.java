package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.entity.SjdEventBO;
import com.peopletech.fractionable.repository.SjdEventRepository;
import com.peopletech.fractionable.util.CommonUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SjdEventServiceImplTest {

    @Mock
    private SjdEventRepository sjdEventRepository;

    @Mock
    private CommonUtil commonUtil;

    @InjectMocks
    private SjdEventServiceImpl sjdEventService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testAddEvent() {
        when(commonUtil.getSjdEventTypeId(anyString())).thenReturn(1);

        sjdEventService.addEvent(1, 2, "eventType", "description");

        verify(commonUtil, times(1)).getSjdEventTypeId("eventType");
        verify(sjdEventRepository, times(1)).save(any(SjdEventBO.class));
    }
    @Test
    public void testGetEventsForSjd() {
        List<SjdEventBO> mockEvents = new ArrayList<>();
        SjdEventBO event1 = new SjdEventBO();
        SjdEventBO event2 = new SjdEventBO();
        mockEvents.add(event1);
        mockEvents.add(event2);

        when(sjdEventRepository.findBySjdIdOrderByCreatedOnDesc(anyInt())).thenReturn(mockEvents);

        List<SjdEventBO> result = sjdEventService.getEventsForSjd(1);

        verify(sjdEventRepository, times(1)).findBySjdIdOrderByCreatedOnDesc(1);
        assertEquals(2, result.size());
        assertEquals(mockEvents, result);
    }
}