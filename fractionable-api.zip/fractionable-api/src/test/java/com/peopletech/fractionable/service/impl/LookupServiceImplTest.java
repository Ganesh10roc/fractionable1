package com.peopletech.fractionable.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.dto.LookupDto;
import com.peopletech.fractionable.entity.*;
import com.peopletech.fractionable.repository.*;
import com.peopletech.fractionable.util.LookupInfo;
import org.dozer.DozerBeanMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.repository.CrudRepository;

import java.lang.reflect.Field;
import java.util.*;

@ExtendWith(MockitoExtension.class)
public class LookupServiceImplTest {

    @Mock
    private QualificationRepository qualificationRepository;

    @Mock
    private JobTypeRepository jobTypeRepository;

    @Mock
    private CandidateEventRepository candidateEventRepository;

    @Mock
    private SkillsRepository skillsRepository;

    @Mock
    private CompanyRepository companyRepository;

    @Mock
    private PriorityRepository priorityRepository;

    @Mock
    private DozerBeanMapper mapper;

    @InjectMocks
    private LookupServiceImpl lookupService;

    private Map<LookupType, LookupInfo> lookupMap;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.initMocks(this);
        lookupService.initialize();
        lookupMap = new EnumMap<>(LookupType.class);
        Field field = LookupServiceImpl.class.getDeclaredField("lookupMap");
        field.setAccessible(true);
        field.set(lookupService, lookupMap);
        lookupMap.put(LookupType.QUALIFICATION, new LookupInfo<>(qualificationRepository, QualificationBO.class));
        lookupMap.put(LookupType.PRIORITY, new LookupInfo<>(priorityRepository, PriorityBO.class));
        lookupMap.put(LookupType.PAY_TYPE, new LookupInfo<>(priorityRepository, PayTypeBO.class));
        lookupMap.put(LookupType.JOB_TYPE, new LookupInfo<>(jobTypeRepository, JobTypeBO.class));
        lookupMap.put(LookupType.CANDIDATE_EVENT_TYPE, new LookupInfo<>(candidateEventRepository, CandidateEventBO.class));
    }

    @Test
    public void getLookupValues_Success() {
        LookupType lookupType = LookupType.QUALIFICATION;
        QualificationBO qualificationBO = new QualificationBO();
        List<QualificationBO> qualificationBOList = new ArrayList<>();
        qualificationBOList.add(qualificationBO);
        when(qualificationRepository.findAll()).thenReturn(qualificationBOList);
        when(mapper.map(qualificationBO, LookupDto.class)).thenReturn(new LookupDto());
        List<LookupDto> result = lookupService.getLookupValues(lookupType);
        assertEquals(1, result.size());
        verify(qualificationRepository, times(1)).findAll();
        verify(mapper, times(1)).map(qualificationBO, LookupDto.class);
    }

    @Test
    @DisplayName("should get all Lookup data with empty list")
    public void getLookupValues_NoData() {
        LookupType lookupType = LookupType.PRIORITY;
        when(priorityRepository.findAll()).thenReturn(new ArrayList<>());
        List<LookupDto> result = lookupService.getLookupValues(lookupType);
        assertEquals(0, result.size());
        verify(priorityRepository, times(1)).findAll();
        verify(mapper, times(0)).map(any(), any());
    }

    @Test
    @DisplayName("should clear all data cache")
    public void clearCache() {
        LookupType lookupType = LookupType.PAY_TYPE;
        lookupService.clearCache(lookupType);
    }

    @Test
    @DisplayName("should save lookup data and return success")
    public void saveLookupData_Success() {
        List<LookupDto> lookupData = new ArrayList<>();
        LookupDto lookupDto = new LookupDto();
        lookupData.add(lookupDto);
        CrudRepository<QualificationBO, Integer> mockRepo = mock(CrudRepository.class);
        when(mockRepo.saveAll(any())).thenReturn(Collections.emptyList());
        lookupMap.put(LookupType.QUALIFICATION, new LookupInfo<>(mockRepo, QualificationBO.class));
        List<LookupDto> result = lookupService.saveLookupData(lookupData, LookupType.QUALIFICATION);
        assertNotNull(result);
        assertEquals(0, result.size());
        verify(mockRepo, times(1)).saveAll(any());
    }

    @Test
    @DisplayName("should return all skills data in list")
    public void getSkills_Success() {
        SkillBO skillBO = new SkillBO();
        List<SkillBO> skillBOList = new ArrayList<>();
        skillBOList.add(skillBO);
        when(skillsRepository.findAllByOrderByNameAsc()).thenReturn(skillBOList);
        when(mapper.map(skillBO, LookupDto.class)).thenReturn(new LookupDto());
        List<LookupDto> result = lookupService.getSkills();
        assertEquals(1, result.size());
        verify(skillsRepository, times(1)).findAllByOrderByNameAsc();
        verify(mapper, times(1)).map(skillBO, LookupDto.class);
    }

    @Test
    @DisplayName("should get empty list data")
    public void getSkills_NoData() {
        when(skillsRepository.findAllByOrderByNameAsc()).thenReturn(new ArrayList<>());
        List<LookupDto> result = lookupService.getSkills();
        assertEquals(0, result.size());
        verify(skillsRepository, times(1)).findAllByOrderByNameAsc();
        verify(mapper, times(0)).map(any(), any());
    }

    @Test
    @DisplayName("should save all skills and return success")
    public void saveAllSkills_Success() {
        List<LookupDto> lookupData = new ArrayList<>();
        LookupDto skillLookupDto = new LookupDto();
        skillLookupDto.setId(1);
        skillLookupDto.setName("Java Programming");
        lookupData.add(skillLookupDto);
        SkillBO skillBO = new SkillBO();
        List<SkillBO> skillBOList = new ArrayList<>();
        skillBOList.add(skillBO);
        when(skillsRepository.saveAll(any())).thenReturn(skillBOList);
        when(mapper.map(skillLookupDto, SkillBO.class)).thenReturn(skillBO);
        List<SkillBO> result = lookupService.saveAllSkills(lookupData);
        assertEquals(1, result.size());
        verify(skillsRepository, times(1)).saveAll(any());
        verify(mapper, times(1)).map(skillLookupDto, SkillBO.class);
    }

    @Test
    @DisplayName("should delete id and return success ")
    public void deleteLookup_Success() {
        Integer id = 1;
        String lookupType = LookupType.COMPANY.toString();
        CompanyRepository mockCompanyRepository = mock(CompanyRepository.class);
        lookupMap.put(LookupType.COMPANY, new LookupInfo(mockCompanyRepository, CompanyBO.class));
        lookupService.deleteLookup(lookupType, id);
        verify(mockCompanyRepository, times(1)).deleteById(id);
    }

    @Test
    @DisplayName("should delete invalid lookup type id ")
    public void deleteLookup_InvalidType() {
        Integer id = 1;
        String lookupType = "INVALID_LOOKUP_TYPE";
        lookupService.deleteLookup(lookupType, id);
    }
}