package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.AppConstants;
import com.peopletech.fractionable.constants.CandidateEventType;
import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.constants.SjdStatusType;
import com.peopletech.fractionable.dto.*;
import com.peopletech.fractionable.dto.request.TagCandidateRequest;
import com.peopletech.fractionable.entity.*;
import com.peopletech.fractionable.entity.compoundkey.SjdCandidateInfoId;
import com.peopletech.fractionable.repository.*;
import com.peopletech.fractionable.service.CandidateEventService;
import com.peopletech.fractionable.service.LookupService;
import com.peopletech.fractionable.service.SjdEventService;
import com.peopletech.fractionable.service.SjdService;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.persistence.Tuple;
import org.dozer.DozerBeanMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SjdServiceImplTest {
    @Mock
    private SjdRepository sjdRepository;
    @Mock
    private SjdUserRepository sjdUserRepository;
    @Mock
    private SjdCandidateInfoRepository sjdCandidateInfoRepository;
    @Mock
    private SjdSkillMappingRepository sjdSkillMappingRepository;
    @Mock
    private SjdEventService sjdEventService;
    @Mock
    private SjdService sjdService;
    @Mock
    private CommonUtil commonUtil;
    @Mock
    private CandidateRepository candidateRepository;
    @Mock
    private LookupService lookupService;

    @Mock
    private CandidateEventService candidateEventService;

    @BeforeEach
    public void setup() {
        sjdService = new SjdServiceImpl(sjdRepository, sjdSkillMappingRepository, sjdUserRepository, new DozerBeanMapper(), sjdCandidateInfoRepository, sjdEventService, candidateRepository, commonUtil, candidateEventService, lookupService);
    }


    @Test
    @DisplayName("should get correct record using sjdId")
    public void checkGetSjd() {
        int sjdId = 1;
        SjdBO sjdBO = new SjdBO();
        sjdBO.setId(sjdId);

        List<SjdSkillMappingBO> skillMappings = new ArrayList<>();
        SjdSkillMappingBO skillMappingBO = new SjdSkillMappingBO();
        skillMappingBO.setSkill(new SkillBO());
        skillMappingBO.setMinExperience(2.2f);
        skillMappings.add(skillMappingBO);

        when(sjdRepository.findById(sjdId)).thenReturn(Optional.of(sjdBO));
        when(sjdSkillMappingRepository.findAllBySjdId(sjdId)).thenReturn(skillMappings);

        SjdDto expectedSjdDto = new SjdDto();
        expectedSjdDto.setId(sjdId);
        expectedSjdDto.setSkills(Collections.singletonList(new SjdSkillMappingDto()));
        SjdDto sjdDto = sjdService.getSjd(sjdId);


        assertEquals(expectedSjdDto.getId(), sjdDto.getId());
        assertEquals(expectedSjdDto.getSkills().size(), sjdDto.getSkills().size());

        verify(sjdRepository, times(1)).findById(sjdId);
        verify(sjdSkillMappingRepository, times(1)).findAllBySjdId(sjdId);
    }

    @Test
    @DisplayName("should have to add record in sjd correctly ")
    public void addSjdUsingUserId() {
        Integer userId = 123;
        SjdDto sjdDto = new SjdDto();

        LookupDto skillLookup = new LookupDto();
        skillLookup.setId(1);
        SjdSkillMappingDto sjdSkill = new SjdSkillMappingDto();
        sjdSkill.setSkill(skillLookup);
        sjdDto.setSkills(Collections.singletonList(sjdSkill));

        SjdBO savedSjdBO = new SjdBO();
        savedSjdBO.setId(1);

        when(sjdRepository.save(any(SjdBO.class))).thenReturn(savedSjdBO);

        SjdStatusBO mockSjdStatus = new SjdStatusBO();
        mockSjdStatus.setId(1);
        when(commonUtil.getSjdStatus(eq(SjdStatusType.NEW.getType()))).thenReturn(mockSjdStatus);

        SjdDto addedSjd = sjdService.addSjd(sjdDto, userId);


        assertEquals(savedSjdBO.getId(), addedSjd.getId());

        verify(sjdRepository, times(1)).save(any(SjdBO.class));
        verify(sjdSkillMappingRepository, times(1)).saveAll(anyList());
        verify(sjdEventService, times(1)).addEvent(eq(savedSjdBO.getId()), eq(userId), eq(AppConstants.SjdEventTypes.SJD_CREATED.name()), anyString());
    }

    @Test
    @DisplayName("Should have to update when id is present ")
    public void testUpdateSdjStatusChange() {
        SjdDto sjdDto = new SjdDto();
        sjdDto.setId(1);
        sjdDto.setSjdStatusId(2);
        sjdDto.setSkills(new ArrayList<>());
        sjdDto.setHiringTeam(new ArrayList<>());
        Integer userId = 123;

        SjdBO existingSjd = new SjdBO();
        existingSjd.setId(1);
        existingSjd.setSjdStatus(new SjdStatusBO());

        SjdBO updatedSjd = new SjdBO();
        updatedSjd.setId(1);


        when(sjdRepository.findById(sjdDto.getId())).thenReturn(Optional.of(existingSjd));
        when(sjdRepository.save(existingSjd)).thenReturn(updatedSjd);

        when(commonUtil.getNameFromId(eq(sjdDto.getSjdStatusId()), eq(LookupType.SJD_STATUS))).thenReturn("NEW_STATUS");

        List<SjdSkillMappingDto> skills = new ArrayList<>();

        sjdDto.setSkills(skills);

        List<UserDetailsDto> hiringTeam = new ArrayList<>();
        sjdDto.setHiringTeam(hiringTeam);

        sjdService.updateSjd(sjdDto, userId);

        verify(sjdRepository, times(1)).findById(sjdDto.getId());
        verify(sjdRepository, times(1)).save(existingSjd);
        verify(sjdEventService, times(1)).addEvent(eq(existingSjd.getId()), eq(userId), eq(AppConstants.SjdEventTypes.SJD_STATUS_CHANGED.name()), eq("NEW_STATUS"));
    }


    @Test
    @DisplayName("Should throw exception when id is not present")
    public void testUpdateSdjStatusChangeIdNotPresent() {
        int sjdId = 1;
        int userId = 123;
        SjdDto sjdDto = new SjdDto();
        sjdDto.setId(sjdId);
        sjdDto.setSjdStatusId(2);
        sjdDto.setSkills(new ArrayList<>());
        sjdDto.setHiringTeam(new ArrayList<>());
        when(sjdRepository.findById(sjdDto.getId())).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> {
            sjdService.updateSjd(sjdDto, userId);
        });

        verify(sjdRepository, times(1)).findById(sjdDto.getId());
        verify(sjdRepository, never()).save(any());
        verify(sjdEventService, never()).addEvent(anyInt(), anyInt(), anyString(), anyString());
    }


    @Test
    @DisplayName("should have to update event and skill to the sjd")
    public void updateSjdDetailsUpdate() {
        SjdDto sjdDto = new SjdDto();
        sjdDto.setId(1);
        Integer userId = 123;

        SjdBO existingSjd = new SjdBO();
        existingSjd.setId(1);

        when(sjdRepository.findById(sjdDto.getId())).thenReturn(Optional.of(existingSjd));
        when(sjdRepository.save(any())).thenReturn(existingSjd);

        sjdService.updateSjd(sjdDto, userId);

        verify(sjdRepository, times(1)).findById(sjdDto.getId());
        verify(sjdRepository, times(1)).save(any(SjdBO.class));
        verify(sjdEventService, times(1)).addEvent(eq(existingSjd.getId()), eq(userId), eq(AppConstants.SjdEventTypes.SJD_DETAILS_UPDATED.name()), anyString());
    }


    @Test
    @DisplayName("Should correctly add total candidates to Sjd list")
    public void testAddTotalCandidatesToSjd() throws Exception {
        List<SjdDto> sjdList = new ArrayList<>();

        SjdDto sjd1 = new SjdDto();
        sjd1.setId(1);

        SjdDto sjd2 = new SjdDto();
        sjd2.setId(2);

        sjdList.add(sjd1);
        sjdList.add(sjd2);

        Tuple tuple1 = mock(Tuple.class);
        when(tuple1.get(0, Integer.class)).thenReturn(1);
        when(tuple1.get(1, Long.class)).thenReturn(5L);

        Tuple tuple2 = mock(Tuple.class);
        when(tuple2.get(0, Integer.class)).thenReturn(2);
        when(tuple2.get(1, Long.class)).thenReturn(10L);

        List<Tuple> tuples = Arrays.asList(tuple1, tuple2);

        when(sjdCandidateInfoRepository.getCandidatesFromSjdList(anyList())).thenReturn(tuples);

        Method privateMethod = SjdServiceImpl.class.getDeclaredMethod("addTotalCandidatesToSjd", List.class);
        privateMethod.setAccessible(true);
        List<SjdDto> result = (List<SjdDto>) privateMethod.invoke(sjdService, sjdList);

        assertEquals(2, result.size());
        assertEquals(5, result.get(0).getTotalCandidates());
        assertEquals(10, result.get(1).getTotalCandidates());
    }


    @Test
    @DisplayName("should get all sjd details properly")
    public void getAllSjdForUser() {
        Integer userId = 123;
        List<SjdUserBO> sjdUserBOList = new ArrayList<>();

        SjdBO sjdBO = new SjdBO();
        sjdBO.setId(1);

        when(sjdUserRepository.findAllByUserId(eq(userId))).thenReturn(sjdUserBOList);

        List<SjdDto> result = sjdService.getAllSjd(userId);

        assertNotNull(result);
    }

    @Test
    @DisplayName("should check the candidate id present then perform the operation")
    public void tagCandidateToSjdWithMissingCandidateId() {
        TagCandidateRequest request = new TagCandidateRequest();
        request.setResumeId("resume123");
        request.setSjdId(456);
        CandidateBO candidate = new CandidateBO();
        candidate.setId(123);

        when(candidateRepository.findByResumeId(eq(request.getResumeId()))).thenReturn(Optional.of(candidate));
        when(sjdCandidateInfoRepository.findBySjdId(eq(request.getSjdId()))).thenReturn(new ArrayList<>());

        CandidateEventTypeBO eventTypeDto = new CandidateEventTypeBO();
        when(commonUtil.getCandidateEventTypeId(anyString())).thenReturn(eventTypeDto);

        sjdService.tagCandidateToSjd(request, 1);
    }

    @Test
    @DisplayName("Should have to add  candidate to candidateBo")
    public void tagCandidateAddUsingCandidateId() {

        TagCandidateRequest request = new TagCandidateRequest();
        request.setResumeId("resume123");
        request.setSjdId(456);
        CandidateBO candidate = new CandidateBO();
        candidate.setId(123);

        when(candidateRepository.findByResumeId(eq(request.getResumeId()))).thenReturn(Optional.of(candidate));
        when(sjdCandidateInfoRepository.findBySjdId(eq(request.getSjdId()))).thenReturn(new ArrayList<>());

        CandidateEventTypeBO eventTypeDto = new CandidateEventTypeBO();
        when(commonUtil.getCandidateEventTypeId(anyString())).thenReturn(eventTypeDto);


        doNothing().when(sjdEventService).addEvent(anyInt(), anyInt(), anyString(), anyString());

        sjdService.tagCandidateToSjd(request, 1);

        verify(candidateRepository, times(1)).findByResumeId(eq(request.getResumeId()));
        verify(sjdCandidateInfoRepository, times(1)).findBySjdId(eq(request.getSjdId()));
        verify(commonUtil, times(1)).getCandidateEventTypeId(anyString());
        verify(sjdEventService, times(1)).addEvent(anyInt(), anyInt(), anyString(), anyString());
    }

    @Test
    @DisplayName("Should have to delete correctly the untagged candidate")
    public void unTagCandidateFromSjd() {
        SjdCandidateInfoDto request = new SjdCandidateInfoDto();
        request.setSjdId(123);
        request.setCandidateId(456);

        CandidateEventTypeBO eventTypeDto = new CandidateEventTypeBO(1, CandidateEventType.CANDIDATE_UNTAGGED_FROM_SJD.name());
        when(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_UNTAGGED_FROM_SJD.name())).thenReturn(eventTypeDto);

        sjdService.unTagCandidateFromSjd(request, 1);

        verify(sjdCandidateInfoRepository, times(1)).deleteById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()));

        verify(candidateEventService, times(1)).addEvent(any(CandidateEventDto.class), eq(1));

        verify(sjdEventService, times(1)).addEvent(request.getSjdId(), 1, AppConstants.SjdEventTypes.CANDIDATE_REMOVED.name(), String.valueOf(request.getCandidateId()));

        verify(commonUtil, times(1)).getCandidateEventTypeId(eq(CandidateEventType.CANDIDATE_UNTAGGED_FROM_SJD.name()));
    }
}
