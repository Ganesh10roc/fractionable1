package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.dto.NotificationDto;
import com.peopletech.fractionable.entity.NotificationBO;
import com.peopletech.fractionable.repository.NotificationRepository;
import com.peopletech.fractionable.service.NotificationService;
import com.peopletech.fractionable.util.CommonUtil;
import org.dozer.DozerBeanMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class NotificationServiceImplTest {
    @Mock
    private NotificationRepository notificationRepository;

    private NotificationService notificationService;

    @BeforeEach
    public void setUp(){
        DozerBeanMapper mapper = new DozerBeanMapper();
        notificationService = new NotificationServiceImpl(notificationRepository,new CommonUtil(new LookupServiceImpl(),mapper),mapper);
    }

    @Test
    @DisplayName("SaveNotification method should return Id.")
    public void saveNotificationMethodReturnsId(){
        Date date = getCurrentDateByAddingTenMinutes();
        NotificationDto notificationDto = NotificationDto.builder().id(10).startDate(date).endDate(date).build();
        NotificationBO notificationBO = NotificationBO.builder().id(10).build();

        when(notificationRepository.save(any(NotificationBO.class))).thenReturn(notificationBO);

        assertEquals(10,notificationService.saveNotification(notificationDto));
    }
    @Test
    @DisplayName("SaveNotification method with invalid start date should throw IllegalArgument Exception.")
    public void InvalidStartDateThrowsIllegalArgumentException() throws ParseException {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        Date startDate = formatter.parse("2023-06-01T00:00:00+0530");

        NotificationDto notificationDto = NotificationDto.builder().id(10).startDate(startDate).endDate(new Date()).build();

        assertThrowsExactly(IllegalArgumentException.class,()->notificationService.saveNotification(notificationDto));
    }

    @Test
    @DisplayName("SaveNotification method with invalid end date should throw IllegalArgument Exception.")
    public void InvalidEndDateThrowsIllegalArgumentException() throws ParseException {
        Date date = getCurrentDateByAddingTenMinutes();

        NotificationDto notificationDto = NotificationDto.builder().id(10).startDate(date).endDate(new Date()).build();

        assertThrowsExactly(IllegalArgumentException.class,()->notificationService.saveNotification(notificationDto));
    }

    @Test
    @DisplayName("getAllNotification method should return list with size 2")
    public void getAllNotificationMethodReturnsList(){
        NotificationBO BO1 = NotificationBO.builder().id(1).build();
        NotificationBO BO2 = NotificationBO.builder().id(2).build();

        when(notificationRepository.findAllNotificationsByExpiryDate()).thenReturn(List.of(BO1,BO2));

        assertEquals(2,notificationService.getAllNotifications().size());
    }
    private Date getCurrentDateByAddingTenMinutes(){
        LocalDateTime dateTime = LocalDateTime.now().plus(Duration.of(10, ChronoUnit.MINUTES));
        return Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant());
    }
}
