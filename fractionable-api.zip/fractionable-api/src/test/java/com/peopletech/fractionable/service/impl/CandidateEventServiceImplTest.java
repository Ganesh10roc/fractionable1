package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.dto.CandidateEventDto;
import com.peopletech.fractionable.entity.CandidateEventBO;
import com.peopletech.fractionable.entity.UserDetailsBO;
import com.peopletech.fractionable.repository.CandidateEventRepository;
import org.dozer.DozerBeanMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;



import java.util.Date;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;



public class CandidateEventServiceImplTest {

    @Mock
    private DozerBeanMapper mapper;
    @Mock
    private CandidateEventDto candidateEventDto;
    @Mock
    private CandidateEventBO candidateEventBO;

    @Mock
    private CandidateEventRepository candidateEventRepository;

    @InjectMocks
    private CandidateEventServiceImpl candidateEventService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    @Test
    public void testAddEvent() {
        Integer userId = 1;
        candidateEventDto = new CandidateEventDto();
        candidateEventBO = new CandidateEventBO();
        when(mapper.map(candidateEventDto, CandidateEventBO.class)).thenReturn(candidateEventBO);
        when(candidateEventRepository.save(candidateEventBO)).thenReturn(candidateEventBO);
        Integer eventId = candidateEventService.addEvent(candidateEventDto, userId);
        verify(mapper, times(1)).map(candidateEventDto, CandidateEventBO.class);
        verify(candidateEventRepository, times(1)).save(candidateEventBO);
        assertEquals(candidateEventBO.getId(), eventId);
    }
}