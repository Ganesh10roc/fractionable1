package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.dto.UserDetailsDto;
import com.peopletech.fractionable.entity.UserDetailsBO;
import com.peopletech.fractionable.entity.UserLeadBO;
import com.peopletech.fractionable.repository.MyTeamRepository;
import org.dozer.DozerBeanMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class MyTeamServiceImplTest {
    @Mock
    private MyTeamRepository myTeamRepository;
    @Mock
    private DozerBeanMapper mapper;
    @InjectMocks
    private MyTeamServiceImpl myTeamService;

    @Test
    @DisplayName("should add team members correctly")
    public void addMyTeamTest() {
        List<Integer> userList = Arrays.asList(1, 2, 3);
        Integer leadId = 4;

        List<UserLeadBO> expectedList = userList.stream()
                .map(item -> UserLeadBO.builder()
                        .lead(UserDetailsBO.builder().id(leadId).build())
                        .user(UserDetailsBO.builder().id(item).build())
                        .build())
                .collect(Collectors.toList());

        when(myTeamRepository.saveAll(expectedList)).thenReturn(expectedList);
        myTeamService.addMyTeam(userList, leadId);
        verify(myTeamRepository).saveAll(expectedList);
    }

    @Test
    @DisplayName("should get team members correctly")
    public void getMyTeamTest() {
        Integer leadId = 5;

        UserLeadBO userLead1 = new UserLeadBO();
        userLead1.setUser(new UserDetailsBO());
        UserLeadBO userLead2 = new UserLeadBO();
        userLead2.setUser(new UserDetailsBO());

        List<UserLeadBO> userLeadBOS = Arrays.asList(userLead1, userLead2);
        when(myTeamRepository.findByLeadId(leadId)).thenReturn(userLeadBOS);

        List<UserDetailsDto> result = myTeamService.getMyTeam(leadId);
        assertEquals(2, result.size());
    }

    @Test
    @DisplayName("should remove team member correctly")
    public void removeFromMyTeamTest() {
        Integer userId = 1;
        Integer leadId = 10;

        myTeamService.removeFromMyTeam(userId, leadId);
        verify(myTeamRepository).delete(
                UserLeadBO.builder()
                        .user(UserDetailsBO.builder().id(userId).build())
                        .lead(UserDetailsBO.builder().id(leadId).build())
                        .build()
        );
    }

}

