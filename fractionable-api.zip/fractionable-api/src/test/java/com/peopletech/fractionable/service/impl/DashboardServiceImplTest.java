package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.CandidateStatusType;
import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.dto.*;
import com.peopletech.fractionable.repository.*;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.persistence.Tuple;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.math.BigDecimal;
import java.text.ParseException;
import java.time.Instant;
import java.util.Collections;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DashboardServiceImplTest {

    @InjectMocks
    private DashboardServiceImpl dashboardServiceImp;

    @Mock
    private CandidateRepository candidateRepository;

    @Mock
    private CandidateInterviewRepository candidateInterviewRepository;

    @Mock
    private SjdRepository sjdRepository;

    @Mock
    private SjdUserRepository sjdUserRepository;

    @Mock
    private SjdCandidateInfoRepository sjdCandidateInfoRepository;

    @Mock
    private UserDetailsRepository userDetailsRepository;

    @Mock
    private CommonUtil commonUtil;


    @Test
    public void testGetQCRatedCandidates() {
        List<Tuple> mockSjdList = Arrays.asList(mock(Tuple.class), mock(Tuple.class));
        when(sjdUserRepository.findAllSjdIdByUserId(anyInt())).thenReturn(mockSjdList);
        List<Tuple> mockQcRatedCandidates = Arrays.asList(mock(Tuple.class), mock(Tuple.class));
        when(commonUtil.getIdFromName(
                CandidateStatusType.QC_RATED.getType(), LookupType.CANDIDATE_STATUS)).thenReturn(123);
        when(sjdCandidateInfoRepository.getQCRatedCandidates(
                anyInt(), anyList())).thenReturn(mockQcRatedCandidates);
        List<QCRatedCandidatesReportDto> result = dashboardServiceImp.getQCRatedCandidates(anyInt());
        assertEquals(2, result.size());
        verify(sjdCandidateInfoRepository,times(1)).getQCRatedCandidates(anyInt(), anyList());
        verify(commonUtil,times(1)).getIdFromName(CandidateStatusType.QC_RATED.getType(),LookupType.CANDIDATE_STATUS);
        verify(sjdCandidateInfoRepository,times(1)).getQCRatedCandidates(
                anyInt(), anyList());
    }


    @Test
    public void testGetQCRatedCandidatesWithNullValues(){
        when(sjdRepository.findAllSjdId()).thenReturn(new ArrayList<>());
        List<QCRatedCandidatesReportDto> result= dashboardServiceImp.getQCRatedCandidates(null);
        assertTrue(result.isEmpty());
        verify(sjdRepository,times(1)).findAllSjdId();
    }


    @Test
    public void testGetActiveInterviews(){
        Tuple mockTuple=mock(Tuple.class);
        when(mockTuple.get(0,Integer.class)).thenReturn(3);
        Instant startTime = Instant.parse("2023-08-17T12:34:56Z");
        Instant endTime = Instant.parse("2023-08-18T12:34:56Z");
        List<Tuple> mockSjdList=List.of(mockTuple);
        when(sjdUserRepository.findAllSjdIdByUserId(anyInt())).thenReturn(mockSjdList);
        Tuple mockCandidates=mock(Tuple.class);
        when(mockCandidates.get(0,Integer.class)).thenReturn(8);
        when(mockCandidates.get(1,String.class)).thenReturn("James");
        when(mockCandidates.get(2,Integer.class)).thenReturn(3);
        when(mockCandidates.get(3,String.class)).thenReturn("Testing");
        when(mockCandidates.get(4,String.class)).thenReturn("level-2");
        when(mockCandidates.get(5,Integer.class)).thenReturn(74);
        when(mockCandidates.get(6,String.class)).thenReturn("Evaluator1");
        when(mockCandidates.get(7,Instant.class)).thenReturn(startTime);
        when(mockCandidates.get(8,Instant.class)).thenReturn(endTime);
        when(mockCandidates.get(9,Integer.class)).thenReturn(75);
        List<Tuple> mockQcRatedCandidates= List.of(mockCandidates);
        when(candidateInterviewRepository.getActiveInterviews(anyList())).thenReturn(mockQcRatedCandidates);
        Tuple mockUNames=mock(Tuple.class);
        when(mockUNames.get(0,Integer.class)).thenReturn(75);
        when(mockUNames.get(1,String.class)).thenReturn("User1");
        List<Tuple> mockUserNames=List.of(mockUNames);
        when(userDetailsRepository.getUserNameFromId(anyList())).thenReturn(mockUserNames);
        List<InterviewReportDto> result=dashboardServiceImp.getActiveInterviews(anyInt());

        assertEquals(1,result.size());
        assertEquals("James",result.get(0).getCandidateName());
        verify(sjdUserRepository,times(1)).findAllSjdIdByUserId(anyInt());
        verify(candidateInterviewRepository,times(1)).getActiveInterviews(anyList());
        verify(userDetailsRepository,times(1)).getUserNameFromId(anyList());
    }


    @Test
    public void testGetActiveInterviewsWithNullUserId(){
        when(sjdRepository.findAllSjdId()).thenReturn(new ArrayList<>());
        List<InterviewReportDto> result= dashboardServiceImp.getActiveInterviews(null);
        assertTrue(result.isEmpty());
        verify(sjdRepository,times(1)).findAllSjdId();
    }


    @Test
    public void testGetCandidateCountByStatus()  throws ParseException{
        Tuple mockTuple=mock(Tuple.class);
        when(mockTuple.get(0,Integer.class)).thenReturn(3);
        List<Tuple> mockSjdList=List.of(mockTuple);
        when(sjdUserRepository.findAllSjdIdByUserId(anyInt())).thenReturn(mockSjdList);
        Tuple mockCount=mock(Tuple.class);
        when(mockCount.get(0,String.class)).thenReturn("Offer_Letter_Released");
        when(mockCount.get(1,Long.class)).thenReturn(10L);
        List<Tuple> mockCandidateCount=List.of(mockCount);
        when(candidateRepository.filterCandidateCountByStatus(anyList(),any(Date.class),any(Date.class))).thenReturn(mockCandidateCount);
        Map<String, Long> result=dashboardServiceImp.getCandidateCountByStatus(anyInt(),"2023-08-17T12:34:56+0530","2023-08-18T12:34:56+0530");

        assertEquals(1,result.size());
        assertEquals(10L,result.get("Offer_Letter_Released"));
        verify(sjdUserRepository,times(1)).findAllSjdIdByUserId(anyInt());
        verify(candidateRepository,times(1)).filterCandidateCountByStatus(anyList(),any(Date.class),any(Date.class));
    }


    @Test
    public void testGetCandidateCountByStatusWithNullDates()  throws ParseException{
        Tuple mockTuple=mock(Tuple.class);
        when(mockTuple.get(0,Integer.class)).thenReturn(3);
        List<Tuple> mockSjdList=List.of(mockTuple);
        when(sjdUserRepository.findAllSjdIdByUserId(anyInt())).thenReturn(mockSjdList);
        Tuple mockCount=mock(Tuple.class);
        when(mockCount.get(0,String.class)).thenReturn("Joining_Letter_Released");
        when(mockCount.get(1,Long.class)).thenReturn(10L);
        List<Tuple> mockCandidateCount=List.of(mockCount);
        when( candidateRepository.getCandidateCountByStatus(anyList())).thenReturn(mockCandidateCount);
        Map<String, Long> result=dashboardServiceImp.getCandidateCountByStatus(anyInt(),null,null);

        assertEquals(1,result.size());
        assertEquals(10L,result.get("Joining_Letter_Released"));
        verify(sjdUserRepository).findAllSjdIdByUserId(anyInt());
        verify(candidateRepository,times(1)).getCandidateCountByStatus(anyList());
    }


    @Test
    public void testGetCandidateCountByStatusWithNullUserId()  throws ParseException{
        when(sjdRepository.findAllSjdId()).thenReturn(new ArrayList<>());
        Map<String, Long> result=dashboardServiceImp.getCandidateCountByStatus(null,"2023-08-17T12:34:56+0530","2023-08-18T12:34:56+0530");
        assertTrue(result.isEmpty());
        verify(sjdRepository,times(1)).findAllSjdId();
    }


    @Test
    public void testGetMyInterviews() {
        Tuple mockTuple1 = mock(Tuple.class);
        when(mockTuple1.get(anyInt(), eq(Integer.class))).thenReturn(1);
        when(mockTuple1.get(anyInt(), eq(String.class))).thenReturn("John Doe");
        Instant mockStartDate = Instant.now();
        Instant mockEndDate = Instant.now();
        when(mockTuple1.get(5, Instant.class)).thenReturn(mockStartDate);
        when(mockTuple1.get(6, Instant.class)).thenReturn(mockEndDate);
        List<Tuple> mockInterviews = Collections.singletonList(mockTuple1);
        when(candidateInterviewRepository.getMyInterviews(anyInt())).thenReturn(mockInterviews);
        List<InterviewReportDto> result = dashboardServiceImp.getMyInterviews(anyInt()); //
        assertEquals(1, result.size());
        verify(candidateInterviewRepository, times(1)).getMyInterviews(anyInt());
    }


    @Test
    public void testGetMyInterviewsWithNullValues(){
        when(candidateInterviewRepository.getMyInterviews(anyInt())).thenReturn(new ArrayList<>());
        List<InterviewReportDto> result= dashboardServiceImp.getMyInterviews(anyInt());
        assertTrue(result.isEmpty());
        verify(candidateInterviewRepository,times(1)).getMyInterviews(anyInt());
    }


    @Test
    public void testGetCandidateCountBySourceChannel() {
        Tuple countTuple=mock(Tuple.class);
        when(countTuple.get(0,Integer.class)).thenReturn(1);
        when(countTuple.get(1,Long.class)).thenReturn(10L);
        List<Tuple> mock1tuple1=List.of(countTuple);
        when(candidateRepository.getCandidateCountBySourceChannel()).thenReturn(mock1tuple1);
        Map<Integer, Long> result=dashboardServiceImp.getCandidateCountBySourceChannel();
        assertEquals(1,result.size());
        assertEquals(10L,result.get(1));
        verify(candidateRepository,times(1)).getCandidateCountBySourceChannel();
    }


    @Test
    public void testGetCandidateCountBySourceChannelWithNull() {
        when(candidateRepository.getCandidateCountBySourceChannel()).thenReturn(new ArrayList<>());
        Map<Integer, Long> result = dashboardServiceImp.getCandidateCountBySourceChannel();
        assertTrue(result.isEmpty());
        verify(candidateRepository,times(1)).getCandidateCountBySourceChannel();
    }


    @Test
    public void testGetSjdCountByStatus() {
        Tuple sjdTuple = mock(Tuple.class);
        when(sjdTuple.get(0, Integer.class)).thenReturn(1);
        Tuple candidateCountTuple = mock(Tuple.class);
        when(candidateCountTuple.get(0, String.class)).thenReturn("Status 1");
        when(candidateCountTuple.get(1, Long.class)).thenReturn(10L);
        List<Tuple> candidateCountList = List.of(candidateCountTuple);
        when(sjdUserRepository.findAllSjdIdByUserId(anyInt())).thenReturn(List.of(sjdTuple));
        when(sjdRepository.getSjdCountByStatus(anyList())).thenReturn(candidateCountList);
        Map<String, Long> result = dashboardServiceImp.getSjdCountByStatus(anyInt());
        // Assertions
        assertEquals(1, result.size());
        assertEquals(10L, result.get("Status 1"));
        verify(sjdUserRepository,times(1)).findAllSjdIdByUserId(anyInt());
        verify(sjdRepository,times(1)).getSjdCountByStatus(anyList());
    }


    @Test
    public void testGetSjdCountByStatusWithNullUser(){
        when(sjdRepository.findAllSjdId()).thenReturn(new ArrayList<>());
        Map<String, Long> result= dashboardServiceImp.getSjdCountByStatus(null);
        assertTrue(result.isEmpty());
        verify(sjdRepository,times(1)).findAllSjdId();
    }


    @Test
    public void testGetAuditCandidates() throws ParseException {
        Tuple mockTuple = mock(Tuple.class);
        Integer sjdId = 456;
        String sjdName = "Software Engineer";
        Integer candidateId = 123;
        String candidateName = "John Doe";
        Integer recruiterId = 789;
        String recruiterName = "Jane Smith";
        Instant created_on = Instant.parse("2023-08-17T12:34:56Z");
        Integer client_id = 10;
        Integer operations_id = 100;

        when(mockTuple.get(0, Integer.class)).thenReturn(sjdId);
        when(mockTuple.get(1, String.class)).thenReturn(sjdName);
        when(mockTuple.get(2, Integer.class)).thenReturn(candidateId);
        when(mockTuple.get(3, String.class)).thenReturn(candidateName);
        when(mockTuple.get(4, Integer.class)).thenReturn(recruiterId);
        when(mockTuple.get(5, String.class)).thenReturn(recruiterName);
        when(mockTuple.get(6, Instant.class)).thenReturn(created_on);
        when(mockTuple.get(7, Integer.class)).thenReturn(client_id);
        when(mockTuple.get(8, Integer.class)).thenReturn(operations_id);

        List<Tuple> mockAuditCandidates = Arrays.asList(mockTuple);

        String a = "2023-08-16T00:00:00+0530";
        String b = "2023-08-18T00:00:00+0530";
        when(sjdCandidateInfoRepository.filterAuditCandidates(any(Date.class),any(Date.class))).thenReturn(mockAuditCandidates);
        List<AuditCandidatesReportDto> result = dashboardServiceImp.getAuditCandidates(a, b);

        assertEquals(1, result.size());
        assertEquals(sjdId,result.get(0).getSjdId());
        verify(sjdCandidateInfoRepository,times(1)).filterAuditCandidates(any(Date.class),any(Date.class));
    }


    @Test
    public void testGetAuditCandidatesWithDateRange() throws ParseException {
        Tuple mockTuple = mock(Tuple.class);
        Integer sjdId = 456;
        String sjdName = "Software Engineer";
        Integer candidateId = 123;
        String candidateName = "John Doe";
        Integer recruiterId = 789;
        String recruiterName = "Jane Smith";
        Instant created_on = Instant.parse("2023-08-17T12:34:56Z");
        Integer client_id = 10;
        Integer operations_id = 100;

        when(mockTuple.get(0, Integer.class)).thenReturn(sjdId);
        when(mockTuple.get(1, String.class)).thenReturn(sjdName);
        when(mockTuple.get(2, Integer.class)).thenReturn(candidateId);
        when(mockTuple.get(3, String.class)).thenReturn(candidateName);
        when(mockTuple.get(4, Integer.class)).thenReturn(recruiterId);
        when(mockTuple.get(5, String.class)).thenReturn(recruiterName);
        when(mockTuple.get(6, Instant.class)).thenReturn(created_on);
        when(mockTuple.get(7, Integer.class)).thenReturn(client_id);
        when(mockTuple.get(8, Integer.class)).thenReturn(operations_id);

        List<Tuple> mockAuditCandidates = List.of(mockTuple);
        when(sjdCandidateInfoRepository.findAuditCandidates())
                .thenReturn(mockAuditCandidates);
        List<AuditCandidatesReportDto> result = dashboardServiceImp.getAuditCandidates(null,null);
        assertEquals(1, result.size());
        assertEquals(sjdId,result.get(0).getSjdId());
        assertEquals(sjdName,result.get(0).getSjdName());
        verify(sjdCandidateInfoRepository,times(1)).findAuditCandidates();
    }


    @Test
    public void testGetSourcingTrends(){
        Instant audit_date = Instant.parse("2023-08-19T12:34:56Z");
        Instant created_on = Instant.parse("2023-08-17T12:34:56Z");
        Tuple mockAudit=mock(Tuple.class);
        when(mockAudit.get(0, java.sql.Date.class)).thenReturn(new java.sql.Date(audit_date.toEpochMilli()));
        when(mockAudit.get(1,Long.class)).thenReturn(25L);
        Tuple mockSource=mock(Tuple.class);
        when(mockSource.get(0, java.sql.Date.class)).thenReturn(new java.sql.Date(created_on.toEpochMilli()));
        when(mockSource.get(1,Long.class)).thenReturn(35L);

        List<Tuple> mockAuditResult= List.of(mockAudit);
        List<Tuple> mockSourceResult= List.of(mockSource);

        when(sjdCandidateInfoRepository.getAuditTrends(anyInt())).thenReturn(mockAuditResult);
        when(sjdCandidateInfoRepository.getSourcingTrends(anyInt())).thenReturn(mockSourceResult);
        List<Map<String, Object>> result=dashboardServiceImp.getSourcingTrends(anyInt());
        assertEquals(1,result.size());
        verify(sjdCandidateInfoRepository,times(1)).getAuditTrends(anyInt());
        verify(sjdCandidateInfoRepository,times(1)).getSourcingTrends(anyInt());
    }


    @Test
    public void testGetSourcingTrendsWithNullCount(){
        when(sjdCandidateInfoRepository.getAuditTrends(null)).thenReturn(new ArrayList<>());
        List<Map<String, Object>> result=dashboardServiceImp.getSourcingTrends(null);
        assertTrue(result.isEmpty());
        verify(sjdCandidateInfoRepository,times(1)).getAuditTrends(null);
    }


    @Test
    public void testGetRatingTrends(){
        Instant created_on=Instant.parse("2023-08-19T12:34:56Z");
        BigDecimal qcRating = new BigDecimal("4.5");
        BigDecimal profile_Rating = new BigDecimal("3.5");
        Tuple mockResult=mock(Tuple.class);
        when(mockResult.get(0,java.sql.Date.class)).thenReturn(new java.sql.Date(created_on.toEpochMilli()));
        when(mockResult.get(1,BigDecimal.class)).thenReturn(qcRating);
        when(mockResult.get(2,BigDecimal.class)).thenReturn(profile_Rating);
        List<Tuple> mockRatingResult=List.of(mockResult);
        when(sjdCandidateInfoRepository.getRatingTrends(anyInt())).thenReturn(mockRatingResult);

        List<Map<String, Object>> result=dashboardServiceImp.getRatingTrends(anyInt());
        assertEquals(1,result.size());
        assertEquals("2023-08-19",result.get(0).get("date"));
        verify(sjdCandidateInfoRepository,times(1)).getRatingTrends(anyInt());
    }


    @Test
    public void testGetRatingTrendsWithNullCount(){
        when(sjdCandidateInfoRepository.getRatingTrends(null)).thenReturn(new ArrayList<>());
        List<Map<String, Object>> result=dashboardServiceImp.getRatingTrends(null);
        assertTrue(result.isEmpty());
        verify(sjdCandidateInfoRepository,times(1)).getRatingTrends(null);
    }


    @Test
    public void testGetRatingTrends1(){
        Instant created_on=Instant.parse("2023-08-19T12:34:56Z");
        BigDecimal qcRating =null;
        BigDecimal profile_Rating = new BigDecimal("3.5");
        Tuple mockResult=mock(Tuple.class);
        when(mockResult.get(0,java.sql.Date.class)).thenReturn(new java.sql.Date(created_on.toEpochMilli()));
        when(mockResult.get(1,BigDecimal.class)).thenReturn(qcRating);
        when(mockResult.get(2,BigDecimal.class)).thenReturn(profile_Rating);
        List<Tuple> mockRatingResult=List.of(mockResult);
        when(sjdCandidateInfoRepository.getRatingTrends(anyInt())).thenReturn(mockRatingResult);

        List<Map<String, Object>> result=dashboardServiceImp.getRatingTrends(anyInt());
        assertEquals(1,result.size());
        assertEquals("2023-08-19",result.get(0).get("date"));
        verify(sjdCandidateInfoRepository,times(1)).getRatingTrends(anyInt());
    }

}

