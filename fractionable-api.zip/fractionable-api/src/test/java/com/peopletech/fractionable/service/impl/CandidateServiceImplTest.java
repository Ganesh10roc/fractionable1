package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.CandidateDetailsType;
import com.peopletech.fractionable.constants.CandidateEventType;
import com.peopletech.fractionable.constants.CandidateStatusType;
import com.peopletech.fractionable.constants.InterviewResult;
import com.peopletech.fractionable.dto.*;
import com.peopletech.fractionable.dto.request.CandidateDetailsDeleteRequest;
import com.peopletech.fractionable.dto.request.CandidateRejectOrCallbackRequest;
import com.peopletech.fractionable.dto.request.TagCandidateRequest;
import com.peopletech.fractionable.entity.*;
import com.peopletech.fractionable.repository.*;
import com.peopletech.fractionable.service.CandidateEventService;
import com.peopletech.fractionable.service.LookupService;
import com.peopletech.fractionable.service.SjdService;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.transaction.Transactional;
import org.dozer.DozerBeanMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;
import org.springframework.data.jpa.domain.Specification;

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CandidateServiceImplTest {
    @InjectMocks
    private CandidateServiceImpl candidateService;

    @Mock
    private CandidateRepository candidateRepository;

    @Mock
    private LookupService lookupService;

    @Mock
    private CommonUtil commonUtil;

    @Mock
    private CandidateEventService candidateEventService;

    @Mock
    private SjdCandidateInfoRepository sjdCandidateInfoRepository;

    @Mock
    private CandidateDocumentRepository candidateDocumentRepository;

    @Mock
    private CandidateEmploymentRepository candidateEmploymentRepository;

    @Mock
    private CandidateEducationRepository candidateEducationRepository;

    @Mock
    private CandidateCertificationRepository candidateCertificationRepository;

    @Mock
    private CandidateInterviewRepository candidateInterviewRepository;

    @Mock
    private DozerBeanMapper mapper;

    @Mock
    private CandidateEventRepository candidateEventRepository;

    @Mock
    private SjdService sjdService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetCandidateById() {
        Integer candidateId = 1;
        Integer sjdId = 2;

        CandidateBO candidateBO = new CandidateBO();
        when(candidateRepository.findById(candidateId)).thenReturn(Optional.of(candidateBO));

        List<CandidateInterviewBO> candidateInterviewList = new ArrayList<>();
        when(candidateInterviewRepository.findBySjdIdAndCandidateId(sjdId, candidateId)).thenReturn(candidateInterviewList);

        List<CandidateEventBO> candidateEventList = new ArrayList<>();
        when(candidateEventRepository.findBySjdIdAndCandidateIdOrderByCreatedOnDesc(sjdId, candidateId)).thenReturn(candidateEventList);

        CandidateDto candidateDto = new CandidateDto();
        when(mapper.map(candidateBO, CandidateDto.class)).thenReturn(candidateDto);

        CandidateDto result = candidateService.getCandidateById(candidateId, sjdId);

        assertEquals(candidateDto, result);
        verify(candidateRepository, times(1)).findById(candidateId);
        verify(candidateInterviewRepository, times(1)).findBySjdIdAndCandidateId(sjdId, candidateId);
        verify(candidateEventRepository, times(1)).findBySjdIdAndCandidateIdOrderByCreatedOnDesc(sjdId, candidateId);
    }

    @Test
    public void testGetCandidateBySjdId() {
        Integer sjdId = 1;

        List<SjdCandidateInfoBO> mockCandidates = new ArrayList<>();
        SjdCandidateInfoBO candidateInfo1 = new SjdCandidateInfoBO();
        candidateInfo1.setCandidate(new CandidateBO());
        mockCandidates.add(candidateInfo1);
        SjdCandidateInfoBO candidateInfo2 = new SjdCandidateInfoBO();
        candidateInfo2.setCandidate(new CandidateBO());
        mockCandidates.add(candidateInfo2);

        when(sjdCandidateInfoRepository.findBySjdId(sjdId)).thenReturn(mockCandidates);

        CandidateDto mockCandidateDto1 = new CandidateDto();
        CandidateDto mockCandidateDto2 = new CandidateDto();

        when(mapper.map(candidateInfo1.getCandidate(), CandidateDto.class)).thenReturn(mockCandidateDto1);
        when(mapper.map(candidateInfo2.getCandidate(), CandidateDto.class)).thenReturn(mockCandidateDto2);

        List<CandidateDto> result = candidateService.getCandidateBySjdId(sjdId);

        assertEquals(mockCandidates.size(), result.size());
        assertEquals(mockCandidateDto1, result.get(0));
        assertEquals(mockCandidateDto2, result.get(1));

        verify(sjdCandidateInfoRepository, times(1)).findBySjdId(sjdId);
        verify(mapper, times(mockCandidates.size())).map(any(CandidateBO.class), eq(CandidateDto.class));
    }

    @Test
    @DisplayName("should get team members correctly")
    public void getAllCandidatesTest() {
        List<CandidateBO> candidateBOList = new ArrayList<>();
        candidateBOList.add(new CandidateBO());
        candidateBOList.add(new CandidateBO());

        when(candidateRepository.findAll()).thenReturn(candidateBOList);

        List<CandidateDto> expectedDtos = candidateBOList.stream()
                .map(bo -> new CandidateDto())
                .collect(Collectors.toList());

        when(mapper.map(any(), eq(CandidateDto.class))).thenReturn(new CandidateDto());

        List<CandidateDto> result = candidateService.getAllCandidates();

        assertEquals(expectedDtos.size(), result.size());

        verify(candidateRepository, times(1)).findAll();
        verify(mapper, times(candidateBOList.size())).map(any(), eq(CandidateDto.class));
    }

    @Test
    void testSaveCandidate() {
        CandidateDto candidateDto = new CandidateDto();
        Integer sjdId = 123;
        Integer userId = 456;

        LookupDto skill1 = new LookupDto();
        skill1.setName("Java");

        LookupDto skill2 = new LookupDto();
        skill2.setName("Python");

        List<LookupDto> skills = new ArrayList<>();
        skills.add(skill1);
        skills.add(skill2);

        List<LookupDto> newSkillsList = new ArrayList<>();
        List<SkillBO> savedSkills = new ArrayList<>();
        CandidateBO savedCandidate = new CandidateBO();
        savedCandidate.setId(789);
        CandidateEventDto candidateEventDto = new CandidateEventDto();
        TagCandidateRequest tagCandidateRequest = new TagCandidateRequest(sjdId, savedCandidate.getId(), null);

        List<String> allSkills = new ArrayList<>();
        for (LookupDto skillDto : skills) {
            allSkills.add(skillDto.getName().toLowerCase());
        }

        List<SkillBO> existingSkills = new ArrayList<>();
        List<LookupDto> newSkills = new ArrayList<>();

        Mockito.when(lookupService.getSkills()).thenReturn(skills);

        CandidateBO candidateBO = new CandidateBO();
        when(mapper.map(candidateDto, CandidateBO.class)).thenReturn(candidateBO);

        when(lookupService.saveAllSkills(newSkillsList)).thenReturn(savedSkills);
        when(candidateRepository.save(candidateBO)).thenReturn(savedCandidate);
        when(candidateEventService.addEvent(any(), eq(userId))).thenReturn(1);

        CandidateEventTypeBO eventTypeBO = new CandidateEventTypeBO();
        when(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_CREATED.name())).thenReturn(eventTypeBO);

        doNothing().when(sjdService).tagCandidateToSjd(eq(tagCandidateRequest), eq(userId));

        candidateDto.getSkills().stream().forEach(s -> {
            if (allSkills.contains(s.getName().toLowerCase())) {
                existingSkills.add(mapper.map(s, SkillBO.class));
            } else {
                newSkills.add(s);
            }
        });

        Integer result = candidateService.saveCandidate(candidateDto, sjdId, userId);

        verify(candidateRepository, times(1)).save(candidateBO);
        verify(candidateEventService, times(1)).addEvent(any(), eq(userId));
        verify(sjdService, times(1)).tagCandidateToSjd(eq(tagCandidateRequest), eq(userId));
        assertEquals(savedCandidate.getId(), result);
    }

    @Test
    @Transactional
    public void testUpdateCandidate() {
        MockitoAnnotations.openMocks(this);

        Integer userId = 1;
        Integer sjdId = 2;
        Boolean isResumeUpdate = false;

        CandidateDto candidateDto = new CandidateDto();
        candidateDto.setId(1);

        CandidateBO existingCandidate = new CandidateBO();
        existingCandidate.setId(candidateDto.getId());
        when(candidateRepository.findById(anyInt())).thenReturn(Optional.of(existingCandidate));

        when(lookupService.getSkills()).thenReturn(new ArrayList<>()); // Adjust the returned list according to your needs
        when(commonUtil.getCandidateEventTypeId(anyString())).thenReturn(new CandidateEventTypeBO());
        when(candidateEventService.addEvent(any(), anyInt())).thenReturn(1); // Adjust the return value as needed

        when(candidateRepository.save(any())).thenReturn(existingCandidate);

        candidateService.updateCandidate(candidateDto, sjdId, userId, isResumeUpdate);

        verify(candidateRepository, times(1)).findById(anyInt());
        verify(candidateRepository, times(1)).save(any());
        verify(lookupService, times(1)).getSkills();
        verify(commonUtil, times(1)).getCandidateEventTypeId(anyString());
        verify(candidateEventService, times(1)).addEvent(Mockito.any(), eq(userId));

    }

    @Test
    public void testAddComments() {
        MockitoAnnotations.openMocks(this);

        Integer userId = 1;

        CandidateEventDto request = new CandidateEventDto();
        request.setSjdId(2);
        request.setCandidateId(3);
        request.setDescription("Some comments");

        CandidateEventTypeBO candidateEventTypeBO = new CandidateEventTypeBO();
        when(commonUtil.getCandidateEventTypeId(anyString())).thenReturn(candidateEventTypeBO);

        when(candidateEventService.addEvent(any(), anyInt())).thenReturn(1); // You can adjust the return value as needed

        Integer result = candidateService.addComments(request, userId);

        verify(commonUtil, times(1)).getCandidateEventTypeId(anyString());
        verify(candidateEventService, times(1)).addEvent(Mockito.any(), eq(userId));

        assertEquals(1, result.intValue());
    }

    @Test
    public void testRejectOrCallback() {
        CandidateRejectOrCallbackRequest request = new CandidateRejectOrCallbackRequest();
        request.setSjdId(9);
        request.setCandidateId(20);
        request.setType("Reject");
        request.setReason("Not a good fit");
        Integer userId = 30;

        SjdCandidateInfoBO mockInfo = new SjdCandidateInfoBO();
        mockInfo.setSjd(new SjdBO());
        mockInfo.setCandidate(new CandidateBO());
        when(sjdCandidateInfoRepository.findById(any())).thenReturn(Optional.of(mockInfo));

        CandidateStatusBO mockStatus = new CandidateStatusBO();
        when(commonUtil.getCandidateStatus(any())).thenReturn(mockStatus);

        CandidateEventTypeBO mockEventType = new CandidateEventTypeBO();
        when(commonUtil.getCandidateEventTypeId(any())).thenReturn(mockEventType);

        when(sjdCandidateInfoRepository.save(any())).thenReturn(mockInfo);

        candidateService.rejectOrCallback(request, userId);

        verify(sjdCandidateInfoRepository, times(1)).findById(any());
        verify(sjdCandidateInfoRepository, times(1)).save(any());
        verify(candidateEventService, times(1)).addEvent(any(), eq(userId));
    }

    @Test
    void testScheduleInterview_NullEvaluator() {
        CandidateInterviewDto request = new CandidateInterviewDto();
        Integer userId = 4;

        CandidateInterviewBO candidateInterview = new CandidateInterviewBO();
        SjdCandidateInfoBO info = new SjdCandidateInfoBO();

        lenient().when(candidateInterviewRepository.save(any(CandidateInterviewBO.class))).thenReturn(candidateInterview);
        lenient().when(sjdCandidateInfoRepository.findById(any())).thenReturn(java.util.Optional.of(info));
        lenient().when(commonUtil.getCandidateEventTypeId(any())).thenReturn(new CandidateEventTypeBO());

        assertThrows(NullPointerException.class, () -> {
            candidateService.scheduleInterview(request, userId, null);
        });

        verify(candidateEventService, never()).addEvent(any(CandidateEventDto.class), anyInt());
    }

    @Test
    void testUpdateInterviewDetails_NoEvaluator() {
        CandidateInterviewDto request = new CandidateInterviewDto();
        Integer userId = 4;
        Boolean isFeedback = true;

        CandidateInterviewBO candidateInterview = new CandidateInterviewBO();
        candidateInterview.setInterviewResult(InterviewResult.ON_HOLD.getType());

        when(candidateInterviewRepository.findById(any())).thenReturn(Optional.of(candidateInterview));

        assertThrows(NullPointerException.class, () -> {
            candidateService.updateInterviewDetails(request, userId, isFeedback, null);
        });
    }

    @Test
    void testUpdateCandidateStatusAfterInterview() throws Exception {
        MockitoAnnotations.openMocks(this);

        Integer userId = 1;

        CandidateInterviewBO selectedTechnicalInterview = new CandidateInterviewBO();
        selectedTechnicalInterview.setSjdId(2);
        selectedTechnicalInterview.setCandidateId(3);
        selectedTechnicalInterview.setInterviewLevel("Technical-1");
        selectedTechnicalInterview.setInterviewResult("Selected");

        SjdCandidateInfoBO sjdCandidateInfo = new SjdCandidateInfoBO();
        when(sjdCandidateInfoRepository.findById(any())).thenReturn(java.util.Optional.of(sjdCandidateInfo));

        Method method = CandidateServiceImpl.class.getDeclaredMethod(
                "updateCandidateStatusAfterInterview", CandidateInterviewBO.class, Integer.class);
        method.setAccessible(true);
        CandidateStatusType selectedStatus = (CandidateStatusType) method.invoke(candidateService, selectedTechnicalInterview, userId);

        verify(sjdCandidateInfoRepository, times(1)).findById(any());
        verify(sjdCandidateInfoRepository, times(1)).save(any());

        assertNotNull(selectedStatus);

        CandidateInterviewBO rejectedInterview = new CandidateInterviewBO();
        rejectedInterview.setSjdId(4);
        rejectedInterview.setCandidateId(5);
        rejectedInterview.setInterviewLevel("HR-1");
        rejectedInterview.setInterviewResult("Rejected");

        when(sjdCandidateInfoRepository.findById(any())).thenReturn(java.util.Optional.of(sjdCandidateInfo));

        CandidateStatusType rejectedStatus = (CandidateStatusType) method.invoke(candidateService, rejectedInterview, userId);

        verify(sjdCandidateInfoRepository, times(2)).findById(any());
        verify(sjdCandidateInfoRepository, times(2)).save(any());

        assertNotNull(rejectedStatus);

        CandidateInterviewBO selectedHrInterview = new CandidateInterviewBO();
        selectedHrInterview.setSjdId(6);
        selectedHrInterview.setCandidateId(7);
        selectedHrInterview.setInterviewLevel("HR-2");
        selectedHrInterview.setInterviewResult("Selected");

        when(sjdCandidateInfoRepository.findById(any())).thenReturn(java.util.Optional.of(sjdCandidateInfo));

        CandidateStatusType selectedHrStatus = (CandidateStatusType) method.invoke(candidateService, selectedHrInterview, userId);

        verify(sjdCandidateInfoRepository, times(3)).findById(any());
        verify(sjdCandidateInfoRepository, times(3)).save(any());

        assertNotNull(selectedHrStatus);
    }

    @Test
    public void testSaveInterviewRescheduleEvent() {
        MockitoAnnotations.openMocks(this);

        Integer userId = 1;
        Integer sjdId = 2;
        Integer candidateId = 3;

        Date startTime = new Date();
        Date endTime = new Date(startTime.getTime() + 3600000);

        CandidateInterviewDto request = new CandidateInterviewDto();
        request.setSjdId(sjdId);
        request.setCandidateId(candidateId);
        request.setStartTime(startTime);
        request.setEndTime(endTime);

        CandidateEventTypeBO eventTypeInfo = new CandidateEventTypeBO();
        eventTypeInfo.setId(1);
        when(commonUtil.getCandidateEventTypeId(CandidateEventType.INTERVIEW_RESCHEDULED.name())).thenReturn(eventTypeInfo);

        try {
            DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat timeFormatter = new SimpleDateFormat("hh:mm a");

            Method method = CandidateServiceImpl.class.getDeclaredMethod(
                    "saveInterviewRescheduleEvent", CandidateInterviewDto.class, Integer.class);
            method.setAccessible(true);
            method.invoke(candidateService, request, userId);

            String expectedDescription = dateFormatter.format(startTime)
                    .concat(" ")
                    .concat(timeFormatter.format(startTime))
                    .concat(" - ")
                    .concat(timeFormatter.format(endTime));

            CandidateEventDto expectedEventDto = CandidateEventDto.builder()
                    .sjdId(sjdId)
                    .candidateId(candidateId)
                    .eventTypeId(eventTypeInfo.getId())
                    .description(expectedDescription)
                    .build();

            verify(candidateEventService, times(1)).addEvent(eq(expectedEventDto), eq(userId));
        } catch (Exception e) {
            fail("Exception occurred: " + e.getMessage());
        }
    }

    @Test
    public void testSaveFeedbackAddedEvent() {
        Integer userId = 1;
        Integer eventTypeId = 1;

        CandidateInterviewDto request = new CandidateInterviewDto();
        request.setSjdId(2);
        request.setCandidateId(3);
        request.setFeedback("Some feedback");

        CandidateEventTypeBO eventTypeBO = new CandidateEventTypeBO();
        eventTypeBO.setId(eventTypeId);

        CandidateEventDto expectedEventDto = CandidateEventDto.builder()
                .sjdId(request.getSjdId())
                .candidateId(request.getCandidateId())
                .description(request.getFeedback())
                .eventTypeId(eventTypeId)
                .build();

        when(commonUtil.getCandidateEventTypeId(CandidateEventType.FEEDBACK_ADDED.name())).thenReturn(eventTypeBO);

        try {
            Method method = CandidateServiceImpl.class.getDeclaredMethod(
                    "saveFeedbackAddedEvent", CandidateInterviewDto.class, Integer.class);
            method.setAccessible(true);
            method.invoke(candidateService, request, userId);
        } catch (Exception e) {
            fail("Exception occurred: " + e.getMessage());
        }

        verify(commonUtil, times(1)).getCandidateEventTypeId(CandidateEventType.FEEDBACK_ADDED.name());
        verify(candidateEventService, times(1)).addEvent(eq(expectedEventDto), eq(userId));
    }


    @Test
    void testSaveStatusChangeEvent() throws Exception {
        MockitoAnnotations.openMocks(this);

        when(commonUtil.getCandidateEventTypeId(any()))
                .thenReturn(new CandidateEventTypeBO(123, "CANDIDATE_REJECTED"));

        CandidateInterviewDto request = new CandidateInterviewDto();
        request.setInterviewResult(InterviewResult.REJECTED.getType());

        Method method = CandidateServiceImpl.class.getDeclaredMethod(
                "saveStatusChangeEvent",
                CandidateInterviewDto.class,
                CandidateStatusType.class,
                Integer.class
        );
        method.setAccessible(true);
        method.invoke(candidateService, request, CandidateStatusType.PROFILE_UPLOADED, 1);

        verify(candidateEventService, times(1)).addEvent(any(CandidateEventDto.class), eq(1));
    }

    @Test
    void addDocumentInformation_ShouldReturnGeneratedDocumentId() {
        Integer userId = 123;
        CandidateDocumentDto documentDto = new CandidateDocumentDto();

        CandidateDocumentBO mappedDocumentBO = new CandidateDocumentBO();
        mappedDocumentBO.setId(1);
        when(mapper.map(documentDto, CandidateDocumentBO.class)).thenReturn(mappedDocumentBO);

        CandidateDocumentBO savedDocumentBO = new CandidateDocumentBO();
        savedDocumentBO.setId(1);
        when(candidateDocumentRepository.save(any(CandidateDocumentBO.class))).thenReturn(savedDocumentBO);

        Integer generatedDocumentId = candidateService.addDocumentInformation(documentDto, userId);

        assertEquals(savedDocumentBO.getId(), generatedDocumentId);
        verify(candidateDocumentRepository, times(1)).save(any(CandidateDocumentBO.class));
    }

    @Test
    void testSearchCandidate() {
        String email = "test@example.com";
        String phone = "1234567890";

        Specification spec = null;

        List<CandidateBO> candidates = new ArrayList<>();
        List<CandidateDto> expectedResults = new ArrayList<>();

        MockitoAnnotations.initMocks(this);

        when(candidateRepository.findAll(any())).thenReturn(candidates);
        when(commonUtil.mapList(candidates, CandidateDto.class)).thenReturn(expectedResults);

        List<CandidateDto> result = candidateService.searchCandidate(email, phone);

        verify(candidateRepository, times(1)).findAll(any());
        verify(commonUtil, times(1)).mapList(candidates, CandidateDto.class);
        assertEquals(expectedResults, result);
    }

    @Test
    void testSearchCandidateWithOnlyEmail() {
        String email = "test@example.com";
        String phone = null;

        testSearchCandidateCommon(email, phone);
    }

    @Test
    void testSearchCandidateWithOnlyPhone() {
        String email = null;
        String phone = "1234567890";

        testSearchCandidateCommon(email, phone);
    }

    private void testSearchCandidateCommon(String email, String phone) {
        Specification spec = null;

        List<CandidateBO> candidates = new ArrayList<>();
        List<CandidateDto> expectedResults = new ArrayList<>();

        MockitoAnnotations.initMocks(this);

        when(candidateRepository.findAll(any())).thenReturn(candidates);
        when(commonUtil.mapList(candidates, CandidateDto.class)).thenReturn(expectedResults);

        List<CandidateDto> result = candidateService.searchCandidate(email, phone);

        verify(candidateRepository, times(1)).findAll(any());
        verify(commonUtil, times(1)).mapList(candidates, CandidateDto.class);
        assertEquals(expectedResults, result);
    }

    @Test
    public void testAuditCandidate() {
        Integer sjdId = 1;
        Integer candidateId = 2;
        Integer userId = 3;

        SjdCandidateInfoDto request = new SjdCandidateInfoDto();
        request.setSjdId(sjdId);
        request.setCandidateId(candidateId);
        request.setAuditResult(true);

        SjdCandidateInfoBO existingInfo = new SjdCandidateInfoBO();
        existingInfo.setSjd(new SjdBO());
        existingInfo.setCandidate(new CandidateBO());

        when(sjdCandidateInfoRepository.findById(any()))
                .thenReturn(Optional.of(existingInfo));

        candidateService.auditCandidate(request, userId);

        verify(sjdCandidateInfoRepository, times(1)).findById(Mockito.any());
        verify(sjdCandidateInfoRepository, times(1)).save(Mockito.any());

        assertTrue(existingInfo.getAuditResult());
        assertEquals(request.getAuditComments(), existingInfo.getAuditComments());
        assertNotNull(existingInfo.getAuditBy());
        assertNotNull(existingInfo.getAuditOn());
    }

    @Test
    public void testSearchCandidateFromResumeId() {
        List<String> resumeIds = Arrays.asList("resumeId1", "resumeId2");

        CandidateBO candidate1 = new CandidateBO();
        candidate1.setId(1);
        candidate1.setResumeId("resumeId1");

        CandidateBO candidate2 = new CandidateBO();
        candidate2.setId(2);
        candidate2.setResumeId("resumeId2");

        List<CandidateBO> candidates = Arrays.asList(candidate1, candidate2);

        when(candidateRepository.findByResumeIdIn(resumeIds)).thenReturn(candidates);

        SjdBO sjd1 = new SjdBO();
        sjd1.setId(1);

        SjdBO sjd2 = new SjdBO();
        sjd2.setId(2);

        Mockito.lenient().when(mapper.map(sjd1, SjdDto.class)).thenReturn(new SjdDto());
        Mockito.lenient().when(mapper.map(sjd2, SjdDto.class)).thenReturn(new SjdDto());

        List<ResumeSearchResponseDto> response = candidateService.searchCandidateFromResumeId(resumeIds);

        assertEquals(2, response.size());
    }

    @ParameterizedTest
    @EnumSource(CandidateDetailsType.class)
    public void testDeleteCandidateDetails(CandidateDetailsType detailsType) {
        CandidateDetailsDeleteRequest request = new CandidateDetailsDeleteRequest();
        request.setIdToBeDeleted(1);
        request.setSjdId(2);
        request.setCandidateId(3);
        Integer userId = 4;

        when(commonUtil.getCandidateEventTypeId(anyString())).thenReturn(new CandidateEventTypeBO());

        switch (detailsType) {
            case EMPLOYMENT:
                candidateService.deleteCandidateDetails(request, CandidateDetailsType.EMPLOYMENT, userId);
                verify(candidateEmploymentRepository, times(1)).deleteById(request.getIdToBeDeleted());
                break;
            case EDUCATION:
                candidateService.deleteCandidateDetails(request, CandidateDetailsType.EDUCATION, userId);
                verify(candidateEducationRepository, times(1)).deleteById(request.getIdToBeDeleted());
                break;
            case CERTIFICATION:
                candidateService.deleteCandidateDetails(request, CandidateDetailsType.CERTIFICATION, userId);
                verify(candidateCertificationRepository, times(1)).deleteById(request.getIdToBeDeleted());
                break;
        }
        verify(candidateEventService, times(1)).addEvent(any(CandidateEventDto.class), eq(userId));
    }

    @Test
    public void testUpdateInterviewDetails_WithFeedback() throws ParseException {
        CandidateInterviewDto request = new CandidateInterviewDto();
        request.setId(1);
        request.setSjdId(123);
        request.setCandidateId(456);
        request.setInterviewResult("Selected");
        request.setFeedback("Good communication skills");
        request.setEvaluator(new UserDetailsDto());

        CandidateInterviewBO existingInterview = new CandidateInterviewBO();
        existingInterview.setInterviewResult("On Hold");

        SjdCandidateInfoBO sjdCandidateInfo = new SjdCandidateInfoBO();
        when(sjdCandidateInfoRepository.findById(any())).thenReturn(Optional.of(sjdCandidateInfo));

        when(commonUtil.getCandidateEventTypeId(anyString())).thenReturn(new CandidateEventTypeBO());
        when(candidateInterviewRepository.findById(anyInt())).thenReturn(Optional.of(existingInterview));
        when(candidateInterviewRepository.save(any(CandidateInterviewBO.class))).thenAnswer((Answer<CandidateInterviewBO>) invocation -> invocation.getArgument(0));
        when(candidateEventService.addEvent(any(), anyInt())).thenReturn(1);

        candidateService.updateInterviewDetails(request, 123, true, null);

        verify(candidateInterviewRepository, times(1)).findById(anyInt());
        verify(candidateInterviewRepository, times(1)).save(any(CandidateInterviewBO.class));
        verify(candidateEventService, times(2)).addEvent(any(), anyInt());
    }

    @Test
    public void testUpdateInterviewDetails_WithoutFeedback() throws ParseException {
        CandidateInterviewDto request = new CandidateInterviewDto();
        request.setId(1);
        request.setSjdId(123);
        request.setCandidateId(456);
        request.setInterviewResult("Selected");
        request.setEvaluator(new UserDetailsDto());
        Date startTime = new Date();
        Date endTime = new Date();
        request.setStartTime(startTime);
        request.setEndTime(endTime);

        CandidateInterviewBO existingInterview = new CandidateInterviewBO();
        existingInterview.setInterviewResult("On Hold");

        when(candidateInterviewRepository.findById(anyInt())).thenReturn(Optional.of(existingInterview));
        when(candidateInterviewRepository.save(any(CandidateInterviewBO.class))).thenAnswer((Answer<CandidateInterviewBO>) invocation -> invocation.getArgument(0));
        when(candidateEventService.addEvent(any(), anyInt())).thenReturn(1);

        CandidateEventTypeBO eventType = new CandidateEventTypeBO();
        when(commonUtil.getCandidateEventTypeId(anyString())).thenReturn(eventType);

        candidateService.updateInterviewDetails(request, 123, false, null);

        verify(candidateInterviewRepository, times(1)).findById(anyInt());
        verify(candidateInterviewRepository, times(1)).save(any(CandidateInterviewBO.class));
        verify(candidateEventService, times(1)).addEvent(any(), anyInt()); // Only one event for Interview Reschedule
    }
}
