package com.peopletech.fractionable.util;

import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.dto.LookupDto;
import com.peopletech.fractionable.entity.CandidateEventTypeBO;
import com.peopletech.fractionable.entity.CandidateStatusBO;
import com.peopletech.fractionable.entity.RoleBO;
import com.peopletech.fractionable.entity.SjdStatusBO;
import com.peopletech.fractionable.service.LookupService;
import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Component
public class CommonUtil {

    LookupService lookupService;
    DozerBeanMapper mapper;

    public CommonUtil(LookupService lookupService, DozerBeanMapper mapper) {
        this.lookupService = lookupService;
        this.mapper = mapper;
    }

    public Integer getSjdEventTypeId(String sjdEventType) {
        List<LookupDto> sjdEventTypeList = lookupService.getLookupValues(LookupType.SJD_EVENT_TYPE);
        LookupDto eventTypeObj = sjdEventTypeList.stream().filter(type ->
                type.getName().equals(sjdEventType)).findFirst().orElseThrow(() -> new RuntimeException("event type not found"));
        return eventTypeObj.getId();
    }

    public CandidateEventTypeBO getCandidateEventTypeId(String candidateEventType) {
        List<LookupDto> candidateEventTypeList = lookupService.getLookupValues(LookupType.CANDIDATE_EVENT_TYPE);
        return candidateEventTypeList
                .stream()
                .filter(type -> type.getName().equals(candidateEventType))
                .findFirst()
                .map(s -> mapper.map(s, CandidateEventTypeBO.class))
                .orElseThrow(() -> new NoSuchElementException("Candidate event type not found"));
    }

    public CandidateStatusBO getCandidateStatus(String candidateStatus) {
        List<LookupDto> statusList = lookupService.getLookupValues(LookupType.CANDIDATE_STATUS);
        return statusList
                .stream()
                .filter(status -> candidateStatus.equalsIgnoreCase(status.getName()))
                .findFirst()
                .map(s -> mapper.map(s, CandidateStatusBO.class))
                .orElseThrow(() -> new NoSuchElementException("Candidate status not found"));
    }

    public String getNameFromId(Integer id, LookupType type) {
        List<LookupDto> statusList = lookupService.getLookupValues(type);
        return statusList
                .stream()
                .filter(status -> id.equals(status.getId()))
                .findFirst()
                .map(LookupDto::getName)
                .orElseThrow(() -> new NoSuchElementException("status not found"));
    }

    public SjdStatusBO getSjdStatus(String sjdStatus) {
        List<LookupDto> statusList = lookupService.getLookupValues(LookupType.SJD_STATUS);
        return statusList
                .stream()
                .filter(status -> sjdStatus.equalsIgnoreCase(status.getName()))
                .findFirst()
                .map(s -> mapper.map(s, SjdStatusBO.class))
                .orElseThrow(() -> new NoSuchElementException("SJD status not found"));
    }

    public RoleBO getRole(String role) {
        List<LookupDto> roleList = lookupService.getLookupValues(LookupType.ROLE);
        return roleList
                .stream()
                .filter(r -> role.equalsIgnoreCase(r.getName()))
                .findFirst()
                .map(s -> mapper.map(s, RoleBO.class))
                .orElseThrow(() -> new NoSuchElementException("SJD status not found"));
    }

    public <T> List mapList(List<T> source, Class destClass) {
        return source.stream().map(s -> mapper.map(s, destClass)).collect(Collectors.toList());
    }

    public <T> List mapItreable(Iterable<T> source, Class destClass) {
        return StreamSupport
                .stream(source.spliterator(), false)
                .map(s -> mapper.map(s, destClass))
                .collect(Collectors.toList());
    }

    public Integer getIdFromName(String name, LookupType type) {
        List<LookupDto> lookupDtoList = lookupService.getLookupValues(type);
        return lookupDtoList
                .stream()
                .filter(lookup -> name.equalsIgnoreCase(lookup.getName()))
                .findFirst()
                .map(l -> l.getId())
                .orElseThrow(() -> new NoSuchElementException(String.format("Lookup value with the name %s not found", name)));
    }
}
