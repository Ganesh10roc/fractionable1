package com.peopletech.fractionable.dto;

import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Data
public class SjdDto {
    private Integer id;
    private String name;
    private String description;
    private Integer domainId;
    private Integer priorityId;
    private List<SjdSkillMappingDto> skills;
    private List<QuestionnaireDto> questionnaire = new ArrayList<>();
    private List<UserDetailsDto> hiringTeam = new ArrayList<>();
    private Integer clientId;
    private String jobLocation;
    private Date endDate;
    private Integer newOpenPositions;
    private Integer backfillOpenPositions;
    private Integer jobTypeId;
    private Integer payTypeId;
    private Integer payRate;
    private Integer projectDuration;
    private Boolean isVisa;
    private String visaType;
    private Integer experienceLevel;

    private Integer maxExperience;
    private String keywords;
    private String targetCompanies;
    private List<LookupDto> sourcingChannels = new ArrayList<>();
    private Integer qualificationId;
    private Integer noticePeriod;
    private Boolean isClientRound;
    private Integer noOfTechnicalInterview;
    private Boolean isOnlineTest;
    private Integer sjdStatusId;
    private UserDetailsDto createdBy;
    private Date createdOn;
    private Integer modifiedById;
    private Date modifiedOn;
    private Integer operationId;
    private String evaluationCriteria;
    private Boolean active;
    private List<SjdEventDto> events;
    private Integer totalCandidates;
    private Boolean isMigrated;
    private Boolean publish;
    private Integer hiringManagerId;
}
