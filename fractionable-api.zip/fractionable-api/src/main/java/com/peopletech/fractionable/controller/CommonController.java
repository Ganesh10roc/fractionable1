package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/common")
public class CommonController {

    @Autowired
    private CommonService commonService;

    @GetMapping("/props")
    public Map<String, String> getFrontEndProps() throws IOException {
        return commonService.getProperties();
    }
}
