package com.peopletech.fractionable.constants;

import java.util.Arrays;

public enum InterviewResult {
    SELECTED("Selected"),
    REJECTED("Rejected"),
    ON_HOLD("On hold");

    private final String type;

    InterviewResult(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    public static InterviewResult get(String type) {
        return Arrays.stream(InterviewResult.values())
                .filter(val -> val.getType().equalsIgnoreCase(type))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Interview result is invalid"));
    }

    public static Boolean isValid(String type) {
        return Arrays.stream(InterviewResult.values())
                .anyMatch(val -> val.getType().equalsIgnoreCase(type));
    }
}
