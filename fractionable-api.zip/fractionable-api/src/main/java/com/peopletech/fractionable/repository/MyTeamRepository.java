package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.UserLeadBO;
import com.peopletech.fractionable.entity.compoundkey.UserLeadID;
import org.springframework.data.repository.CrudRepository;

import java.util.Collection;

public interface MyTeamRepository extends CrudRepository<UserLeadBO, UserLeadID> {
    Collection<UserLeadBO> findByLeadId(Integer id);
}
