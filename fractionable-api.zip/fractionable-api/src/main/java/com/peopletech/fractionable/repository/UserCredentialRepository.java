package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.UserCredentialBO;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface UserCredentialRepository extends CrudRepository<UserCredentialBO, Integer> {
    Optional<UserCredentialBO> findByUsernameIgnoreCase(String username);

    Optional<UserCredentialBO> findByUserId(Integer userId);
}
