package com.peopletech.fractionable.entity;

import com.peopletech.fractionable.entity.compoundkey.SjdCandidateInfoId;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "sjd_candidate_info")
public class SjdCandidateInfoBO {

    @EmbeddedId
    private SjdCandidateInfoId id;

    @ManyToOne
    @MapsId("sjdId")
    @JoinColumn(name = "sjd_id")
    private SjdBO sjd;

    @ManyToOne
    @MapsId("candidateId")
    @JoinColumn(name = "candidate_id")
    private CandidateBO candidate;

    @OneToOne
    @JoinColumn(name = "candidate_status_id", referencedColumnName = "id")
    private CandidateStatusBO candidateStatus;

    @Column(name = "qc_rating")
    private Float qcRating;

    @Column(name = "profiler_rating")
    private Float profilerRating;

    @Column(name = "audit_result")
    private Boolean auditResult;

    @Column(name = "audit_comments")
    private String auditComments;

    @OneToOne
    @JoinColumn(name = "audit_by_id", referencedColumnName = "id")
    private UserDetailsBO auditBy;

    @Column(name = "audit_on")
    private Date auditOn;

    @Column(name = "created_by_id")
    private Integer createdBy;

    @Column(name = "created_on")
    private Date createdOn;

    @Column(name = "comment")
    private String comment;

    @Column(name = "candidate_sub_status")
    private String candidateSubStatus;

    public SjdCandidateInfoBO(Integer sjdId, Integer candidateId) {
        this.id = new SjdCandidateInfoId(sjdId, candidateId);
    }
}
