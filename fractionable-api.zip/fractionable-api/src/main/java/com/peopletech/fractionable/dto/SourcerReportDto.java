package com.peopletech.fractionable.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SourcerReportDto {
    private Integer sjdId;
    private String sjdName;
    private Integer candidateId;
    private String candidateName;
    private String phoneNumber;
    private String email;
    private Float experience;
    private Integer noticePeriod;
    private Float qcRating;
    private Float profilerRating;
    private String currentCtc;
    private String expectedCtc;
    private String candidateStatus;
    private String candidateSubStatus;
    private Date eventCreatedOn;
    private String recruiterName;
    private String operations;
    private String client;
    private String comment;
    private String currentRole;
}
