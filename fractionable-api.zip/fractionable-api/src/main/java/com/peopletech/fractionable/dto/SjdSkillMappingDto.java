package com.peopletech.fractionable.dto;

import lombok.Data;

@Data
public class SjdSkillMappingDto {

    private LookupDto skill;
    private Float minExperience;
}
