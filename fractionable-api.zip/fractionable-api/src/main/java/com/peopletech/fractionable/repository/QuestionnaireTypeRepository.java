package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.QuestionnaireTypeBO;
import org.springframework.data.repository.CrudRepository;

public interface QuestionnaireTypeRepository extends CrudRepository<QuestionnaireTypeBO, Integer> {
}
