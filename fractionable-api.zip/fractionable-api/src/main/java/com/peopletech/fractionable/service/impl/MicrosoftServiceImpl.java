package com.peopletech.fractionable.service.impl;

import com.microsoft.graph.models.*;
import com.microsoft.graph.options.HeaderOption;
import com.microsoft.graph.options.Option;
import com.microsoft.graph.requests.GraphServiceClient;
import com.microsoft.graph.serializer.OffsetDateTimeSerializer;
import com.peopletech.fractionable.dto.CandidateInterviewDto;
import com.peopletech.fractionable.entity.SjdBO;
import com.peopletech.fractionable.entity.tad.TadSjdBO;
import com.peopletech.fractionable.repository.SjdRepository;
import com.peopletech.fractionable.repository.tad.TadSjdRepository;
import com.peopletech.fractionable.service.MicrosoftService;
import java.io.IOException;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import okhttp3.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

@Service
public class MicrosoftServiceImpl implements MicrosoftService {

    @Value("${fractionable.enable.office.integration}")
    private Boolean enableOfficeIntegration;

    @Autowired SjdRepository sjdRepository;

    @Autowired TadSjdRepository tadSjdRepository;

    @Override
    public OnlineMeeting scheduleTeamsMeeting(CandidateInterviewDto request, String accessToken)
            throws ParseException {
        if (!enableOfficeIntegration) {
            return new OnlineMeeting();
        }
        GraphServiceClient<Request> _userClient = getUserClient(accessToken);

        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        OnlineMeeting onlineMeeting = new OnlineMeeting();
        onlineMeeting.startDateTime =
                OffsetDateTimeSerializer.deserialize(formatter.format(request.getStartTime()));
        onlineMeeting.endDateTime =
                OffsetDateTimeSerializer.deserialize(formatter.format(request.getEndTime()));

        MeetingParticipantInfo recruiter = new MeetingParticipantInfo();
        recruiter.upn = request.getRecruiterEmail();
        MeetingParticipantInfo candidate = new MeetingParticipantInfo();
        candidate.upn = request.getCandidateEmail();
        MeetingParticipantInfo evaluator = new MeetingParticipantInfo();
        evaluator.upn = request.getEvaluator().getEmail();

        List<MeetingParticipantInfo> meetingParticipantInfos = new ArrayList<>();
        meetingParticipantInfos.add(candidate);
        meetingParticipantInfos.add(evaluator);
        //    meetingParticipantInfos.addAll(
        //        request.getHiringTeamEmails().stream()
        //            .map(
        //                email -> {
        //                  MeetingParticipantInfo participant = new MeetingParticipantInfo();
        //                  participant.upn = request.getRecruiterEmail();
        //                  return participant;
        //                })
        //            .toList());

        MeetingParticipants participants = new MeetingParticipants();
        participants.organizer = recruiter;
        participants.attendees = meetingParticipantInfos;

        onlineMeeting.participants = participants;
        if (request.getMeetingId() == null) {
            onlineMeeting.subject = "Technical Interview with Peopletech Group";
            JoinMeetingIdSettings settings = new JoinMeetingIdSettings();
            settings.isPasscodeRequired = true;
            onlineMeeting.joinMeetingIdSettings = settings;
            return _userClient.me().onlineMeetings().buildRequest().post(onlineMeeting);
        } else {
            onlineMeeting.participants.organizer = null;
            return _userClient
                    .me()
                    .onlineMeetings(request.getMeetingId())
                    .buildRequest()
                    .patch(onlineMeeting);
        }
    }

    @Override
    public Event sendMeetingInviteByMail(
            CandidateInterviewDto request, String accessToken, OnlineMeeting meeting,Boolean flag)
            throws ParseException {

        if (!enableOfficeIntegration) {
            return new Event();
        }

        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ");
        String timeZone =
                TimeZone.getTimeZone(
                                ZonedDateTime.parse(formatter.format(request.getStartTime()), dateTimeFormatter)
                                        .getZone())
                        .getDisplayName();

        GraphServiceClient<Request> _userClient = getUserClient(accessToken);
        LinkedList<Option> requestOptions = new LinkedList<>();
        requestOptions.add(
                new HeaderOption("Prefer", "outlook.timezone=\"".concat(timeZone).concat("\"")));
        Event event = new Event();
        if(flag){
            TadSjdBO sjdBO = tadSjdRepository.findById(request.getSjdId()).get();
            event.subject =
                    "Interview invite: "
                            .concat(sjdBO.getName())
                            .concat(" position at ")
                            .concat("Peopletech Group")
                            .concat(" | ")
                            .concat("Round:")
                            .concat(request.getInterviewLevel())
                            .concat(" | ")
                            .concat(String.valueOf(request.getSjdId()));

        }else{
            SjdBO sjdBO = sjdRepository.findById(request.getSjdId()).get();
            event.subject =
                    "Interview invite: "
                            .concat(sjdBO.getName())
                            .concat(" position at ")
                            .concat("Peopletech Group")
                            .concat(" | ")
                            .concat("Round:")
                            .concat(request.getInterviewLevel())
                            .concat(" | ")
                            .concat(String.valueOf(request.getSjdId()));
        }
        ItemBody body = new ItemBody();
        body.contentType = BodyType.HTML;
        try {
            String template =
                    (meeting != null)
                            ? "online_meeting_email_template.txt"
                            : "in_person_meeting_email_template.txt";
            String msg =
                    StreamUtils.copyToString(
                            new ClassPathResource(template).getInputStream(), Charset.defaultCharset());
            msg = msg.replace("{{CANDIDATE_NAME}}", request.getCandidateName());

            //      String date = (new SimpleDateFormat("dd/MM/yyyy")).format(request.getStartTime());

            DateFormat timeFormatter = new SimpleDateFormat("hh:mm a z");
            DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
            if (request.getRecruiter().getOperations() == 1) {
                dateFormatter.setTimeZone(TimeZone.getTimeZone("IST"));
                timeFormatter.setTimeZone(TimeZone.getTimeZone("IST"));
            } else {
                dateFormatter.setTimeZone(TimeZone.getTimeZone("EDT"));
                timeFormatter.setTimeZone(TimeZone.getTimeZone("EDT"));
            }
            String date = dateFormatter.format(request.getStartTime());
            String startTime = timeFormatter.format(request.getStartTime());
            String endTime = timeFormatter.format(request.getEndTime());

            msg = msg.replace("{{INTERVIEW_DATE}}", date);
            msg = msg.replace("{{INTERVIEW_TIME}}", startTime.concat(" - ").concat(endTime));
            msg = msg.replace("{{RECRUITER_NAME}}", request.getRecruiterName());
            if (meeting != null) {
                msg = msg.replace("{{TEAMS_MEETING_URL}}", meeting.joinWebUrl);
                msg = msg.replace("{{MEETING_ID}}", meeting.joinMeetingIdSettings.joinMeetingId);
                msg = msg.replace("{{MEETING_PASSCODE}}", meeting.joinMeetingIdSettings.passcode);
            }
            body.content = msg;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        event.body = body;

        DateTimeTimeZone start = new DateTimeTimeZone();
        start.dateTime = formatter.format(request.getStartTime());
        start.timeZone = timeZone;
        event.start = start;

        DateTimeTimeZone end = new DateTimeTimeZone();
        end.dateTime = formatter.format(request.getEndTime());
        end.timeZone = timeZone;
        event.end = end;

        Location location = new Location();
        location.displayName =
                (meeting != null) ? "Virtual Meeting - MS Teams" : "Face to Face Interview";
        event.location = location;

        LinkedList<Attendee> attendeesList = new LinkedList<>();

        Attendee attendeeCandidate = new Attendee();
        EmailAddress candidateEmail = new EmailAddress();
        candidateEmail.address = request.getCandidateEmail();
        candidateEmail.name = request.getCandidateName();
        attendeeCandidate.emailAddress = candidateEmail;
        attendeeCandidate.type = AttendeeType.REQUIRED;
        attendeesList.add(attendeeCandidate);

        Attendee attendeeEvaluator = new Attendee();
        EmailAddress evaluatorEmail = new EmailAddress();
        evaluatorEmail.address = request.getEvaluator().getEmail();
        evaluatorEmail.name =
                request
                        .getEvaluator()
                        .getFirstName()
                        .concat(" ")
                        .concat(request.getEvaluator().getLastName());
        attendeeEvaluator.emailAddress = evaluatorEmail;
        attendeeEvaluator.type = AttendeeType.REQUIRED;
        attendeesList.add(attendeeEvaluator);

        Attendee attendeeRecruiter = new Attendee();
        EmailAddress recruiterEmail = new EmailAddress();
        recruiterEmail.address = request.getRecruiterEmail();
        recruiterEmail.name = request.getRecruiterName();
        attendeeRecruiter.emailAddress = recruiterEmail;
        attendeeRecruiter.type = AttendeeType.REQUIRED;
        attendeesList.add(attendeeRecruiter);

        //    attendeesList.addAll(
        //        request.getHiringTeamEmails().stream()
        //            .map(
        //                email -> {
        //                  Attendee attendee = new Attendee();
        //                  EmailAddress attendeeEmail = new EmailAddress();
        //                  attendeeEmail.address = email;
        //                  attendee.emailAddress = attendeeEmail;
        //                  attendee.type = AttendeeType.OPTIONAL;
        //                  return attendee;
        //                })
        //            .toList());

        event.attendees = attendeesList;

        if (request.getMeetingInvitationId() == null) {
            event.allowNewTimeProposals = true;
            event.transactionId = UUID.randomUUID().toString();
            return _userClient.me().events().buildRequest(requestOptions).post(event);
        } else {
            return _userClient
                    .me()
                    .events(request.getMeetingInvitationId())
                    .buildRequest(requestOptions)
                    .patch(event);
        }
    }

    @Override
    public void deleteTeamsMeeting(String meetingId, String accessToken) {

        if (!enableOfficeIntegration) {
            return;
        }

        GraphServiceClient<Request> _userClient = getUserClient(accessToken);
        _userClient.me().onlineMeetings(meetingId).buildRequest().delete();
    }

    @Override
    public void cancelMeetingInvite(String meetingInviteId, String accessToken) {

        if (!enableOfficeIntegration) {
            return;
        }

        GraphServiceClient<Request> _userClient = getUserClient(accessToken);
        _userClient
                .me()
                .events(meetingInviteId)
                .cancel(EventCancelParameterSet.newBuilder().build())
                .buildRequest()
                .post();
    }

    private GraphServiceClient<Request> getUserClient(String accessToken) {
        return GraphServiceClient.builder()
                .authenticationProvider(
                        requestUrl -> {
                            CompletableFuture<String> future = new CompletableFuture<>();
                            future.complete(accessToken);
                            return future;
                        })
                .buildClient();
    }
}
