package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.SjdUserBO;
import com.peopletech.fractionable.entity.compoundkey.SjdUserID;
import jakarta.persistence.Tuple;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.Collection;
import java.util.List;

public interface SjdUserRepository extends CrudRepository<SjdUserBO, SjdUserID> {
    Collection<SjdUserBO> findAllByUserId(Integer userId);

    @Query(value = "select sum.sjd_id from sjd_user_mapping sum inner join sjd s on sum.sjd_id = s.id where s.is_active = true and sum.user_id = ?1", nativeQuery = true)
    List<Tuple> findAllSjdIdByUserId(Integer userId);
}
