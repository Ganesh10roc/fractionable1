package com.peopletech.fractionable.dto;

import lombok.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class QuestionnaireDto {
    @EqualsAndHashCode.Include
    private Integer id;
    private String name;
    private Integer questionnaireTypeId;
    private List<QuestionDto> questions = new ArrayList<>();
    private List<LookupDto> skills = new ArrayList<>();
    private UserDetailsDto createdBy;
    private Date createdOn;
    private List<Integer> sjdId;
}