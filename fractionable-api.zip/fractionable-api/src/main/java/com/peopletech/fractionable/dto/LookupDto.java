package com.peopletech.fractionable.dto;

import lombok.Data;

@Data
public final class LookupDto {
    private Integer id;
    private String name;
}