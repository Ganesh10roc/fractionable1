package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.dto.AuditReportDto;
import com.peopletech.fractionable.dto.request.ReportRequestDto;
import com.peopletech.fractionable.repository.SjdCandidateInfoRepository;
import com.peopletech.fractionable.service.ReportService;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.persistence.Tuple;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

@Service
public class AuditReportServiceImpl implements ReportService<List<AuditReportDto>, byte[]> {

    @Autowired
    SjdCandidateInfoRepository sjdCandidateInfoRepository;

    @Autowired
    CommonUtil commonUtil;

    @Override
    public List<AuditReportDto> getReport(ReportRequestDto reportRequestDto) {
        return getAuditReportData(reportRequestDto.getFromDate(), reportRequestDto.getToDate());
    }

    @Override
    public byte[] getReportExcel(ReportRequestDto reportRequestDto) throws IOException {
        List<AuditReportDto> list = getAuditReportData(reportRequestDto.getFromDate(), reportRequestDto.getToDate());
        Map<String, Integer> headers = new LinkedHashMap<>();
        headers.put("SJD ID", 10);
        headers.put("SJD Name", 20);
        headers.put("Candidate Name", 30);
        headers.put("Recruiter", 30);
        headers.put("Audit Result", 30);
        headers.put("Audit Comments", 70);
        headers.put("Audited By", 30);
        headers.put("Audited On", 30);
        headers.put("Operations",60);

        Workbook wb = new HSSFWorkbook();
        Sheet sheet = wb.createSheet("Report");
        int index = 0;
        for (String key : headers.keySet()) {
            sheet.setColumnWidth(index++, 256 * headers.get(key));
        }

        Row row = sheet.createRow(0);
        row.setHeight((short) -1);
        populateHeaderRow(wb, row, headers.keySet());

        for (int i = 0; i < list.size(); i++) {
            Row r = sheet.createRow(i + 1);
            populateAuditDataRow(wb, r, list.get(i));
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        wb.write(out);
        out.close();
        wb.close();
        return out.toByteArray();
    }

    private List<AuditReportDto> getAuditReportData(Date fromDate, Date toDate) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(toDate);
        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE), 23, 59, 59);
        List<Tuple> auditReport = sjdCandidateInfoRepository.findAuditReport(fromDate, cal.getTime());
        return auditReport.stream().map(tuple -> mapAuditTupleToDto(tuple)).toList();
    }

    private AuditReportDto mapAuditTupleToDto(Tuple tuple) {
        AuditReportDto dto = AuditReportDto.builder()
                .sjdId(tuple.get(0, Integer.class))
                .sjdName(tuple.get(1, String.class))
                .candidateId(tuple.get(2, Integer.class))
                .candidateName(tuple.get(3, String.class))
                .recruiterName(tuple.get(4, String.class))
                .auditResult(tuple.get(5, Boolean.class))
                .auditComments(tuple.get(6, String.class))
                .auditedBy(tuple.get(7, String.class))
                .auditedOn(Date.from(tuple.get(8, Instant.class)))
                .operations(commonUtil.getNameFromId(tuple.get(9,Integer.class), LookupType.OPERATION))
                .build();
        return dto;
    }

    private CellStyle createBorderStyle(Workbook wb) {
        BorderStyle thin = BorderStyle.THIN;
        Short black = IndexedColors.BLACK.getIndex();
        CellStyle style = wb.createCellStyle();
        style.setBorderTop(thin);
        style.setTopBorderColor(black);
        style.setBorderRight(thin);
        style.setRightBorderColor(black);
        style.setBorderBottom(thin);
        style.setBottomBorderColor(black);
        style.setBorderLeft(thin);
        style.setLeftBorderColor(black);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private void populateHeaderRow(Workbook wb, Row row, Set<String> headers) {
        CellStyle headerStyle = createBorderStyle(wb);
        Font font = wb.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        int index = 0;
        for (String header : headers) {
            Cell cell = row.createCell(index++);
            cell.setCellStyle(headerStyle);
            cell.setCellValue(header);
        }
    }

    private void populateAuditDataRow(Workbook wb, Row r, AuditReportDto report) {
        Cell c1 = r.createCell(0);
        c1.setCellValue(report.getSjdId());

        Cell c2 = r.createCell(1);
        c2.setCellValue(report.getSjdName());

        Cell c3 = r.createCell(2);
        c3.setCellValue(report.getCandidateName());

        Cell c4 = r.createCell(3);
        c4.setCellValue(report.getRecruiterName());

        CellStyle resultCellStyle = createBorderStyle(wb);
        Font font = wb.createFont();
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        resultCellStyle.setFont(font);
        resultCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        resultCellStyle.setFillForegroundColor(report.getAuditResult() ?
                IndexedColors.GREEN.getIndex() : IndexedColors.RED.getIndex());
        resultCellStyle.setAlignment(HorizontalAlignment.CENTER);
        resultCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);


        Cell c5 = r.createCell(4);
        c5.setCellStyle(resultCellStyle);
        c5.setCellValue(report.getAuditResult() ? "Pass" : "Fail");

        Cell c6 = r.createCell(5);
        CellStyle commentCellStyle = wb.createCellStyle();
        commentCellStyle.setWrapText(true);
        c6.setCellStyle(commentCellStyle);
        c6.setCellValue(report.getAuditComments());

        Cell c7 = r.createCell(6);
        c7.setCellValue(report.getAuditedBy());

        DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy hh:mm a");

        Cell c11 = r.createCell(7);
        c11.setCellValue(dateFormatter.format(report.getAuditedOn()));

        Cell c12 = r.createCell(8);
        c12.setCellValue(report.getOperations());

    }

}
