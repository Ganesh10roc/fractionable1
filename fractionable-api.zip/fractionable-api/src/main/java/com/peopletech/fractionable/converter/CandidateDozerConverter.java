package com.peopletech.fractionable.converter;

import com.peopletech.fractionable.entity.CandidateBO;
import org.dozer.CustomConverter;

import java.util.Arrays;
import java.util.List;

public class CandidateDozerConverter implements CustomConverter {

    @Override
    public Object convert(Object destination, Object source, Class destClass, Class sourceClass) {
        if (sourceClass.equals(Integer.class)) {
            CandidateBO candidate = CandidateBO.builder().id((Integer) source).build();
            if (destClass.equals(List.class)) {
                return Arrays.asList(candidate);
            } else {
                return candidate;
            }
        } else if (sourceClass.equals(CandidateBO.class)) {
            if (destClass.equals(List.class)) {
                return Arrays.asList(((CandidateBO) source).getId());
            } else {
                return ((CandidateBO) source).getId();
            }

        }
        return null;
    }
}