package com.peopletech.fractionable.converter;

import com.peopletech.fractionable.entity.SjdBO;
import org.dozer.CustomConverter;

import java.util.Arrays;
import java.util.List;

public class SjdDozerConverter implements CustomConverter {

    @Override
    public Object convert(Object destination, Object source, Class destClass, Class sourceClass) {
        if (sourceClass.equals(Integer.class)) {
            SjdBO sjd = new SjdBO();
            sjd.setId((Integer) source);
            if (destClass.equals(List.class)) {
                return Arrays.asList(sjd);
            } else {
                return sjd;
            }
        } else if (sourceClass.equals(SjdBO.class)) {
            if (destClass.equals(List.class)) {
                return Arrays.asList(((SjdBO) source).getId());
            } else if (destClass.equals(String.class)) {
                return ((SjdBO) source).getName();
            } else {
                return ((SjdBO) source).getId();
            }
        }
        return null;
    }
}