package com.peopletech.fractionable.service;

import com.peopletech.fractionable.dto.UserDetailsDto;

import java.util.List;

public interface MyTeamService {
    void addMyTeam(List<Integer> userList, Integer leadId);

    List<UserDetailsDto> getMyTeam(Integer leadId);

    void removeFromMyTeam(Integer userId, Integer leadId);
}
