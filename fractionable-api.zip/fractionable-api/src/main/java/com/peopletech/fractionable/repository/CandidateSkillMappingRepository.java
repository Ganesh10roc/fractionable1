package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.CandidateSkillMappingBO;
import com.peopletech.fractionable.entity.compoundkey.CandidateSkillID;
import org.springframework.data.repository.CrudRepository;

public interface CandidateSkillMappingRepository extends CrudRepository<CandidateSkillMappingBO, CandidateSkillID> {
}
