package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.constants.AppConstants;
import com.peopletech.fractionable.dto.AppResponseDto;
import com.peopletech.fractionable.dto.UserDetailsDto;
import com.peopletech.fractionable.service.UserService;
import com.peopletech.fractionable.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private CommonUtil commonUtil;

    @PostMapping
    public AppResponseDto<Integer> createUser(@RequestBody UserDetailsDto userDetails, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        UserDetailsDto userDetailsDto = userService.createUser(userDetails, userId);
        return new AppResponseDto<>(userDetailsDto.getId(), "User created successfully");
    }

    @PatchMapping
    public UserDetailsDto updateUser(@RequestBody UserDetailsDto userDetails, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        return userService.updateUser(userDetails, userId);
    }

    @GetMapping
    public List<UserDetailsDto> getUsers(@RequestParam(required = false) Integer role) {
        if (ObjectUtils.isEmpty(role)) {
            return userService.getAllUsers();
        } else {
            return userService.getUsersByRole(role);
        }
    }
}
