package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "source_channel_lookup")
public class SourceChannelBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "source_channel_lookup_id_generator")
    @SequenceGenerator(name = "source_channel_lookup_id_generator", sequenceName = "source_channel_lookup_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;
}
