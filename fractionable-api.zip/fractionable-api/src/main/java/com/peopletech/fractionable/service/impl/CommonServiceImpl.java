package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.service.CommonService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

@Service
public class CommonServiceImpl implements CommonService {

    @Value("${front-end.property.path}")
    private String propertyFilePath;

    @Override
    public Map<String, String> getProperties() throws IOException {
        Map<String, String> props = new HashMap<>();
        try {
            FileInputStream file = new FileInputStream(propertyFilePath);
            Properties properties = new Properties();
            properties.load(file);
            file.close();
            properties.forEach((key, value) -> {
                props.put((String) key, (String) value);
            });
        } catch (IOException e) {
            throw new IOException("Unable to read property file");
        }
        return props;
    }
}
