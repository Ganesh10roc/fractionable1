package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.SjdEventBO;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SjdEventRepository extends CrudRepository<SjdEventBO, Integer> {
    List<SjdEventBO> findBySjdIdOrderByCreatedOnDesc(Integer sjdId);
}
