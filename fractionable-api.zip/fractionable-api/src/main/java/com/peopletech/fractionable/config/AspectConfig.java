package com.peopletech.fractionable.config;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.context.annotation.Configuration;

import java.lang.reflect.Method;

@Aspect
@Slf4j
@Configuration
public class AspectConfig {

    @Pointcut("execution(* com.peopletech.fractionable.controller.*.*(..))")
    public void controllerPointcut() {
        // Pointcut declaration. No implementation needed
    }

    @Before(value = "com.peopletech.fractionable.config.AspectConfig.controllerPointcut()")
    public void beforeController(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        log.info("Execution of {}.{} method started", method.getDeclaringClass().getSimpleName(), method.getName());
    }

    @AfterThrowing(value = "com.peopletech.fractionable.config.AspectConfig.controllerPointcut()", throwing = "ex")
    public void exceptionInController(JoinPoint joinPoint, Exception ex) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        log.error("Exception thrown in {}.{} method", method.getDeclaringClass().getSimpleName(), method.getName());
        log.error(ex.getMessage(), ex);
    }
}
