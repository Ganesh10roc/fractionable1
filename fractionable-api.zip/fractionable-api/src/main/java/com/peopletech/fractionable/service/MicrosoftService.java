package com.peopletech.fractionable.service;

import com.microsoft.graph.models.Event;
import com.microsoft.graph.models.OnlineMeeting;
import com.peopletech.fractionable.dto.CandidateInterviewDto;

import java.text.ParseException;

public interface MicrosoftService {

    OnlineMeeting scheduleTeamsMeeting(CandidateInterviewDto request, String accessToken) throws ParseException;

    Event sendMeetingInviteByMail(CandidateInterviewDto request, String accessToken, OnlineMeeting meeting) throws ParseException;

    void deleteTeamsMeeting(String meetingId, String accessToken);

    void cancelMeetingInvite(String meetingInviteId, String accessToken);

}
