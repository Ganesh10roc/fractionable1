package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.QualificationBO;
import org.springframework.data.repository.CrudRepository;

public interface QualificationRepository extends CrudRepository<QualificationBO, Integer> {
}
