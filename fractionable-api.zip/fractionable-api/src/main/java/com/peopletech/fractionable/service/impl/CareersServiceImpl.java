package com.peopletech.fractionable.service.impl;


import com.peopletech.fractionable.constants.SjdStatusType;
import com.peopletech.fractionable.dto.SjdDto;
import com.peopletech.fractionable.entity.SjdBO;
import com.peopletech.fractionable.repository.SjdRepository;
import com.peopletech.fractionable.service.CareersService;
import com.peopletech.fractionable.util.CommonUtil;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CareersServiceImpl implements CareersService {
    private SjdRepository sjdRepository;
    private CommonUtil commonUtil;

    public CareersServiceImpl(SjdRepository sjdRepository, CommonUtil commonUtil) {
        this.sjdRepository=sjdRepository;
        this.commonUtil=commonUtil;
    }
    @Override
    public List<SjdDto> getSjd() {
        Set<String> blockedStatus = new HashSet<>(Arrays.asList(SjdStatusType.ON_HOLD.getType(),SjdStatusType.COMPLETED.getType()));
        List<SjdBO> sjdBOList = sjdRepository.findAllByPublishAndActive(true,true);
        sjdBOList = sjdBOList.stream().filter(sjdBO -> !blockedStatus.contains(sjdBO.getSjdStatus().getName())).toList();
        List<SjdDto> sjdDtoList = commonUtil.mapItreable( sjdBOList , SjdDto.class);
        return sjdDtoList;
    }

}