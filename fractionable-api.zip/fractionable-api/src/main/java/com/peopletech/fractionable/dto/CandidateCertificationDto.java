package com.peopletech.fractionable.dto;

import lombok.Data;

@Data
public class CandidateCertificationDto {
    private Integer id;
    private String certificationName;
    private String issuedBy;
    private Integer certificationYear;
}
