package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.constants.AppConstants;
import com.peopletech.fractionable.constants.CandidateDetailsType;
import com.peopletech.fractionable.constants.InterviewResult;
import com.peopletech.fractionable.constants.RatingType;
import com.peopletech.fractionable.dto.*;
import com.peopletech.fractionable.dto.request.CandidateDetailsDeleteRequest;
import com.peopletech.fractionable.dto.request.CandidateRejectOrCallbackRequest;
import com.peopletech.fractionable.dto.request.CandidateSubStatusChangeRequest;
import com.peopletech.fractionable.service.CandidateService;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping("/candidate")
public class CandidateController {

    @Autowired
    CandidateService candidateService;

    @Autowired
    DozerBeanMapper mapper;

    @GetMapping
    public List<CandidateDto> getAllCandidate() {
        return candidateService.getAllCandidates();
    }

    @GetMapping("/{candidateId}")
    public CandidateDto getCandidateById(@PathVariable Integer candidateId, @RequestParam(required = false) Integer sjdId) {
        return candidateService.getCandidateById(candidateId, sjdId);
    }

    @GetMapping("/sjd/{sjdId}")
    public List<CandidateDto> getCandidateBySjdId(@PathVariable Integer sjdId) {
        return candidateService.getCandidateBySjdId(sjdId);
    }

    @PostMapping
    public AppResponseDto<Integer> saveCandidate(@RequestBody CandidateDto candidate, @RequestParam(required = false) Integer sjdId, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        Integer id = candidateService.saveCandidate(candidate, sjdId, userId);
        return new AppResponseDto<>(id, "Candidate added successfully");
    }

    @PatchMapping
    public AppResponseDto<Integer> updateCandidate(@RequestBody CandidateDto candidate, @RequestParam(required = false) Integer sjdId, @RequestParam(required = false, defaultValue = "false") Boolean isResumeUpdate, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        Integer id = candidateService.updateCandidate(candidate, sjdId, userId, isResumeUpdate);
        return new AppResponseDto<>(id, "Candidate updated successfully");
    }

    @PatchMapping("/status")
    public AppResponseDto<Integer> updateCandidateStatus(@RequestBody CandidateStatusChangeDto request, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        candidateService.updateCandidateStatus(request, userId);
        return new AppResponseDto<>(null, "Candidate status updated successfully");
    }

    @PatchMapping("/sub-status")
    public AppResponseDto<Integer> updateCandidateSubStatus(@RequestBody CandidateSubStatusChangeRequest request, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        candidateService.updateCandidateSubStatus(request, userId);
        return new AppResponseDto<>(null, "Candidate sub status updated successfully");
    }

    @PatchMapping("/rating/{type}")
    public AppResponseDto<Integer> updateCandidateRating(@RequestBody SjdCandidateInfoDto request, @PathVariable String type, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        if (RatingType.QC_RATING.equals(RatingType.get(type))) {
            candidateService.updateCandidateQcRating(request, userId);
        } else {
            candidateService.updateCandidateProfilerRating(request, userId);
        }
        return new AppResponseDto<>(null, "Candidate rating updated successfully");
    }

    @PostMapping("/comment")
    public AppResponseDto<Integer> addComments(@RequestBody CandidateEventDto request, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        Integer id = candidateService.addComments(request, userId);
        return new AppResponseDto<>(id, "Comment added successfully");
    }


    @PostMapping("/reject")
    public AppResponseDto<Integer> rejectOrCallback(@RequestBody CandidateRejectOrCallbackRequest request, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        candidateService.rejectOrCallback(request, userId);
        return new AppResponseDto<>(null, "Candidate rejected successfully");
    }

    @PostMapping("/interview")
    public AppResponseDto<Integer> scheduleInterview(@RequestBody CandidateInterviewDto request, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId, @RequestHeader(name = "accessToken", required = false) String accessToken) throws ParseException {
        candidateService.scheduleInterview(request, userId, accessToken);
        return new AppResponseDto<>(null, "Interview scheduled successfully");
    }

    @PatchMapping("/interview")
    public AppResponseDto<Integer> updateInterviewDetails(@RequestBody CandidateInterviewDto request, @RequestParam Boolean isFeedback, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId, @RequestHeader(name = "accessToken", required = false) String accessToken) throws ParseException {
        if (isFeedback && !InterviewResult.isValid(request.getInterviewResult())) {
            throw new IllegalArgumentException("Interview result is not valid");
        }
        candidateService.updateInterviewDetails(request, userId, isFeedback, accessToken);
        return new AppResponseDto<>(null, "Interview details updated successfully");
    }


    @PostMapping("/document")
    public AppResponseDto<Integer> addDocument(@RequestBody CandidateDocumentDto document, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        Integer id = candidateService.addDocumentInformation(document, userId);
        return new AppResponseDto<>(id, "Document added successfully");
    }

    @GetMapping("/search")
    public List<CandidateDto> searchCandidate(@RequestParam(required = false) String email,
                                              @RequestParam(required = false) String phone) {
        return candidateService.searchCandidate(email, phone);
    }

    @PatchMapping("/audit")
    public AppResponseDto<Void> auditCandidate(@RequestBody SjdCandidateInfoDto info, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        candidateService.auditCandidate(info, userId);
        return new AppResponseDto<>(null, "Audit info added successfully");
    }

    @PostMapping("/resume-id-search")
    public List<ResumeSearchResponseDto> searchFromResumeId(@RequestBody List<String> resumeIds) {
        return candidateService.searchCandidateFromResumeId(resumeIds);
    }

    @DeleteMapping("/employment")
    public AppResponseDto<Void> deleteCandidateEmployment(@RequestBody CandidateDetailsDeleteRequest request, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        candidateService.deleteCandidateDetails(request, CandidateDetailsType.EMPLOYMENT, userId);
        return new AppResponseDto<>(null, "Candidate employment removed successfully");
    }

    @DeleteMapping("/education")
    public AppResponseDto<Void> deleteCandidateEducation(@RequestBody CandidateDetailsDeleteRequest request, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        candidateService.deleteCandidateDetails(request, CandidateDetailsType.EDUCATION, userId);
        return new AppResponseDto<>(null, "Candidate education removed successfully");
    }

    @DeleteMapping("/certification")
    public AppResponseDto<Void> deleteCandidateCertification(@RequestBody CandidateDetailsDeleteRequest request, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        candidateService.deleteCandidateDetails(request, CandidateDetailsType.CERTIFICATION, userId);
        return new AppResponseDto<>(null, "Candidate certification removed successfully");
    }

    @DeleteMapping("/interview")
    public AppResponseDto<Integer> deleteInterviewDetails(@RequestBody CandidateDetailsDeleteRequest request, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId, @RequestHeader(name = "accessToken", required = false) String accessToken) {
        candidateService.deleteCandidateInterview(request, userId, accessToken);
        return new AppResponseDto<>(null, "Interview details deleted successfully");
    }

}
