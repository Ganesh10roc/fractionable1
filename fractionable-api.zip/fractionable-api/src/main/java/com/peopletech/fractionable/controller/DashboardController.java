package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.constants.AppConstants;
import com.peopletech.fractionable.dto.AuditCandidatesReportDto;
import com.peopletech.fractionable.dto.InterviewReportDto;
import com.peopletech.fractionable.dto.QCRatedCandidatesReportDto;
import com.peopletech.fractionable.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {

    @Autowired
    DashboardService dashboardService;

    @GetMapping("")
    public Map<String, Object> getDashBoardData(@RequestParam(required = true) Integer count, @RequestParam(required = false) Integer userId) throws ParseException {
        Map<String, Long> sjdCountByStatus = dashboardService.getSjdCountByStatus(userId);
        List<InterviewReportDto> activeInterviews = dashboardService.getActiveInterviews(userId);
        List<QCRatedCandidatesReportDto> qcRatedCandidates = dashboardService.getQCRatedCandidates(userId);
        Map<Integer, Long> candidateCountBySourceChannel = dashboardService.getCandidateCountBySourceChannel();
        List<AuditCandidatesReportDto> auditCandidates = dashboardService.getAuditCandidates(null, null);
        List<Map<String, Object>> sourcingTrends = dashboardService.getSourcingTrends(count);
        List<Map<String, Object>> ratingTrends = dashboardService.getRatingTrends(count);
        Map<String, Long> candidateCountByStatus = dashboardService.getCandidateCountByStatus(userId, null, null);


        Map<String, Object> response = new HashMap<>();
        response.put("sjdCountByStatus", sjdCountByStatus);
        response.put("activeInterviews", activeInterviews);
        response.put("qcRatedCandidates", qcRatedCandidates);
        response.put("candidateCountBySourceChannel", candidateCountBySourceChannel);
        response.put("auditCandidates", auditCandidates);
        response.put("sourcingTrends", sourcingTrends);
        response.put("ratingTrends", ratingTrends);
        response.put("candidateCountByStatus", candidateCountByStatus);
        return response;
    }

    @GetMapping("/qc-rated")
    public List<QCRatedCandidatesReportDto> getQCRatedCandidates(@RequestParam(required = false) Integer userId) {
        return dashboardService.getQCRatedCandidates(userId);
    }

    @GetMapping("/interview")
    public List<InterviewReportDto> getActiveInterviews(@RequestParam(required = false) Integer userId) {
        return dashboardService.getActiveInterviews(userId);
    }

    @GetMapping("/interview/me")
    public List<InterviewReportDto> getMyInterviews(@RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        return dashboardService.getMyInterviews(userId);
    }

    @GetMapping("/source-channel")
    public Map<Integer, Long> getCandidateCountBySourceChannel() {
        return dashboardService.getCandidateCountBySourceChannel();
    }

    @GetMapping("/candidate-status")
    public Map<String, Long> getCandidateCountByStatus(@RequestParam(required = false) Integer userId, @RequestParam(required = false) String fromDate, @RequestParam(required = false) String toDate) throws ParseException {
        return dashboardService.getCandidateCountByStatus(userId, fromDate, toDate);
    }

    @GetMapping("/sjd-status")
    public Map<String, Long> getSjdCountByStatus(@RequestParam(required = false) Integer userId) {
        return dashboardService.getSjdCountByStatus(userId);
    }

    @GetMapping("/audit")
    public List<AuditCandidatesReportDto> getAuditCandidates(@RequestParam(required = false) String fromDate, @RequestParam(required = false) String toDate) throws ParseException {
        return dashboardService.getAuditCandidates(fromDate, toDate);
    }

    @GetMapping("/sourcing-trend")
    public List<Map<String, Object>> getSourcingTrends(@RequestParam(required = true) Integer count) {
        return dashboardService.getSourcingTrends(count);
    }

    @GetMapping("/rating-trend")
    public List<Map<String, Object>> getRatingTrends(@RequestParam(required = true) Integer count) {
        return dashboardService.getRatingTrends(count);
    }

}
