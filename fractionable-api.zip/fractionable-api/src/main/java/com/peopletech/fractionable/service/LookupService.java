package com.peopletech.fractionable.service;

import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.dto.LookupDto;
import com.peopletech.fractionable.entity.SkillBO;

import java.util.List;

public interface LookupService {
    public <T, I> List<LookupDto> getLookupValues(LookupType type);

    public List<LookupDto> getSkills();

    public void clearCache(LookupType type);

    public <T, I> List<LookupDto> saveLookupData(List<LookupDto> lookupData, LookupType type);

    public List<SkillBO> saveAllSkills(List<LookupDto> lookupData);

    public <T, I> void deleteLookup(String type, Integer id);

}
