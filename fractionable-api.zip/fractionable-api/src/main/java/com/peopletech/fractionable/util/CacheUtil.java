package com.peopletech.fractionable.util;

import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.service.LookupService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.stream.Stream;

@Component
@Slf4j
public class CacheUtil {

    @Autowired
    private LookupService lookupService;

    @EventListener
    public void onApplicationEvent(ApplicationReadyEvent event) {
        log.info("Loading data in cache started");
        Instant start = Instant.now();
        Stream
                .of(LookupType.values())
                .forEach(lookupService::getLookupValues);
        Instant end = Instant.now();
        log.info("Loading data in cache completed in {} milliseconds", Duration.between(start, end).toMillis());
    }
}
