package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.QuestionBO;
import org.springframework.data.repository.CrudRepository;

public interface QuestionRepository extends CrudRepository<QuestionBO, Integer> {
}
