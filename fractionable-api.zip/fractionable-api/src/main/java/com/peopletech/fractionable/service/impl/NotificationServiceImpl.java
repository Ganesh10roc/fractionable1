package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.dto.NotificationDto;
import com.peopletech.fractionable.entity.NotificationBO;
import com.peopletech.fractionable.repository.NotificationRepository;
import com.peopletech.fractionable.service.NotificationService;
import com.peopletech.fractionable.util.CommonUtil;
import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class NotificationServiceImpl implements NotificationService {

    private NotificationRepository notificationRepository;
    private CommonUtil commonUtil;
    private DozerBeanMapper mapper;


    public NotificationServiceImpl(NotificationRepository notificationRepository, CommonUtil commonUtil, DozerBeanMapper mapper) {
        this.notificationRepository = notificationRepository;
        this.commonUtil = commonUtil;
        this.mapper = mapper;
    }

    @Override
    public Integer saveNotification(NotificationDto notificationDto){
        NotificationBO notificationBO = mapper.map(notificationDto, NotificationBO.class);
        return notificationRepository.save(notificationBO).getId();
    }

    @Override
    public List<NotificationDto> getAllNotifications() {
        List<NotificationDto> notificationDtoList = commonUtil.mapItreable(notificationRepository.findAllNotificationsByExpiryDate(), NotificationDto.class);
        return notificationDtoList;
    }

    @Override
    public void deleteNotification(Integer id) {
        notificationRepository.deleteById(id);
    }
}
