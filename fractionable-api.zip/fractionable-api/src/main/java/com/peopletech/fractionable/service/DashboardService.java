package com.peopletech.fractionable.service;

import com.peopletech.fractionable.dto.AuditCandidatesReportDto;
import com.peopletech.fractionable.dto.InterviewReportDto;
import com.peopletech.fractionable.dto.QCRatedCandidatesReportDto;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

public interface DashboardService {
    public List<QCRatedCandidatesReportDto> getQCRatedCandidates(Integer userId);

    public List<InterviewReportDto> getActiveInterviews(Integer userId);

    public List<InterviewReportDto> getMyInterviews(Integer userId);

    public Map<Integer, Long> getCandidateCountBySourceChannel();

    public Map<String, Long> getCandidateCountByStatus(Integer userId, String fromDate, String toDate) throws ParseException;

    public Map<String, Long> getSjdCountByStatus(Integer userId);

    public List<AuditCandidatesReportDto> getAuditCandidates(String fromDate, String toDate) throws ParseException;

    public List<Map<String, Object>> getSourcingTrends(Integer count);

    public List<Map<String, Object>> getRatingTrends(Integer count);
}
