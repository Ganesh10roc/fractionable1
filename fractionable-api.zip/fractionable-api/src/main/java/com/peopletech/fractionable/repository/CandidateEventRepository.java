package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.CandidateEventBO;
import jakarta.persistence.Tuple;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface CandidateEventRepository extends CrudRepository<CandidateEventBO, Integer> {
    List<CandidateEventBO> findBySjdIdAndCandidateIdOrderByCreatedOnDesc(Integer sjdId, Integer candidateId);

    @Query(value = "SELECT " +
            "c.id candidateId," +
            "ce.sjd_id sjdId," +
            "s.name sjdName," +
            "c.name candidateName," +
            "c.phone_number phoneNumber," +
            "c.email email," +
            "c.experience experience," +
            "c.notice_period_days noticePeriod," +
            "sci.qc_rating," +
            "sci.profiler_rating," +
            "c.current_ctc," +
            "c.current_ctc_frequency," +
            "c.expected_ctc," +
            "c.expected_ctc_frequency," +
            "sci.candidate_status_id," +
            "ce.created_on eventCreatedOn," +
            "concat(u.first_name, ' ', u.last_name) recruiterName," +
            "u.operation_id operations," +
            "s.client_id client," +
            "sci.comment," +
            "c.present_role," +
            "sci.candidate_sub_status " +
            "FROM public.candidate_events  ce " +
            "join public.sjd  s on ce.sjd_id = s.id " +
            "join public.candidate c on ce.candidate_id=c.id " +
            "join public.user_details u on u.id = ce.created_by_id " +
            "join public.sjd_candidate_info sci on (sci.sjd_id = s.id and sci.candidate_id = c.id )" +
            "where " +
            "ce.event_type_id = :eventId " +
            "and ce.created_by_id in :userIds " +
            "and ce.created_on >= :fromDate and ce.created_on <= :toDate ", countQuery = "select 1", nativeQuery = true)
    List<Tuple> findSourcerReport(@Param("eventId") Integer eventTypeId,
                                  @Param("userIds") List<Integer> userIds,
                                  @Param("fromDate") Date fromDate,
                                  @Param("toDate") Date toDate);

    @Query(value = "SELECT " +
            "c.id candidateId," +
            "ce.sjd_id sjdId," +
            "s.name sjdName," +
            "c.name candidateName," +
            "c.phone_number phoneNumber," +
            "c.email email," +
            "c.experience experience," +
            "c.notice_period_days noticePeriod," +
            "sci.qc_rating," +
            "sci.profiler_rating," +
            "c.current_ctc," +
            "c.current_ctc_frequency," +
            "c.expected_ctc," +
            "c.expected_ctc_frequency," +
            "sci.candidate_status_id," +
            "ce.created_on eventCreatedOn," +
            "concat(u.first_name, ' ', u.last_name) recruiterName," +
            "u.operation_id operations," +
            "s.client_id client," +
            "sci.comment," +
            "c.present_role," +
            "sci.candidate_sub_status " +
            "FROM public.candidate_events  ce " +
            "join public.sjd  s on ce.sjd_id = s.id " +
            "join public.candidate c on ce.candidate_id=c.id " +
            "join public.user_details u on u.id = ce.created_by_id " +
            "join public.sjd_candidate_info sci on (sci.sjd_id = s.id and sci.candidate_id = c.id )" +
            "where " +
            "ce.event_type_id = :eventId " +
            "and ce.created_on >= :fromDate and ce.created_on <= :toDate and u.operation_id in :operations", countQuery = "select 1", nativeQuery = true)
    List<Tuple> findSourcerReportForAdmin(@Param("eventId") Integer eventTypeId,
                                          @Param("fromDate") Date fromDate,
                                          @Param("toDate") Date toDate,
                                          @Param("operations") List<Integer> operations);
}
