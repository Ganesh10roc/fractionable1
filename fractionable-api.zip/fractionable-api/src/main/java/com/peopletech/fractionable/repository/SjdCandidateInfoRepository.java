package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.SjdCandidateInfoBO;
import com.peopletech.fractionable.entity.compoundkey.SjdCandidateInfoId;
import jakarta.persistence.Tuple;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface SjdCandidateInfoRepository extends CrudRepository<SjdCandidateInfoBO, SjdCandidateInfoId> {
    List<SjdCandidateInfoBO> findBySjdId(Integer sjdId);

    @Query(value = "SELECT sjd_id, count(sjd_id) FROM sjd_candidate_info e WHERE e.sjd_id in ?1 group by e.sjd_id", nativeQuery = true)
    List<Tuple> getCandidatesFromSjdList(List<Integer> sjdIds);

    @Query(value = "select c.id as candidate_id, c.name as candidate_name, s.id as sjd_id, s.name as sjd_name, sci.qc_rating, ud.id as recruiter_id, CONCAT(ud.first_name,' ',ud.last_name) as recruiter_name from sjd_candidate_info sci inner join sjd s on sci.sjd_id = s.id inner join candidate c on sci.candidate_id = c.id inner join user_details ud on sci.created_by_id = ud.id where candidate_status_id = ?1 and s.id in ?2", nativeQuery = true)
    List<Tuple> getQCRatedCandidates(Integer statusId, List<Integer> sjdIds);

    @Query(value = "select sci.sjd_id, s.name as sjd_name, sci.candidate_id, c.name as candidate_name, concat(u.first_name, ' ', u.last_name) as recruiter, sci.audit_result, sci.audit_comments, concat(ud.first_name, ' ', ud.last_name) as auditedBy, sci.audit_on, ud.operation_id from sjd_candidate_info sci inner join sjd s on sci.sjd_id = s.id inner join candidate c on sci.candidate_id = c.id inner join user_details ud on sci.audit_by_id = ud.id inner join user_details u on sci.created_by_id = u.id where sci.audit_on >= ?1 and sci.audit_on <= ?2", countQuery = "select 1", nativeQuery = true)
    List<Tuple> findAuditReport(@Param("fromDate") Date fromDate,
                                @Param("toDate") Date toDate);

    @Query(value = "select s.id as sjdId, s.name as sjdName, c.id as candidateId, c.name as candidateName, ud.id as recruiterId, concat(ud.first_name, ' ', ud.last_name) as recruiterName, sci.created_on, s.client_id, c.operations_id from sjd_candidate_info sci inner join candidate c on sci.candidate_id = c.id inner join sjd s on sci.sjd_id = s.id inner join user_details ud on sci.created_by_id = ud.id where sci.audit_result is null order by sci.created_on desc limit 200", nativeQuery = true)
    List<Tuple> findAuditCandidates();

    @Query(value = "select s.id as sjdId, s.name as sjdName, c.id as candidateId, c.name as candidateName, ud.id as recruiterId, concat(ud.first_name, ' ', ud.last_name) as recruiterName, sci.created_on, s.client_id, c.operations_id from sjd_candidate_info sci inner join candidate c on sci.candidate_id = c.id inner join sjd s on sci.sjd_id = s.id inner join user_details ud on sci.created_by_id = ud.id where sci.audit_result is null and sci.created_on >= ?1 and sci.created_on <= ?2", nativeQuery = true)
    List<Tuple> filterAuditCandidates(@Param("fromDate") Date fromDate,
                                      @Param("toDate") Date toDate);

    @Query(value = "select DATE(sci.created_on) as created, count(created_on) from sjd_candidate_info sci group by created order by created desc limit ?1", nativeQuery = true)
    List<Tuple> getSourcingTrends(@Param("count") Integer count);

    @Query(value = "select DATE(sci.audit_on) as audited, count(audit_on) from sjd_candidate_info sci where audit_on is not null group by audited order by audited desc limit ?1", nativeQuery = true)
    List<Tuple> getAuditTrends(@Param("count") Integer count);

    @Query(value = "select DATE(sci.created_on) as created, avg(sci.qc_rating) as qc_rating, avg(sci.profiler_rating) as profiler_rating from sjd_candidate_info sci group by created order by created desc limit ?1", nativeQuery = true)
    List<Tuple> getRatingTrends(@Param("count") Integer count);

}