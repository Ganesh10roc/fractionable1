package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.HiringManagerBO;
import org.springframework.data.repository.CrudRepository;

public interface HiringManagerRepository extends CrudRepository<HiringManagerBO,Integer> {
}
