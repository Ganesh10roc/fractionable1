package com.peopletech.fractionable.specifications;

import com.peopletech.fractionable.entity.UserDetailsBO;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

public class CandidateSpecifications {

    public static Specification<UserDetailsBO> isEmailPresent(String email) {
        return new Specification<UserDetailsBO>() {
            @Override
            public Predicate toPredicate(Root<UserDetailsBO> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
                return criteriaBuilder.equal(root.get("email"), email);
            }
        };
    }

    public static Specification<UserDetailsBO> isPhoneNumberPresent(String phoneNumber) {
        return new Specification<UserDetailsBO>() {
            @Override
            public Predicate toPredicate(Root<UserDetailsBO> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
                return criteriaBuilder.equal(root.get("phoneNumber"), phoneNumber);
            }
        };
    }
}
