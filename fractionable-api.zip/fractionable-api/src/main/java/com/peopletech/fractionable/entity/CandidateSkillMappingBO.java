package com.peopletech.fractionable.entity;

import com.peopletech.fractionable.entity.compoundkey.CandidateSkillID;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "candidate_skills_mapping")
@NoArgsConstructor
@AllArgsConstructor
public class CandidateSkillMappingBO {


    @EmbeddedId
    private CandidateSkillID id;
}
