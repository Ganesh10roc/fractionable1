package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.dto.CandidateEventDto;
import com.peopletech.fractionable.entity.CandidateEventBO;
import com.peopletech.fractionable.entity.UserDetailsBO;
import com.peopletech.fractionable.repository.CandidateEventRepository;
import com.peopletech.fractionable.service.CandidateEventService;
import com.peopletech.fractionable.util.CommonUtil;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class CandidateEventServiceImpl implements CandidateEventService {

    @Autowired
    private DozerBeanMapper mapper;

    @Autowired
    private CommonUtil commonUtil;

    @Autowired
    private CandidateEventRepository candidateEventRepository;

    @Override
    @Async
    public Integer addEvent(CandidateEventDto candidateEvent, Integer userId) {
        CandidateEventBO candidateEventBO = mapper.map(candidateEvent, CandidateEventBO.class);
        candidateEventBO.setCreatedBy(UserDetailsBO.builder().id(userId).build());
        candidateEventBO.setCreatedOn(new Date());
        return candidateEventRepository.save(candidateEventBO).getId();
    }
}
