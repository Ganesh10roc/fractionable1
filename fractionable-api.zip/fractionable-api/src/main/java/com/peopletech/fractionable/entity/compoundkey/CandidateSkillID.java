package com.peopletech.fractionable.entity.compoundkey;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;

@Embeddable
@AllArgsConstructor
public class CandidateSkillID {

    @Column(name = "candidate_id")
    private Integer candidateId;

    @Column(name = "skill_id")
    private Integer skillId;
}
