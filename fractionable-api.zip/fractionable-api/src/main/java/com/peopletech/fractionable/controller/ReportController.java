package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.constants.AppConstants;
import com.peopletech.fractionable.dto.AppResponseDto;
import com.peopletech.fractionable.dto.AuditReportDto;
import com.peopletech.fractionable.dto.SourcerReportDto;
import com.peopletech.fractionable.dto.request.ReportRequestDto;
import com.peopletech.fractionable.service.impl.AuditReportServiceImpl;
import com.peopletech.fractionable.service.impl.SourcerReportServiceImpl;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/report")
public class ReportController {

    @Autowired
    SourcerReportServiceImpl sourcerReportService;

    @Autowired
    AuditReportServiceImpl auditReportService;

    @GetMapping("")
    public AppResponseDto<Object> getReport(@RequestHeader(AppConstants.USER_ID_HEADER) Integer userId,
                                            @RequestParam String fromDate,
                                            @RequestParam String toDate,
                                            @RequestParam String reportType,
                                            @RequestParam(required = false) Integer operations) throws Exception {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        ReportRequestDto requestDto = ReportRequestDto
                .builder()
                .userId(userId)
                .fromDate(formatter.parse(fromDate))
                .toDate(formatter.parse(toDate))
                .operations(operations)
                .build();
        if (reportType.equalsIgnoreCase("sourcerReport")) {
            Map<String, List<SourcerReportDto>> sourcerReport = sourcerReportService.getReport(requestDto);
            return new AppResponseDto<>(sourcerReport, null);
        } else {
            List<AuditReportDto> auditReport = auditReportService.getReport(requestDto);
            return new AppResponseDto<>(auditReport, null);
        }
    }

    @GetMapping("/download")
    @ResponseBody
    public String getReportExcel(@RequestHeader(AppConstants.USER_ID_HEADER) Integer userId,
                                 @RequestParam String fromDate, @RequestParam String toDate,
                                 @RequestParam String reportType,
                                 @RequestParam(required = false) Integer operations,
                                 HttpServletResponse response) throws Exception {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        ReportRequestDto requestDto = ReportRequestDto
                .builder()
                .userId(userId)
                .fromDate(formatter.parse(fromDate))
                .toDate(formatter.parse(toDate))
                .operations(operations)
                .build();
        byte[] reportExcel;
        if (reportType.equalsIgnoreCase("sourcerReport")) {
            reportExcel = sourcerReportService.getReportExcel(requestDto);
        } else {
            reportExcel = auditReportService.getReportExcel(requestDto);
        }
        return Base64.getEncoder().encodeToString(reportExcel);
    }
}
