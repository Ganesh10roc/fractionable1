package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.UserRoleBO;
import com.peopletech.fractionable.entity.compoundkey.UserRoleID;
import org.springframework.data.repository.CrudRepository;

public interface UserRoleRepository extends CrudRepository<UserRoleBO, UserRoleID> {
    void deleteAllByUserId(Integer userId);
}
