package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.dto.SjdDto;
import com.peopletech.fractionable.service.CareersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/careers")
public class CareersController {

    @Autowired
    private CareersService careersService;

    @GetMapping("/sjd")
    public List<SjdDto> getSJD(){
        return careersService.getSjd();
    }
}