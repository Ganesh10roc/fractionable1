package com.peopletech.fractionable.constants;

import java.util.Arrays;

public enum CandidateSubStatus {
    NOT_INTERESTED("Not Intereseted"),
    REJECTED("Rejected"),
    CALL_BACK("Callback"),
    ON_HOLD("On Hold"),
    DROPPED("Dropped");

    private final String value;

    CandidateSubStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public static CandidateSubStatus get(String type) {
        return Arrays.stream(CandidateSubStatus.values())
                .filter(val -> val.getValue().equalsIgnoreCase(type))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Candidate sub status is invalid"));
    }
}
