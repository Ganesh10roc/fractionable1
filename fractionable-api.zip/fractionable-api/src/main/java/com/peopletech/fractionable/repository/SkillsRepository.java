package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.SkillBO;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SkillsRepository extends CrudRepository<SkillBO, Integer> {
    List<SkillBO> findAllByOrderByNameAsc();
}
