package com.peopletech.fractionable.dto;

import lombok.Data;

import java.util.Date;

@Data
public class InterviewReportDto {
    Integer candidateId;
    String candidateName;
    Integer sjdId;
    String sjdName;
    String interviewLevel;
    Integer evaluatorId;
    String evaluatorName;
    Date startDate;
    Date endDate;
    Integer createdById;
    String createdByName;
    String interviewResult;
}
