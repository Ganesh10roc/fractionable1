package com.peopletech.fractionable.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CandidateInterviewDto {
    private Integer id;
    private Integer sjdId;
    private Integer candidateId;
    private String candidateEmail;
    private String candidateName;
    private UserDetailsDto evaluator;
    private String interviewLevel;
    private Date startTime;
    private Date endTime;
    private String feedback;
    private String recording;
    private String interviewResult;
    private Integer createdBy;
    private Date createdOn;
    private Integer modifiedBy;
    private Date modifiedOn;
    private String recruiterEmail;
    private String recruiterName;
    private String meetingLink;
    private String meetingId;
    private String meetingInvitationId;
    private List<String> hiringTeamEmails;
    private UserDetailsDto recruiter;
}
