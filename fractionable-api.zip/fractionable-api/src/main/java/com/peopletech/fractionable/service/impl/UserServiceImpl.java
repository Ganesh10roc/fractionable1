package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.dto.UserDetailsDto;
import com.peopletech.fractionable.dto.request.LoginRequestDto;
import com.peopletech.fractionable.entity.RoleBO;
import com.peopletech.fractionable.entity.UserCredentialBO;
import com.peopletech.fractionable.entity.UserDetailsBO;
import com.peopletech.fractionable.exception.InvalidCredentialsException;
import com.peopletech.fractionable.repository.UserCredentialRepository;
import com.peopletech.fractionable.repository.UserDetailsRepository;
import com.peopletech.fractionable.repository.UserRoleRepository;
import com.peopletech.fractionable.service.UserService;
import com.peopletech.fractionable.util.MicrosoftTokenVerifierUtil;
import jakarta.transaction.Transactional;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Supplier;
import java.util.stream.StreamSupport;

@Service
public class UserServiceImpl implements UserService {
    private UserDetailsRepository userDetailsRepository;
    private UserCredentialRepository userCredentialRepository;
    private DozerBeanMapper mapper;
    private UserRoleRepository userRoleRepository;

    private MicrosoftTokenVerifierUtil microsoftTokenVerifierUtil;

    public UserServiceImpl(UserDetailsRepository userDetailsRepository, UserCredentialRepository userCredentialRepository, DozerBeanMapper mapper, UserRoleRepository userRoleRepository, MicrosoftTokenVerifierUtil microsoftTokenVerifierUtil) {
        this.userDetailsRepository = userDetailsRepository;
        this.userCredentialRepository = userCredentialRepository;
        this.mapper = mapper;
        this.userRoleRepository = userRoleRepository;
        this.microsoftTokenVerifierUtil = microsoftTokenVerifierUtil;
    }

    @Value("${fractionable.default.pwd}")
    private String defaultPwd;


    private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    private final static String ERROR_MESSAGE = "The requested user with id %s is not found";

    @Override
    public UserDetailsBO findByUserId(Integer id) {
        return userDetailsRepository
                .findById(id)
                .orElseThrow(() -> new NoSuchElementException(String.format(ERROR_MESSAGE, id)));
    }

    @Override
    @Deprecated
    public UserDetailsBO validateUserCredentials(LoginRequestDto loginRequest) {
        Supplier<InvalidCredentialsException> expSupplier = () -> new InvalidCredentialsException(String.format("The requested user %s not found", loginRequest.getUsername()));
        UserCredentialBO userCredentials =
                userCredentialRepository
                        .findByUsernameIgnoreCase(loginRequest.getUsername())
                        .orElseThrow(expSupplier);

        boolean isValid = encoder.matches(loginRequest.getPassword(),
                userCredentials.getPassword());

        if (!isValid)
            throw new InvalidCredentialsException("Invalid Credentials");

        return userDetailsRepository.findByEmailIgnoreCase(loginRequest.getUsername()).orElseThrow(expSupplier);
    }

    @Override
    public UserDetailsBO authenticateToken(String accessToken) {
        String email = microsoftTokenVerifierUtil.verifyToken(accessToken);
        if (email == null)
            throw new InvalidCredentialsException("Authentication failed by Microsoft token verifier!");
        return userDetailsRepository.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new InvalidCredentialsException("Authentication failed, user not found in database"));
    }

    @Override
    public UserDetailsDto createUser(UserDetailsDto userDetails, Integer userId) {
        UserDetailsBO userDetailsBO = new UserDetailsBO();
        mapper.map(userDetails, userDetailsBO);
        userDetailsRepository.findByEmailIgnoreCase(userDetailsBO.getEmail()).ifPresent(user -> {
            throw new IllegalArgumentException("User with the email " + userDetailsBO.getEmail() + " already Exist.");
        });
        userDetailsBO.setActive(true);
        userDetailsBO.setLocked(false);
        userDetailsBO.setCreatedBy(userId);
        userDetailsBO.setCreatedOn(new Date());
        userDetailsBO.setModifiedBy(userId);
        userDetailsBO.setModifiedOn(new Date());
        UserDetailsBO result = userDetailsRepository.save(userDetailsBO);

        UserCredentialBO credentialBO = new UserCredentialBO();
        credentialBO.setUserId(result.getId());
        credentialBO.setUsername(result.getEmail());
        credentialBO.setPassword(encoder.encode(defaultPwd));
        credentialBO.setModifiedOn(new Date());
        userCredentialRepository.save(credentialBO);
        return mapper.map(result, UserDetailsDto.class);
    }

    @Override
    @Transactional
    public UserDetailsDto updateUser(UserDetailsDto userDetails, Integer userId) {
        UserDetailsBO userDetailsBO = userDetailsRepository
                                        .findById(userDetails.getId())
                                        .orElseThrow(() -> new NoSuchElementException(String.format(ERROR_MESSAGE, userId)));
        userDetailsBO.setRoles(new ArrayList<>());
        mapper.map(userDetails, userDetailsBO);
        userDetailsBO.setModifiedBy(userId);
        userDetailsBO.setModifiedOn(new Date());
        userDetailsRepository.save(userDetailsBO);
        return mapper.map(userDetailsBO, UserDetailsDto.class);
    }

    @Override
    public List<UserDetailsDto> getUsersByRole(Integer roleId) {
        List<UserDetailsBO> userDetails = userDetailsRepository.findByRolesAndActive(new RoleBO(roleId, null), true);
        return userDetails
                .stream()
                .map(user -> mapper.map(user, UserDetailsDto.class))
                .toList();
    }

    @Override
    public void changePassword(Integer userId, String password) {
        UserCredentialBO userCredentialBO = userCredentialRepository
                .findByUserId(userId)
                .orElseThrow(() -> new NoSuchElementException(String.format("User with id %s is not found", userId)));
        userCredentialBO.setPassword(encoder.encode(password));
        userCredentialBO.setModifiedOn(new Date());
        userCredentialRepository.save(userCredentialBO);
    }

    @Override
    public List<UserDetailsDto> getAllUsers() {
        Iterable<UserDetailsBO> userDetails = userDetailsRepository.findAllByActiveAndIsMigratedOrderByFirstNameAsc(true,null);
        return StreamSupport.stream(userDetails.spliterator(), false)
                .map(user -> mapper.map(user, UserDetailsDto.class)).toList();
    }
}
