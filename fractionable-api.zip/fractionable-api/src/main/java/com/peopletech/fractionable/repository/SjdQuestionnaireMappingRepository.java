package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.SjdQuestionnaireMappingBO;
import com.peopletech.fractionable.entity.compoundkey.SjdQuestionnaireID;
import jakarta.persistence.Tuple;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SjdQuestionnaireMappingRepository extends CrudRepository<SjdQuestionnaireMappingBO, SjdQuestionnaireID> {

    @Query(value = "select sjd_id, questionnaire_id from sjd_questionnaire_mapping where questionnaire_id = ?1", nativeQuery = true)
    List<Tuple> findByQuestionnaireId(Integer questionnaireId);
}
