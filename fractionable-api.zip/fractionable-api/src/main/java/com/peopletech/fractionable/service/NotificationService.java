package com.peopletech.fractionable.service;

import com.peopletech.fractionable.dto.NotificationDto;

import java.util.List;

public interface NotificationService {
    Integer saveNotification(NotificationDto notificationDto);
    List<NotificationDto> getAllNotifications();
    void deleteNotification(Integer id);

}
