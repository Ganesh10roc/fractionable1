package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Table(name = "candidate")
public class CandidateBO {

    @Id
    @Column(name = "id")
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "candidate_id_generator")
    @SequenceGenerator(name = "candidate_id_generator", sequenceName = "candidate_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "email")
    private String email;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "location")
    private String location;

    @Column(name = "notice_period_days")
    private Integer noticePeriod;

    @Column(name = "experience")
    private Float experience;

    @Column(name = "resume_id")
    private String resumeId;

    @OneToOne
    @JoinColumn(name = "source_channel_id", referencedColumnName = "id")
    private SourceChannelBO sourceChannel;

    @OneToOne
    @JoinColumn(name = "domain_expertise_id", referencedColumnName = "id")
    private DomainBO domain;

    @Column(name = "present_role")
    private String currentRole;

    @Column(name = "current_ctc")
    private String currentCtc;

    @Column(name = "expected_ctc")
    private String expectedCtc;

    @Column(name = "linkedin_url")
    private String linkedInUrl;

    @Column(name = "visa_type")
    private String visaType;

    @Column(name = "visa_status")
    private String visaStatus;

    @Column(name = "visa_validity")
    private String visaValidity;

    @OneToMany(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
    @JoinColumn(name = "candidate_id", referencedColumnName = "id")
    private List<CandidateEducationBO> educationDetails;

    @OneToMany(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
    @JoinColumn(name = "candidate_id", referencedColumnName = "id")
    private List<CandidateCertificationBO> certificationDetails;

    @OneToMany(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
    @JoinColumn(name = "candidate_id", referencedColumnName = "id")
    private List<CandidateEmploymentBO> employmentDetails;

    @OneToMany(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
    @JoinColumn(name = "candidate_id", referencedColumnName = "id")
    private List<CandidateDocumentBO> documents;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "candidate_skills_mapping",
            joinColumns = @JoinColumn(
                    name = "candidate_id", referencedColumnName = "id"
            ),
            inverseJoinColumns = @JoinColumn(
                    name = "skill_id", referencedColumnName = "id"
            )
    )
    private List<SkillBO> skills = new ArrayList<>();

    @OneToMany(mappedBy = "candidate")
    private List<SjdCandidateInfoBO> sjdCandidateInfo = new ArrayList<>();

    @Column(name = "additional_info")
    private String additionalInfo;

    @Column(name = "created_by_id")
    private Integer createdBy;

    @Column(name = "created_on")
    private Date createdOn;

    @Column(name = "modified_by_id")
    private Integer modifiedBy;

    @Column(name = "modified_on")
    private Date modifiedOn;

    @Column(name = "ai_checkbox")
    private Boolean aiCheckbox;

    @Column(name = "is_migrated")
    private Boolean isMigrated;

    @OneToOne
    @JoinColumn(name = "operations_id", referencedColumnName = "id")
    private OperationsBO operations;

    @OneToOne
    @JoinColumn(name = "current_ctc_frequency", referencedColumnName = "id")
    private PayTypeBO currentCtcFrequency;

    @OneToOne
    @JoinColumn(name = "expected_ctc_frequency", referencedColumnName = "id")
    private PayTypeBO expectedCtcFrequency;
}
