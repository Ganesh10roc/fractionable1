package com.peopletech.fractionable.entity;

import com.peopletech.fractionable.entity.compoundkey.UserLeadID;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "user_lead_mapping")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@IdClass(UserLeadID.class)
public class UserLeadBO {

    @Id
    @OneToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    UserDetailsBO user;
    @Id
    @OneToOne
    @JoinColumn(name = "lead_id", referencedColumnName = "id")
    UserDetailsBO lead;
}
