package com.peopletech.fractionable.entity;

import com.peopletech.fractionable.entity.compoundkey.SjdSkillMappingId;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "sjd_skills_mapping")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class SjdSkillMappingBO {

    @EmbeddedId
    @EqualsAndHashCode.Include
    private SjdSkillMappingId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("sjdId")
    @JoinColumn(name = "sjd_id")
    private SjdBO sjd;

    @ManyToOne
    @MapsId("skillId")
    @JoinColumn(name = "skill_id")
    private SkillBO skill;

    @Column(name = "min_experience")
    private Float minExperience;

    public SjdSkillMappingBO(Integer sjdId, Integer skillId) {
        this.id = new SjdSkillMappingId(sjdId, skillId);
    }
}
