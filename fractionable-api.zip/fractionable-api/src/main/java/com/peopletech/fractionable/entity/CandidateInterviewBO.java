package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "candidate_interview")
public class CandidateInterviewBO {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "candidate_interview_id_generator")
    @SequenceGenerator(name = "candidate_interview_id_generator", sequenceName = "candidate_interview_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "sjd_id")
    private Integer sjdId;

    @Column(name = "candidate_id")
    private Integer candidateId;


    @Column(name = "evaluator_id")
    private Integer evaluatorId;

    @Column(name = "interview_level")
    private String interviewLevel;

    @Column(name = "start_time")
    private Date startTime;

    @Column(name = "end_time")
    private Date endTime;

    @Column(name = "interview_feedback")
    private String feedback;

    @Column(name = "interview_recording_link")
    private String recording;

    @Column(name = "interview_result")
    private String interviewResult;

    @Column(name = "created_by_id")
    private Integer createdBy;

    @Column(name = "created_on")
    private Date createdOn;

    @Column(name = "modified_by_id")
    private Integer modifiedBy;

    @Column(name = "modified_on")
    private Date modifiedOn;

    @Column(name = "meeting_link")
    private String meetingLink;

    @Column(name = "meeting_id")
    private String meetingId;

    @Column(name = "meeting_invitation_id")
    private String meetingInvitationId;

}
