package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.dto.AppResponseDto;
import com.peopletech.fractionable.dto.NotificationDto;
import com.peopletech.fractionable.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notification")
public class NotificationController {
    @Autowired
    private NotificationService notificationService;
    @PostMapping
    public AppResponseDto<Integer> saveNotification(@RequestBody NotificationDto notificationDto){
        Integer id = notificationService.saveNotification(notificationDto);
        return new AppResponseDto<>(id, "Notification added successfully");
    }
    @GetMapping
    public List<NotificationDto> getAllNotifications(){
        return notificationService.getAllNotifications();
    }

    @DeleteMapping("/{id}")
    public AppResponseDto deleteNotification(@PathVariable("id") Integer id) {
        notificationService.deleteNotification(id);
        return new AppResponseDto(null, "Notification deleted successfully");
    }

}
