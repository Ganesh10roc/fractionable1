package com.peopletech.fractionable.constants;

public enum CandidateDetailsType {
    EDUCATION,
    EMPLOYMENT,
    CERTIFICATION
}
