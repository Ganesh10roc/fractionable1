package com.peopletech.fractionable.repository;


import com.peopletech.fractionable.entity.NotificationBO;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface NotificationRepository extends CrudRepository<NotificationBO, Integer> {
    @Query(value = "select * from notification n where n.start_date <= current_timestamp and n.end_date > current_timestamp", nativeQuery = true)
    List<NotificationBO> findAllNotificationsByExpiryDate();
}
