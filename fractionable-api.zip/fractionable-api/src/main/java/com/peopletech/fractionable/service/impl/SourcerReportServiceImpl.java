package com.peopletech.fractionable.service.impl;

import com.peopletech.fractionable.constants.CandidateEventType;
import com.peopletech.fractionable.constants.LookupType;
import com.peopletech.fractionable.dto.LookupDto;
import com.peopletech.fractionable.dto.SourcerReportDto;
import com.peopletech.fractionable.dto.request.ReportRequestDto;
import com.peopletech.fractionable.entity.UserLeadBO;
import com.peopletech.fractionable.repository.CandidateEventRepository;
import com.peopletech.fractionable.repository.MyTeamRepository;
import com.peopletech.fractionable.repository.UserDetailsRepository;
import com.peopletech.fractionable.service.LookupService;
import com.peopletech.fractionable.service.ReportService;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.persistence.Tuple;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SourcerReportServiceImpl implements ReportService<Map<String, List<SourcerReportDto>>, byte[]> {

    @Value("${candidate.profile.url}")
    private String candidateProfileUrl;

    @Autowired
    CandidateEventRepository candidateEventRepository;

    @Autowired
    MyTeamRepository myTeamRepository;

    @Autowired
    UserDetailsRepository userDetailsRepository;

    @Autowired
    LookupService lookupService;

    @Autowired
    CommonUtil commonUtil;

    @Override
    public Map<String, List<SourcerReportDto>> getReport(ReportRequestDto reportRequestDto) {
        List<SourcerReportDto> list = getSourcerReportData(reportRequestDto.getUserId(), reportRequestDto.getFromDate(), reportRequestDto.getToDate(), reportRequestDto.getOperations());
        return list.stream().collect(Collectors.groupingBy(item -> item.getRecruiterName()));
    }

    @Override
    public byte[] getReportExcel(ReportRequestDto reportRequestDto) throws IOException {
        List<SourcerReportDto> list = getSourcerReportData(reportRequestDto.getUserId(), reportRequestDto.getFromDate(), reportRequestDto.getToDate(), reportRequestDto.getOperations());
        Map<String, Integer> headers = new LinkedHashMap<>();
        headers.put("SJD ID", 10);
        headers.put("SJD Name", 20);
        headers.put("Candidate Name", 30);
        headers.put("Candidate Profile", 30);
        headers.put("Phone", 20);
        headers.put("Email", 30);
        headers.put("Experience (years)", 20);
        headers.put("Notice Period (days)", 20);
        headers.put("QC Rating", 15);
        headers.put("profiler Rating", 15);
        headers.put("Current CTC", 15);
        headers.put("Expected CTC", 15);
        headers.put("Status", 50);
        headers.put("Sub Status", 50);
        headers.put("Comments", 50);
        headers.put("Recruiter", 30);
        headers.put("Created On", 30);
        headers.put("Operations", 40);
        headers.put("Client", 30);
        headers.put("Current Role", 30);

        Workbook wb = new HSSFWorkbook();
        Sheet sheet = wb.createSheet("Report");
        int index = 0;
        for (String key : headers.keySet()) {
            sheet.setColumnWidth(index++, 256 * headers.get(key));
        }

        Row row = sheet.createRow(0);
        populateHeaderRow(wb, row, headers.keySet());
        CellStyle center = wb.createCellStyle();
        center.setAlignment(HorizontalAlignment.CENTER);
        for (int i = 0; i < list.size(); i++) {
            Row r = sheet.createRow(i + 1);
            populateDataRow(center, r, list.get(i));
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        wb.write(out);
        out.close();
        wb.close();
        return out.toByteArray();
    }

    private List<SourcerReportDto> getSourcerReportData(Integer userId, Date fromDate, Date toDate, Integer operations) {
        boolean isAdmin = userDetailsRepository
                .findById(userId)
                .orElseThrow(() -> new NoSuchElementException(String.format("The requested user with id %s is not found", userId)))
                .getRoles()
                .stream()
                .anyMatch((role) -> role.getName().equalsIgnoreCase("admin"));

        Calendar from = Calendar.getInstance();
        from.setTime(fromDate);
        from.set(from.get(Calendar.YEAR), from.get(Calendar.MONTH), from.get(Calendar.DATE), 00, 00, 00);


        Calendar to = Calendar.getInstance();
        to.setTime(toDate);
        to.set(to.get(Calendar.YEAR), to.get(Calendar.MONTH), to.get(Calendar.DATE), 23, 59, 59);
        List<Integer> teamMemberIds = new ArrayList<>();
        if (!isAdmin) {
            Collection<UserLeadBO> userLeadBOS = myTeamRepository.findByLeadId(userId);
            teamMemberIds.addAll(userLeadBOS.stream().map(bo -> bo.getUser().getId()).toList());
            teamMemberIds.add(userId);
        }
        List<Integer> operationIds = operations != null ? Arrays.asList(operations) : lookupService.getLookupValues(LookupType.OPERATION).stream().map(LookupDto::getId).toList();
        List<Tuple> tupleData = isAdmin ? candidateEventRepository.findSourcerReportForAdmin(commonUtil.getIdFromName(CandidateEventType.CANDIDATE_TAGGED_TO_SJD.name(), LookupType.CANDIDATE_EVENT_TYPE), fromDate, to.getTime(), operationIds)
                : candidateEventRepository.findSourcerReport(commonUtil.getIdFromName(CandidateEventType.CANDIDATE_TAGGED_TO_SJD.name(), LookupType.CANDIDATE_EVENT_TYPE), teamMemberIds, from.getTime(), to.getTime());
        return tupleData.stream().map(tuple -> mapSourcerTupleToDto(tuple)).toList();
    }


    private SourcerReportDto mapSourcerTupleToDto(Tuple tuple) {
        SourcerReportDto dto = SourcerReportDto.builder()
                .candidateId(tuple.get(0, Integer.class))
                .sjdId(tuple.get(1, Integer.class))
                .sjdName(tuple.get(2, String.class))
                .candidateName(tuple.get(3, String.class))
                .phoneNumber(tuple.get(4, String.class))
                .email(tuple.get(5, String.class))
                .noticePeriod(tuple.get(7, Integer.class))
                .candidateStatus(commonUtil.getNameFromId(tuple.get(14, Integer.class), LookupType.CANDIDATE_STATUS))
                .eventCreatedOn(Date.from(tuple.get(15, Instant.class)))
                .recruiterName(tuple.get(16, String.class))
                .operations(commonUtil.getNameFromId(tuple.get(17, Integer.class), LookupType.OPERATION))
                .client(commonUtil.getNameFromId(tuple.get(18, Integer.class), LookupType.CLIENT))
                .candidateSubStatus(tuple.get(21, String.class))
                .build();
        if (tuple.get(6) != null) {
            dto.setExperience(tuple.get(6, BigDecimal.class).floatValue());
        }

        if (tuple.get(8) != null) {
            dto.setQcRating(tuple.get(8, BigDecimal.class).floatValue());
        }
        if (tuple.get(9) != null) {
            dto.setProfilerRating(tuple.get(9, BigDecimal.class).floatValue());
        }
        if (tuple.get(10) != null) {
            StringBuilder btr = new StringBuilder();
            btr.append(tuple.get(10, String.class));
            if (tuple.get(11) != null) {
                btr.append(" (");
                btr.append(commonUtil.getNameFromId(tuple.get(11, Integer.class), LookupType.PAY_TYPE));
                btr.append(")");
            }
            dto.setCurrentCtc(btr.toString());
        }
        if (tuple.get(12) != null) {
            StringBuilder btr = new StringBuilder();
            btr.append(tuple.get(12, String.class));
            if (tuple.get(13) != null) {
                btr.append(" (");
                btr.append(commonUtil.getNameFromId(tuple.get(13, Integer.class), LookupType.PAY_TYPE));
                btr.append(")");
            }
            dto.setExpectedCtc(btr.toString());
        }
        if (tuple.get(19) != null) {
            dto.setComment(tuple.get(19, String.class));
        }
        if (tuple.get(20) != null) {
            dto.setCurrentRole(tuple.get(20, String.class));
        }

        return dto;
    }

    private CellStyle createBorderStyle(Workbook wb) {
        BorderStyle thin = BorderStyle.THIN;
        Short black = IndexedColors.BLACK.getIndex();
        CellStyle style = wb.createCellStyle();
        style.setBorderTop(thin);
        style.setTopBorderColor(black);
        style.setBorderRight(thin);
        style.setRightBorderColor(black);
        style.setBorderBottom(thin);
        style.setBottomBorderColor(black);
        style.setBorderLeft(thin);
        style.setLeftBorderColor(black);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private void populateHeaderRow(Workbook wb, Row row, Set<String> headers) {
        CellStyle headerStyle = createBorderStyle(wb);
        Font font = wb.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        int index = 0;
        for (String header : headers) {
            Cell cell = row.createCell(index++);
            cell.setCellStyle(headerStyle);
            cell.setCellValue(header);
        }
    }

    private void populateDataRow(CellStyle center, Row r, SourcerReportDto report) {
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(2);
        Cell sjdId = r.createCell(0);
        sjdId.setCellValue(report.getSjdId());

        Cell sjdName = r.createCell(1);
        sjdName.setCellValue(report.getSjdName());

        Cell candidateName = r.createCell(2);
        candidateName.setCellValue(report.getCandidateName());

        Cell candidateProfileUrl = r.createCell(3);
        candidateProfileUrl.setCellValue(
                this.candidateProfileUrl.replace("{sjdId}", Base64.getEncoder().encodeToString(String.valueOf(report.getSjdId()).getBytes())).replace("{candidateId}", Base64.getEncoder().encodeToString(String.valueOf(report.getCandidateId()).getBytes()))
        );

        Cell phoneNumber = r.createCell(4);
        phoneNumber.setCellValue(report.getPhoneNumber());

        Cell email = r.createCell(5);
        email.setCellValue(report.getEmail());

        Cell experience = r.createCell(6);
        experience.setCellStyle(center);
        experience.setCellValue(nf.format(report.getExperience()));

        Cell noticePeriod = r.createCell(7);
        noticePeriod.setCellStyle(center);
        noticePeriod.setCellValue(report.getNoticePeriod());

        Cell qcRating = r.createCell(8);
        qcRating.setCellStyle(center);
        if (report.getQcRating() != null)
            qcRating.setCellValue(nf.format(report.getQcRating()));

        Cell profilerRating = r.createCell(9);
        profilerRating.setCellStyle(center);
        if (report.getProfilerRating() != null)
            profilerRating.setCellValue(nf.format(report.getProfilerRating()));

        Cell currentCtc = r.createCell(10);
        currentCtc.setCellStyle(center);
        currentCtc.setCellValue(report.getCurrentCtc());

        Cell expectedCtc = r.createCell(11);
        expectedCtc.setCellStyle(center);
        expectedCtc.setCellValue(report.getExpectedCtc());

        Cell candidateStatus = r.createCell(12);
        candidateStatus.setCellValue(report.getCandidateStatus());

        Cell candidateSubStatus = r.createCell(13);
        candidateSubStatus.setCellValue(report.getCandidateSubStatus());


        Cell comment = r.createCell(14);
        comment.setCellValue(report.getComment());


        Cell recruiter = r.createCell(15);
        recruiter.setCellValue(report.getRecruiterName());

        DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy hh:mm a");

        Cell createdOn = r.createCell(16);
        createdOn.setCellValue(dateFormatter.format(report.getEventCreatedOn()));

        Cell operations = r.createCell(17);
        operations.setCellValue(report.getOperations());

        Cell client = r.createCell(18);
        client.setCellValue(report.getClient());

        Cell currentRole = r.createCell(19);
        currentRole.setCellValue(report.getCurrentRole());
    }

}
