package com.peopletech.fractionable.service;

import com.peopletech.fractionable.dto.request.ReportRequestDto;

import java.io.IOException;

public interface ReportService<K, V> {

    K getReport(ReportRequestDto reportRequestDto);

    V getReportExcel(ReportRequestDto reportRequestDto) throws IOException;

}
