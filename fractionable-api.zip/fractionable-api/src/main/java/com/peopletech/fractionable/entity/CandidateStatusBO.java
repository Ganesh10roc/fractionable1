package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "candidate_status_lookup")
public class CandidateStatusBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "candidate_status_lookup_id_generator")
    @SequenceGenerator(name = "candidate_status_lookup_id_generator", sequenceName = "candidate_status_lookup_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;
}
