package com.peopletech.fractionable.dto;

import lombok.Data;

@Data
public class CandidateStatusChangeDto {
    private Integer candidateId;
    private Integer sjdId;
    private Integer statusId;
    private String reason;
}
