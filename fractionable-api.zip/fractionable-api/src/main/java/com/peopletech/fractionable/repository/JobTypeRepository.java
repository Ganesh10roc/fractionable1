package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.JobTypeBO;
import org.springframework.data.repository.CrudRepository;

public interface JobTypeRepository extends CrudRepository<JobTypeBO, Integer> {
}
