package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.SourceChannelBO;
import org.springframework.data.repository.CrudRepository;

public interface SourceChannelRepository extends CrudRepository<SourceChannelBO, Integer> {
}
