package com.peopletech.fractionable.entity.compoundkey;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserLeadID implements Serializable {
    private Integer user;
    private Integer lead;
}
