package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Entity
@Data
@Table(name = "candidate_events")
public class CandidateEventBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "candidate_events_id_generator")
    @SequenceGenerator(name = "candidate_events_id_generator", sequenceName = "candidate_events_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "sjd_id")
    private Integer sjdId;

    @Column(name = "candidate_id")
    private Integer candidateId;

    @OneToOne
    @JoinColumn(name = "event_type_id", referencedColumnName = "id")
    private CandidateEventTypeBO eventType;

    @Column(name = "description")
    private String description;

    @OneToOne
    @JoinColumn(name = "created_by_id", referencedColumnName = "id")
    private UserDetailsBO createdBy;

    @Column(name = "created_on")
    private Date createdOn;
}
