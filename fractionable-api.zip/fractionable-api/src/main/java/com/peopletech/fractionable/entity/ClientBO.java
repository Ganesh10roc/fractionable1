package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "client_lookup")
public class ClientBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "client_lookup_id_generator")
    @SequenceGenerator(name = "client_lookup_id_generator", sequenceName = "client_lookup_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;
}
