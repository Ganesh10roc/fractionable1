package com.peopletech.fractionable.dto;

import lombok.Data;

import java.util.Date;

@Data
public class CandidateDocumentDto {
    private Integer id;
    private Integer candidateId;
    private String documentName;
    private String fileName;
    private String documentUrl;
    private String createdByName;
    private Date createdOn;
}
