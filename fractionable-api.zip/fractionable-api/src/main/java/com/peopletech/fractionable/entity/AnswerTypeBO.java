package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "answer_type_lookup")
public class AnswerTypeBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "answer_type_lookup_id_generator")
    @SequenceGenerator(name = "answer_type_lookup_id_generator", sequenceName = "answer_type_lookup_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;
}