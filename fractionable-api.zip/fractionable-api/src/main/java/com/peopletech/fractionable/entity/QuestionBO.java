package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "questions")
public class QuestionBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "questions_id_generator")
    @SequenceGenerator(name = "questions_id_generator", sequenceName = "questions_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "question")
    private String question;

    @Column(name = "required")
    private Boolean required;

    @OneToOne
    @JoinColumn(name = "answer_type_id", referencedColumnName = "id")
    private AnswerTypeBO answerType;
}