package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "candidate_education")
public class CandidateEducationBO {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "candidate_education_id_generator")
    @SequenceGenerator(name = "candidate_education_id_generator", sequenceName = "candidate_education_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "candidate_id")
    private Integer candidateId;

    @Column(name = "institution_name")
    private String institution;

    @Column(name = "location")
    private String location;

    @Column(name = "qualification")
    private String qualification;

    @Column(name = "domain")
    private String domain;

    @Column(name = "start_date")
    private Date startDate;

    @Column(name = "end_date")
    private Date endDate;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CandidateEducationBO that = (CandidateEducationBO) o;
        if (id != null || that.id != null)
            return Objects.equals(id, that.id);
        else
            return Objects.equals(startDate, that.startDate) && Objects.equals(endDate, that.endDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, startDate, endDate);
    }
}
