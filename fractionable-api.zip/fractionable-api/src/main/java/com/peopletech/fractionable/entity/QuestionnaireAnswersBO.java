package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "questionnaire_answers")
public class QuestionnaireAnswersBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "questionnaire_answers_id_generator")
    @SequenceGenerator(name = "questionnaire_answers_id_generator", sequenceName = "questionnaire_answers_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "sjd_id")
    private Integer sjdId;

    @Column(name = "questionnaire_id")
    private Integer questionnaireId;
    @Column(name = "question_id")
    private Integer questionId;
    @Column(name = "candidate_id")
    private Integer candidateId;
    @Column(name = "answer")
    private String answer;


}
