package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.SjdSkillMappingBO;
import com.peopletech.fractionable.entity.compoundkey.SjdSkillMappingId;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SjdSkillMappingRepository extends CrudRepository<SjdSkillMappingBO, SjdSkillMappingId> {

    List<SjdSkillMappingBO> findAllBySjdId(Integer sjdId);

}