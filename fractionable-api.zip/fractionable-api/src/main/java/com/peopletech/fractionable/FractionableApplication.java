package com.peopletech.fractionable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@SpringBootApplication
@EnableAspectJAutoProxy
@EnableWebSecurity
@EnableCaching
public class FractionableApplication {

    public static void main(String[] args) {
        SpringApplication.run(FractionableApplication.class, args);
    }

}
