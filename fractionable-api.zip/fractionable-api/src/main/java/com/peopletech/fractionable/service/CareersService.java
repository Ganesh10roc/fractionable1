package com.peopletech.fractionable.service;

import com.peopletech.fractionable.dto.SjdDto;

import java.util.List;

public interface CareersService {
    List<SjdDto> getSjd();
}