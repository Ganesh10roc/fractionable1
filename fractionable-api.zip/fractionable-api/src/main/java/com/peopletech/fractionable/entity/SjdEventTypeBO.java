package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "sjd_event_types_lookup")
public class SjdEventTypeBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sjd_event_types_lookup_id_generator")
    @SequenceGenerator(name = "sjd_event_types_lookup_id_generator", sequenceName = "sjd_event_types_lookup_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;
}
