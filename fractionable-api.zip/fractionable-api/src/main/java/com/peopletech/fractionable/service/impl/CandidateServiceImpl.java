package com.peopletech.fractionable.service.impl;

import com.microsoft.graph.models.Event;
import com.microsoft.graph.models.OnlineMeeting;
import com.peopletech.fractionable.constants.*;
import com.peopletech.fractionable.dto.*;
import com.peopletech.fractionable.dto.request.CandidateDetailsDeleteRequest;
import com.peopletech.fractionable.dto.request.CandidateRejectOrCallbackRequest;
import com.peopletech.fractionable.dto.request.CandidateSubStatusChangeRequest;
import com.peopletech.fractionable.dto.request.TagCandidateRequest;
import com.peopletech.fractionable.entity.*;
import com.peopletech.fractionable.entity.compoundkey.SjdCandidateInfoId;
import com.peopletech.fractionable.repository.*;
import com.peopletech.fractionable.service.*;
import com.peopletech.fractionable.specifications.CandidateSpecifications;
import com.peopletech.fractionable.util.CommonUtil;
import jakarta.transaction.Transactional;
import org.apache.commons.lang3.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.StreamSupport;

@Service
public class CandidateServiceImpl implements CandidateService {

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private SjdRepository sjdRepository;

    @Autowired
    private SjdCandidateInfoRepository sjdCandidateInfoRepository;

    @Autowired
    private CandidateDocumentRepository candidateDocumentRepository;

    @Autowired
    private CandidateEventService candidateEventService;

    @Autowired
    private SjdService sjdService;

    @Autowired
    private CandidateEventRepository candidateEventRepository;

    @Autowired
    private CandidateInterviewRepository candidateInterviewRepository;

    @Autowired
    private CandidateSkillMappingRepository candidateSkillMappingRepository;

    @Autowired
    private UserDetailsRepository userDetailsRepository;

    @Autowired
    private LookupService lookupService;

    @Autowired
    private CommonUtil commonUtil;

    @Autowired
    private CandidateEmploymentRepository candidateEmploymentRepository;

    @Autowired
    private CandidateEducationRepository candidateEducationRepository;

    @Autowired
    private CandidateCertificationRepository candidateCertificationRepository;

    @Autowired
    private DozerBeanMapper mapper;

    @Autowired
    private MicrosoftService microsoftService;

    @Value("${fractionable.minimum.rating}")
    private Float minimumRating;


    @Override
    public CandidateDto getCandidateById(Integer candidateId, Integer sjdId) {
        CandidateBO candidateBO = candidateRepository
                .findById(candidateId)
                .orElseThrow(() -> new NoSuchElementException(String.format("The requested candidate with id %s is not found", candidateId)));
        CandidateDto candidateDto = mapper.map(candidateBO, CandidateDto.class);
        if (sjdId != null) {

            List<CandidateInterviewBO> candidateInterview = candidateInterviewRepository.findBySjdIdAndCandidateId(sjdId, candidateId);

            List<CandidateInterviewDto> interviewDtos = candidateInterview.stream().map(interview -> {
                CandidateInterviewDto dto = mapper.map(interview, CandidateInterviewDto.class);
                dto.setEvaluator(
                        mapper.map(userDetailsRepository.findById(interview.getEvaluatorId()).get(), UserDetailsDto.class)
                );
                return dto;
            }).toList();

            candidateDto.setInterview(interviewDtos);
            List<CandidateEventDto> candidateEvents = commonUtil.mapList(
                    candidateEventRepository
                            .findBySjdIdAndCandidateIdOrderByCreatedOnDesc(sjdId, candidateId),
                    CandidateEventDto.class);
            candidateDto.setEvents(candidateEvents);
        }
        return candidateDto;
    }

    @Override
    public List<CandidateDto> getCandidateBySjdId(Integer sjdId) {
        List<SjdCandidateInfoBO> candidates = sjdCandidateInfoRepository.findBySjdId(sjdId);
        return candidates
                .stream()
                .map(c -> mapper.map(c.getCandidate(), CandidateDto.class))
                .toList();
    }

    @Override
    public List<CandidateDto> getAllCandidates() {
        Iterable<CandidateBO> itr = candidateRepository.findAll();
        return StreamSupport
                .stream(itr.spliterator(), false)
                .map(bo -> mapper.map(bo, CandidateDto.class))
                .toList();
    }

    @Override
    @Transactional
    public Integer saveCandidate(CandidateDto candidate, Integer sjdId, Integer userId) {

        List<String> allSkills = lookupService.getSkills().stream().map(s -> s.getName().toLowerCase()).toList();

        List<SkillBO> existingSkills = new ArrayList<>();
        List<LookupDto> newSkills = new ArrayList<>();

        candidate.getSkills().stream().forEach(s -> {
            if (allSkills.contains(s.getName().toLowerCase())) {
                existingSkills.add(mapper.map(s, SkillBO.class));
            } else {
                newSkills.add(s);
            }
        });

        List<SkillBO> skills = lookupService.saveAllSkills(newSkills);
        skills.addAll(existingSkills);

        CandidateBO candidateBO = mapper.map(candidate, CandidateBO.class);
        candidateBO.setSkills(skills);
        candidateBO.setCreatedBy(userId);
        candidateBO.setCreatedOn(new Date());
        candidateBO.setModifiedBy(userId);
        candidateBO.setModifiedOn(new Date());
        CandidateBO result = candidateRepository.save(candidateBO);
        if (sjdId != null) {
            CandidateEventDto candidateEvent =
                    CandidateEventDto
                            .builder()
                            .sjdId(sjdId)
                            .candidateId(result.getId())
                            .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_CREATED.name()).getId())
                            .description(String.valueOf(result.getId()))
                            .build();
            candidateEventService.addEvent(candidateEvent, userId);

            TagCandidateRequest info = new TagCandidateRequest(sjdId, result.getId(), null);
            sjdService.tagCandidateToSjd(info, userId);
        }

        return result.getId();
    }

    @Override
    @Transactional
    public Integer updateCandidate(CandidateDto candidate, Integer sjdId, Integer userId, Boolean isResumeUpdate) {
        CandidateBO candidateBO = candidateRepository
                .findById(candidate.getId())
                .orElseThrow(() -> new NoSuchElementException(String.format("The requested candidate with id %s is not found", candidate.getId())));

        List<String> allSkills = lookupService.getSkills().stream().map(s -> s.getName().toLowerCase()).toList();

        List<SkillBO> existingSkills = new ArrayList<>();
        List<LookupDto> newSkills = new ArrayList<>();

        candidate.getSkills().stream().forEach(s -> {
            if (allSkills.contains(s.getName().toLowerCase())) {
                existingSkills.add(mapper.map(s, SkillBO.class));
            } else {
                newSkills.add(s);
            }
        });
        List<SkillBO> skills = lookupService.saveAllSkills(newSkills);
        skills.addAll(existingSkills);
/*
        List<Integer> skillsInNewObject = skills.stream().map(SkillBO::getId).toList();

        List<CandidateSkillID> skillsToBeDeleted = candidateBO.getSkills()
                .stream()
                .filter(skill -> !skillsInNewObject.contains(skill.getId()))
                .map(skill -> new CandidateSkillID(candidate.getId(), skill.getId()))
                .collect(Collectors.toList());

        candidateSkillMappingRepository.deleteAllById(skillsToBeDeleted);
*/
        mapper.map(candidate, candidateBO);
        candidateBO.setSkills(skills);
        candidateBO.setModifiedBy(userId);
        candidateBO.setModifiedOn(new Date());
        CandidateBO result = candidateRepository.save(candidateBO);
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(sjdId)
                        .candidateId(candidate.getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(
                                isResumeUpdate ? CandidateEventType.RESUME_UPDATED.name() : CandidateEventType.CANDIDATE_DETAILS_UPDATED.name()
                        ).getId())
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
        return result.getId();
    }

    @Override
    public void updateCandidateStatus(CandidateStatusChangeDto request, Integer userId) {
        CandidateStatusBO status = new CandidateStatusBO();
        status.setId(request.getStatusId());
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        info.setCandidateStatus(status);
        info.setCandidateSubStatus(null);
        info.setComment(null);
        String newStatus = commonUtil.getNameFromId(request.getStatusId(), LookupType.CANDIDATE_STATUS);
        CandidateEventType eventType = CandidateEventType.CANDIDATE_STATUS_CHANGED;
        String description = newStatus;
        if (newStatus.equalsIgnoreCase(CandidateStatusType.CANDIDATE_REJECTED.getType())) {
            eventType = CandidateEventType.CANDIDATE_REJECTED;
            description = request.getReason();
            info.setComment(request.getReason());
        } else if (newStatus.equalsIgnoreCase(CandidateStatusType.CALLBACK.getType())) {
            eventType = CandidateEventType.CALLBACK_ADDED;
            description = request.getReason();
            info.setComment(request.getReason());
        } else if (newStatus.equalsIgnoreCase(CandidateStatusType.CANDIDATE_NOT_INTERESTED.getType())) {
            eventType = CandidateEventType.NOT_INTERESTED;
            description = request.getReason();
            info.setComment(request.getReason());
        } else {
            info.setComment(null);
        }
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(eventType.name()).getId())
                        .description(description)
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
        sjdCandidateInfoRepository.save(info).getId();
    }

    @Override
    public void updateCandidateSubStatus(CandidateSubStatusChangeRequest request, Integer userId) {
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        info.setCandidateSubStatus(request.getSubStatus());
        info.setComment(request.getComment());
        sjdCandidateInfoRepository.save(info);

        CandidateEventType eventType;

        switch (CandidateSubStatus.get(request.getSubStatus())) {
            case CALL_BACK -> eventType = CandidateEventType.CALLBACK_ADDED;
            case REJECTED -> eventType = CandidateEventType.CANDIDATE_REJECTED;
            case NOT_INTERESTED -> eventType = CandidateEventType.NOT_INTERESTED;
            case ON_HOLD -> eventType = CandidateEventType.CANDIDATE_ON_HOLD;
            case DROPPED -> eventType = CandidateEventType.CANDIDATE_DROPPED;
            default -> eventType = CandidateEventType.CANDIDATE_STATUS_CHANGED;
        }

        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(eventType.name()).getId())
                        .description(request.getComment())
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
    }

    @Override
    public void updateCandidateQcRating(SjdCandidateInfoDto request, Integer userId) {
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        info.setQcRating(request.getQcRating());

        // For newly rated, change the status. For rating update, do not change the status.
        info.setCandidateStatus(commonUtil.getCandidateStatus(CandidateStatusType.QC_RATED.getType()));
        if (request.getQcRating() < minimumRating) {
            info.setCandidateSubStatus(CandidateSubStatus.REJECTED.getValue());
            info.setComment(RejectReasons.LOW_RATING.getType());
        } else {
            info.setComment(null);
            info.setCandidateSubStatus(null);
        }
        sjdCandidateInfoRepository.save(info);

        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.QC_RATING_ADDED.name()).getId())
                        .description(String.valueOf(request.getQcRating()))
                        .build();

        // Add an event for candidate rated
        candidateEventService.addEvent(candidateEvent, userId);

        // Add an event for candidate status update
        if (request.getQcRating() < minimumRating) {
            candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_REJECTED.name()).getId());
            candidateEvent.setDescription(RejectReasons.LOW_RATING.getType());
            candidateEventService.addEvent(candidateEvent, userId);
        }
    }

    @Override
    public void updateCandidateProfilerRating(SjdCandidateInfoDto request, Integer userId) {
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        Float existingRating = info.getProfilerRating();
        String existingStatus = info.getCandidateStatus().getName();
        info.setProfilerRating(request.getProfilerRating());

        // For newly rated, change the status. For rating update, do not change the status.
        info.setCandidateStatus(commonUtil.getCandidateStatus(CandidateStatusType.PROFILER_RATED.getType()));
        if (request.getProfilerRating() < minimumRating) {
            info.setCandidateSubStatus(CandidateSubStatus.REJECTED.getValue());
            info.setComment(RejectReasons.LOW_RATING.getType());
        } else {
            info.setComment(null);
            info.setCandidateSubStatus(null);
        }

        sjdCandidateInfoRepository.save(info);

        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.PROFILER_RATING_ADDED.name()).getId())
                        .description(String.valueOf(request.getProfilerRating()))
                        .build();

        // Add an event for candidate rated
        candidateEventService.addEvent(candidateEvent, userId);

        // Add an event for candidate status update
        if (request.getProfilerRating() < minimumRating) {
            candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_REJECTED.name()).getId());
            candidateEvent.setDescription(RejectReasons.LOW_RATING.getType());
            candidateEventService.addEvent(candidateEvent, userId);
        }
    }

    @Override
    public Integer addComments(CandidateEventDto request, Integer userId) {
        request.setEventTypeId(
                commonUtil.getCandidateEventTypeId(CandidateEventType.COMMENTS_ADDED.name()).getId()
        );
        return candidateEventService.addEvent(request, userId);
    }

    @Override
    public void rejectOrCallback(CandidateRejectOrCallbackRequest request, Integer userId) {
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));

        info.setCandidateStatus(commonUtil.getCandidateStatus(
                "Reject".equalsIgnoreCase(request.getType()) ? CandidateStatusType.CANDIDATE_REJECTED.getType() : CandidateStatusType.CALLBACK.getType()
        ));
        sjdCandidateInfoRepository.save(info).getId();
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(
                                "Reject".equalsIgnoreCase(request.getType()) ? CandidateEventType.CANDIDATE_REJECTED.name() : CandidateEventType.CALLBACK_ADDED.name()).getId())
                        .description(request.getReason() != null ? request.getReason() : request.getComment())
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
    }

    @Override
    public void scheduleInterview(CandidateInterviewDto request, Integer userId, String accessToken) throws ParseException {
        request.setRecruiter(mapper.map(userDetailsRepository.findById(userId).get(), UserDetailsDto.class));
        OnlineMeeting teamsMeeting = microsoftService.scheduleTeamsMeeting(request, accessToken);
        Event meetingInvitation = microsoftService.sendMeetingInviteByMail(request, accessToken, teamsMeeting);

        CandidateInterviewBO candidateInterview = mapper.map(request, CandidateInterviewBO.class);
        candidateInterview.setEvaluatorId(request.getEvaluator().getId());
        candidateInterview.setMeetingLink(teamsMeeting.joinWebUrl);
        candidateInterview.setMeetingId(teamsMeeting.id);
        candidateInterview.setMeetingInvitationId(meetingInvitation.id);
        candidateInterview.setCreatedBy(userId);
        candidateInterview.setCreatedOn(new Date());
        candidateInterview.setModifiedBy(userId);
        candidateInterview.setModifiedOn(new Date());
        candidateInterviewRepository.save(candidateInterview);
        String level = candidateInterview.getInterviewLevel();

        CandidateStatusType status = candidateInterview.getInterviewLevel().startsWith("HR") ?
                CandidateStatusType.HR_INTERVIEW_SCHEDULED : CandidateStatusType.get("Tech Interview-".concat(level.substring(level.length() - 1)).concat(" Scheduled"));
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        info.setCandidateStatus(commonUtil.getCandidateStatus(status.getType()));
        info.setCandidateSubStatus(null);
        info.setComment(null);
        sjdCandidateInfoRepository.save(info);
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(info.getSjd().getId())
                        .candidateId(info.getCandidate().getId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_STATUS_CHANGED.name()).getId())
                        .description(status.getType())
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);

        String date = (new SimpleDateFormat("dd/MM/yyyy")).format(request.getStartTime());
        DateFormat timeFormatter = new SimpleDateFormat("hh:mm a z");
        if (request.getRecruiter().getOperations() == 1) {
            timeFormatter.setTimeZone(TimeZone.getTimeZone("IST"));
        } else {
            timeFormatter.setTimeZone(TimeZone.getTimeZone("EDT"));
        }

        String startTime = timeFormatter.format(request.getStartTime());
        String endTime = timeFormatter.format(request.getEndTime());

        candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.INTERVIEW_SCHEDULED.name()).getId());
        candidateEvent.setDescription(
                date
                        .concat(" ")
                        .concat(startTime)
                        .concat(" - ")
                        .concat(endTime)
        );
        candidateEventService.addEvent(candidateEvent, userId);
    }

    @Override
    public void updateInterviewDetails(CandidateInterviewDto request, Integer userId, Boolean isFeedback, String accessToken) throws ParseException {
        request.setRecruiter(mapper.map(userDetailsRepository.findById(userId).get(), UserDetailsDto.class));
        // Get existing interview info from database
        CandidateInterviewBO candidateInterview = candidateInterviewRepository
                .findById(request.getId())
                .orElseThrow(() -> new NoSuchElementException(String.format("No interview schedule exists between sjd id %s, candidate id %s and evaluator id %s", request.getSjdId(), request.getCandidateId(), request.getEvaluator().getId())));
        String oldInterviewResult = candidateInterview.getInterviewResult();

        // Update database with the new information info
        mapper.map(request, candidateInterview);
        candidateInterview.setEvaluatorId(request.getEvaluator().getId());
        candidateInterview.setModifiedBy(userId);
        candidateInterview.setModifiedOn(new Date());
        if (!isFeedback && request.getMeetingId() != null) {
            OnlineMeeting teamsMeeting = microsoftService.scheduleTeamsMeeting(request, accessToken);
            Event meetingInvitation = microsoftService.sendMeetingInviteByMail(request, accessToken, teamsMeeting);
            candidateInterview.setMeetingLink(teamsMeeting.joinWebUrl);
            candidateInterview.setMeetingId(teamsMeeting.id);
            candidateInterview.setMeetingInvitationId(meetingInvitation.id);
        }
        candidateInterviewRepository.save(candidateInterview);

        if (isFeedback) {
            // If it is feedback submission, add an event for the same
            saveFeedbackAddedEvent(request, userId);

            // If it is a new feedback or a change of feedback from On Hold then update the status accordingly
            if ((oldInterviewResult == null) || InterviewResult.ON_HOLD.getType().equalsIgnoreCase(oldInterviewResult)) {
                updateCandidateStatusAfterInterview(candidateInterview, userId);
            }

        } else {
            // If it is not a feedback request, it will be an interview reschedule event.
            // Add an event for the same.
            saveInterviewRescheduleEvent(request, userId);
        }
    }

    private void updateCandidateStatusAfterInterview(CandidateInterviewBO candidateInterview, Integer userId) {
        SjdCandidateInfoBO info = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(candidateInterview.getSjdId(), candidateInterview.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", candidateInterview.getCandidateId(), candidateInterview.getSjdId())));

        String level = candidateInterview.getInterviewLevel();
        String interviewResult = candidateInterview.getInterviewResult();
        String description = null;
        CandidateEventType eventType = null;
        if (InterviewResult.ON_HOLD.getType().equalsIgnoreCase(interviewResult)) {
            info.setCandidateSubStatus(CandidateSubStatus.ON_HOLD.getValue());
            info.setComment("Interview decision pending");
            description = "Interview decision pending";
            eventType = CandidateEventType.CANDIDATE_ON_HOLD;
        } else if (InterviewResult.REJECTED.getType().equalsIgnoreCase(interviewResult)) {
            info.setCandidateSubStatus(CandidateSubStatus.REJECTED.getValue());
            info.setComment(RejectReasons.FAILED_IN_INTERVIEW.getType());
            description = RejectReasons.FAILED_IN_INTERVIEW.getType();
            eventType = CandidateEventType.CANDIDATE_REJECTED;
        } else if (InterviewResult.SELECTED.getType().equalsIgnoreCase(interviewResult)) {
            CandidateStatusType status = null;
            if (level.startsWith("HR")) {
                status = CandidateStatusType.HR_INTERVIEW_CLEARED;
            } else if (level.startsWith("Technical-")) {
                status = CandidateStatusType.get("Tech Interview-".concat(level.substring(level.length() - 1)).concat(" cleared"));
            }
            info.setCandidateStatus(commonUtil.getCandidateStatus(status.getType()));
            info.setCandidateSubStatus(null);
            info.setComment(null);
            description = status.getType();
            eventType = CandidateEventType.CANDIDATE_STATUS_CHANGED;
        }
        sjdCandidateInfoRepository.save(info);

        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(candidateInterview.getSjdId())
                        .candidateId(candidateInterview.getCandidateId())
                        .build();
        candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(eventType.name()).getId());
        candidateEvent.setDescription(description);
        candidateEventService.addEvent(candidateEvent, userId);
    }


    private void saveInterviewRescheduleEvent(CandidateInterviewDto request, Integer userId) {
        String date = (new SimpleDateFormat("dd/MM/yyyy")).format(request.getStartTime());
        DateFormat timeFormatter = new SimpleDateFormat("hh:mm a z");
        if (request.getRecruiter().getOperations() == 1) {
            timeFormatter.setTimeZone(TimeZone.getTimeZone("IST"));
        } else {
            timeFormatter.setTimeZone(TimeZone.getTimeZone("EDT"));
        }
        String startTime = timeFormatter.format(request.getStartTime());
        String endTime = timeFormatter.format(request.getEndTime());
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(request.getSjdId())
                        .candidateId(request.getCandidateId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.INTERVIEW_RESCHEDULED.name()).getId())
                        .description(
                                date
                                        .concat(" ")
                                        .concat(startTime)
                                        .concat(" - ")
                                        .concat(endTime)
                        ).build();
        candidateEventService.addEvent(candidateEvent, userId);
    }

    private void saveFeedbackAddedEvent(CandidateInterviewDto request, Integer userId) {
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(request.getSjdId())
                        .candidateId(request.getCandidateId())
                        .description(request.getFeedback())
                        .build();
        candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.FEEDBACK_ADDED.name()).getId());
        candidateEventService.addEvent(candidateEvent, userId);
    }

//    private void saveStatusChangeEvent(CandidateInterviewDto request, CandidateStatusType candidateStatus, Integer userId) {
//        CandidateEventDto candidateEvent =
//                CandidateEventDto
//                        .builder()
//                        .sjdId(request.getSjdId())
//                        .candidateId(request.getCandidateId())
//                        .description(request.getFeedback())
//                        .build();
//        candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.FEEDBACK_ADDED.name()).getId());
//        if (InterviewResult.REJECTED.getType().equalsIgnoreCase(request.getInterviewResult())) {
//            candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_REJECTED.name()).getId());
//            candidateEvent.setDescription(RejectReasons.FAILED_IN_INTERVIEW.getType());
//        } else {
//            candidateEvent.setEventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.CANDIDATE_STATUS_CHANGED.name()).getId());
//            candidateEvent.setDescription(candidateStatus.getType());
//        }
//
//        candidateEventService.addEvent(candidateEvent, userId);
//    }

    @Override
    public Integer addDocumentInformation(CandidateDocumentDto document, Integer userId) {
        CandidateDocumentBO candidateDocumentBO = mapper.map(document, CandidateDocumentBO.class);
        candidateDocumentBO.setCreatedBy(UserDetailsBO.builder().id(userId).build());
        candidateDocumentBO.setCreatedOn(new Date());
        return candidateDocumentRepository.save(candidateDocumentBO).getId();
    }

    @Override
    public List<CandidateDto> searchCandidate(String email, String phone) {
        Specification spec = null;

        if (!StringUtils.isEmpty(email) && !StringUtils.isEmpty(phone))
            spec = CandidateSpecifications.isEmailPresent(email).or(CandidateSpecifications.isPhoneNumberPresent(phone));
        else if (!StringUtils.isEmpty(email))
            spec = CandidateSpecifications.isEmailPresent(email);
        else if (!StringUtils.isEmpty(phone))
            spec = CandidateSpecifications.isPhoneNumberPresent(phone);
        List<CandidateBO> all = candidateRepository.findAll(spec);
        return commonUtil.mapList(all, CandidateDto.class);
    }

    @Override
    public void auditCandidate(SjdCandidateInfoDto request, Integer userId) {
        SjdCandidateInfoBO existing = sjdCandidateInfoRepository
                .findById(new SjdCandidateInfoId(request.getSjdId(), request.getCandidateId()))
                .orElseThrow(() -> new NoSuchElementException(String.format("No mapping exists between candidate id %s and sjd id %s", request.getCandidateId(), request.getSjdId())));
        existing.setAuditResult(request.getAuditResult());
        existing.setAuditComments(request.getAuditComments());
        existing.setAuditBy(UserDetailsBO.builder().id(userId).build());
        existing.setAuditOn(new Date());
        sjdCandidateInfoRepository.save(existing);
    }

    @Override
    public List<ResumeSearchResponseDto> searchCandidateFromResumeId(List<String> resumeIds) {
        List<CandidateBO> candidates = candidateRepository.findByResumeIdIn(resumeIds);
        return candidates.stream().map((candidateBO -> {
            List<SjdBO> sjdBOS = candidateBO.getSjdCandidateInfo().stream()
                    .map((sjdCandidateInfoBO -> sjdCandidateInfoBO.getSjd())).toList();
            return ResumeSearchResponseDto.builder()
                    .resumeId(candidateBO.getResumeId())
                    .candidateId(candidateBO.getId())
                    .sjds(sjdBOS.stream().map(sjdBO -> mapper.map(sjdBO, SjdDto.class)).toList()).build();
        })).toList();
    }

    @Override
    public void deleteCandidateDetails(CandidateDetailsDeleteRequest request, CandidateDetailsType type, Integer userId) {
        CandidateEventType eventType = CandidateEventType.CANDIDATE_DETAILS_UPDATED;
        Integer idToBeDeleted = request.getIdToBeDeleted();
        switch (type) {
            case EMPLOYMENT:
                candidateEmploymentRepository.deleteById(idToBeDeleted);
                break;
            case EDUCATION:
                candidateEducationRepository.deleteById(idToBeDeleted);
                break;
            case CERTIFICATION:
                candidateCertificationRepository.deleteById(idToBeDeleted);
                break;
        }
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(request.getSjdId())
                        .candidateId(request.getCandidateId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(eventType.name()).getId())
                        .description(String.valueOf(idToBeDeleted))
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
    }

    @Override
    public void deleteCandidateInterview(CandidateDetailsDeleteRequest request, Integer userId, String accessToken) {
        Integer idToBeDeleted = request.getIdToBeDeleted();
        CandidateInterviewBO interviewInfo = candidateInterviewRepository.findById(idToBeDeleted).orElseThrow(() -> new NoSuchElementException(String.format("The requested interview with id %s is not found", idToBeDeleted)));
        candidateInterviewRepository.deleteById(idToBeDeleted);
        if (interviewInfo.getMeetingId() != null) {
            microsoftService.deleteTeamsMeeting(interviewInfo.getMeetingId(), accessToken);
            microsoftService.cancelMeetingInvite(interviewInfo.getMeetingInvitationId(), accessToken);
        }
        CandidateEventDto candidateEvent =
                CandidateEventDto
                        .builder()
                        .sjdId(request.getSjdId())
                        .candidateId(request.getCandidateId())
                        .eventTypeId(commonUtil.getCandidateEventTypeId(CandidateEventType.INTERVIEW_DELETED.name()).getId())
                        .description(String.valueOf(idToBeDeleted))
                        .build();
        candidateEventService.addEvent(candidateEvent, userId);
    }
}
