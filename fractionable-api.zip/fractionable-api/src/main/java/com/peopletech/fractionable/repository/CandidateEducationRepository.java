package com.peopletech.fractionable.repository;

import com.peopletech.fractionable.entity.CandidateEducationBO;
import org.springframework.data.repository.CrudRepository;

public interface CandidateEducationRepository extends CrudRepository<CandidateEducationBO, Integer> {
}
