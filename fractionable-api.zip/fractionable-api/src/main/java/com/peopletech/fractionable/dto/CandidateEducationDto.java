package com.peopletech.fractionable.dto;

import lombok.Data;

import java.util.Date;

@Data
public class CandidateEducationDto {
    private Integer id;
    private String institution;
    private String location;
    private String qualification;
    private String domain;
    private Date startDate;
    private Date endDate;
}
