package com.peopletech.fractionable.controller;

import com.peopletech.fractionable.constants.AppConstants;
import com.peopletech.fractionable.dto.AppResponseDto;
import com.peopletech.fractionable.dto.request.LoginRequestDto;
import com.peopletech.fractionable.dto.request.TokenAuthenticateDto;
import com.peopletech.fractionable.entity.UserDetailsBO;
import com.peopletech.fractionable.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/security")
public class SecurityController {

    @Autowired
    private UserService userService;

    @Deprecated
    @PostMapping("/login")
    public UserDetailsBO login(@RequestBody LoginRequestDto loginRequest) {
        return userService.validateUserCredentials(loginRequest);
    }

    @PostMapping("/authenticate")
    public UserDetailsBO authenticate(@RequestBody TokenAuthenticateDto request) {
        return userService.authenticateToken(request.getIdToken());
    }

    @PatchMapping("/changePassword")
    public AppResponseDto<Integer> changePassword(@RequestParam String password, @RequestHeader(AppConstants.USER_ID_HEADER) Integer userId) {
        userService.changePassword(userId, password);
        return new AppResponseDto<>(userId, "password updated successfully");
    }


}
