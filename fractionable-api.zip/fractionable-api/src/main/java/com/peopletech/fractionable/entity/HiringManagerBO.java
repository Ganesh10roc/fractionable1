package com.peopletech.fractionable.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "hiring_manager_lookup")
public class HiringManagerBO {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hiring_manager_lookup_id_generator")
    @SequenceGenerator(name = "hiring_manager_lookup_id_generator", sequenceName = "hiring_manager_lookup_id_seq", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;
}
