package com.peopletech.fractionable.dto;

import lombok.Data;

import java.util.Date;

@Data
public class AuditCandidatesReportDto {
    Integer sjdId;
    String sjdName;
    Integer candidateId;
    String candidateName;
    Integer recruiterId;
    String recruiterName;
    Date createdOn;
    Integer clientId;
    Integer operationsId;
}
